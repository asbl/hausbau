<?php
$CONFIG = array (
  'instanceid' => 'ocish1njbruw',
  'passwordsalt' => '72946170416778875038849231382812',
  'secret' => 'kquj7q47g4wb7slbju9upnkqgrdpmsidfhszp35utlwiswxxemkrexaa2puecxwl2lfolpqj1ltxxl1f7gcidp9xuudtrgn5',
  'trusted_domains' => 
  array (
    0 => 'it-teaching.de',
    1 => 'cws-lehrer.de',
  ),
  'datadirectory' => '/home4/kd34245/ownclouddata',
  'overwrite.cli.url' => 'https://it-teaching.de/owncloud',
  'dbtype' => 'mysql',
  'version' => '10.0.3.3',
  'dbname' => 'kd34245_ownc812',
  'dbhost' => 'localhost',
  'dbtableprefix' => 'oc_',
  'dbuser' => 'kd34245_ownc812',
  'dbpassword' => 'pSZ!5.WN67',
  'logtimezone' => 'Europe/Berlin',
  'installed' => true,
  'user_backends' => 
  array (
    0 => 
    array (
      'class' => 'OC_User_IMAP',
      'arguments' => 
      array (
        0 => '{mail.your-server.de:993/imap/ssl/novalidate-cert}',
      ),
    ),
  ),
  'mail_from_address' => 'andreas.siebel',
  'mail_smtpmode' => 'smtp',
  'mail_smtpsecure' => 'ssl',
  'mail_smtpauthtype' => 'LOGIN',
  'mail_smtpauth' => 1,
  'mail_domain' => 'it-teaching.de',
  'mail_smtphost' => 'smtp.gmail.com',
  'mail_smtpname' => 'andreas.siebel@it-teaching.de',
  'mail_smtppassword' => 'abpsundzyoafoegr',
  'mail_smtpport' => '465',
  'theme' => '',
  'loglevel' => 3,
  'maintenance' => false,
  'filelocking.enabled' =>false,
);
