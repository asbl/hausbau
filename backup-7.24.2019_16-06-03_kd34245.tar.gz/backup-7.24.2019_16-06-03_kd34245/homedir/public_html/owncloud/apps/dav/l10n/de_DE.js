OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Geburtstage Ihrer Kontakte",
    "Personal" : "Persönlich",
    "Contacts" : "Kontakte",
    "Technical details" : "Technische Details",
    "Remote Address: %s" : "Entfernte Adresse: %s",
    "Request ID: %s" : "Anfragekennung: %s"
},
"nplurals=2; plural=(n != 1);");
