OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Contact birthdays",
    "Personal" : "Personal",
    "Contacts" : "Contacts",
    "Technical details" : "Technical details",
    "Remote Address: %s" : "Remote Address: %s",
    "Request ID: %s" : "Request ID: %s"
},
"nplurals=2; plural=(n != 1);");
