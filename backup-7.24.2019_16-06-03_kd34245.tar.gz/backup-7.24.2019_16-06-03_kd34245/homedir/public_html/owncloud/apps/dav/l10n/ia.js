OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Die de nativitate de contacto",
    "Personal" : "Personal",
    "Contacts" : "Contactos",
    "Technical details" : "Detalios technic",
    "Remote Address: %s" : "Adresse remote: %s",
    "Request ID: %s" : "ID de requesta: %s"
},
"nplurals=2; plural=(n != 1);");
