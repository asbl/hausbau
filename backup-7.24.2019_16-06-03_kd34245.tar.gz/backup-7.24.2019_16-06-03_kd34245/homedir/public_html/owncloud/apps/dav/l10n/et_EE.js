OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Kontakti sünnipäevad",
    "Personal" : "Isiklik",
    "Contacts" : "Kontaktid",
    "Technical details" : "Tehnilised andmed",
    "Remote Address: %s" : "Kaugaadress: %s",
    "Request ID: %s" : "Päringu ID: %s"
},
"nplurals=2; plural=(n != 1);");
