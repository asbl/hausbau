OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Zile de naștere a persoanelor",
    "Personal" : "Personal",
    "Contacts" : "Contacte",
    "Technical details" : "Detalii tehnice"
},
"nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));");
