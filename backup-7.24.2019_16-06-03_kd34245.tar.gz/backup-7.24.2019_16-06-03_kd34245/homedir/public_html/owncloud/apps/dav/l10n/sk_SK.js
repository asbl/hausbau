OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Narodeniny kontaktov",
    "Personal" : "Osobné",
    "Contacts" : "Kontakty",
    "Technical details" : "Technické podrobnosti",
    "Remote Address: %s" : "Vzdialená adresa: %s",
    "Request ID: %s" : "ID požiadavky: %s"
},
"nplurals=3; plural=(n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2;");
