OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "יום הולדת של אנשי קשר",
    "Personal" : "אישי",
    "Contacts" : "אנשי קשר",
    "Technical details" : "פרטים טכנים",
    "Remote Address: %s" : "כתובת מרוחקת: %s",
    "Request ID: %s" : "מספר זיהוי מבוקש: %s"
},
"nplurals=2; plural=(n != 1);");
