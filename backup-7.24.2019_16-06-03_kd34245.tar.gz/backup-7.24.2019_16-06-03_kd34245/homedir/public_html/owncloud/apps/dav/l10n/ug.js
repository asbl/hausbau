OC.L10N.register(
    "dav",
    {
    "Personal" : "شەخسىي",
    "Contacts" : "ئالاقەداشلار"
},
"nplurals=1; plural=0;");
