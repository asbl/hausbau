OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Γενέθλια επαφής",
    "Personal" : "Προσωπικά",
    "Contacts" : "Επαφές",
    "Technical details" : "Τεχνικές λεπτομέρειες",
    "Remote Address: %s" : "Απομακρυσμένη Διεύθυνση: %s",
    "Request ID: %s" : "Αίτημα ID: %s"
},
"nplurals=2; plural=(n != 1);");
