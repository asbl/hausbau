OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "পরিচিতজনের জন্মদিন",
    "Personal" : "ব্যক্তিগত",
    "Contacts" : "পরিচিতজন"
},
"nplurals=2; plural=(n != 1);");
