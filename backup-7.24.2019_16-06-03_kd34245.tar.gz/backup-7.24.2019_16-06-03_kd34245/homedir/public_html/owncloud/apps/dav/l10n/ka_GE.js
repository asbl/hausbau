OC.L10N.register(
    "dav",
    {
    "Personal" : "პირადი",
    "Contacts" : "კონტაქტები"
},
"nplurals=1; plural=0;");
