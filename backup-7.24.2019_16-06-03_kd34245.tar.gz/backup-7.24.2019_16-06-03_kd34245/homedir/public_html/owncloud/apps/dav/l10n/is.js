OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Afmælisdagar tengiliðar",
    "Personal" : "Einka",
    "Contacts" : "Tengiliðir",
    "Technical details" : "Tæknilegar upplýsingar",
    "Remote Address: %s" : "fjartengt vistfang: %s",
    "Request ID: %s" : "Beiðni um auðkenni: %s"
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");
