OC.L10N.register(
    "dav",
    {
    "Personal" : "Անձնական"
},
"nplurals=2; plural=(n != 1);");
