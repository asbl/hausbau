OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "ខួប​កំណើត​អ្នក​ត្រូវ​ទាក់ទង",
    "Personal" : "ផ្ទាល់​ខ្លួន",
    "Contacts" : "ទំនាក់​ទំនង"
},
"nplurals=1; plural=0;");
