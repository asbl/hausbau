OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "કોન્ટાક્ટ ના જન્મદિવસ ",
    "Personal" : "વ્યક્તિગત",
    "Contacts" : "કોન્ટાક્ટ",
    "Technical details" : " તકનીકી  વિગતો ",
    "Remote Address: %s" : "દૂરનું એડ્રેસ: %s",
    "Request ID: %s" : "રિક્વેસ્ટ આઈ ડી : %s "
},
"nplurals=2; plural=(n != 1);");
