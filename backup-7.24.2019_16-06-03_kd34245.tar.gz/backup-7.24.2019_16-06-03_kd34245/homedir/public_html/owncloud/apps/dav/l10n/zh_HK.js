OC.L10N.register(
    "dav",
    {
    "Personal" : "個人",
    "Contacts" : "聯絡人"
},
"nplurals=1; plural=0;");
