OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "උපන්දින",
    "Personal" : "පෞද්ගලික",
    "Contacts" : "සබඳතා",
    "Technical details" : "තාක්ෂණික තොරතුරු",
    "Remote Address: %s" : "දූරස්ථ ලිපිනය: %s",
    "Request ID: %s" : "ඉල්ලීම්: %s"
},
"nplurals=2; plural=(n != 1);");
