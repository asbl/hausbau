OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Дні народження контактів",
    "Personal" : "Особисте",
    "Contacts" : "Контакти",
    "Technical details" : "Технічні деталі",
    "Remote Address: %s" : "Віддалена Адреса: %s",
    "Request ID: %s" : "ID запиту: %s"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
