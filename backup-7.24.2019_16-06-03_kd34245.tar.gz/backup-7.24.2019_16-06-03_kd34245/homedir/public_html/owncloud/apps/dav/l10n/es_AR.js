OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Cumpleaños",
    "Personal" : "Personal",
    "Contacts" : "Contactos"
},
"nplurals=2; plural=(n != 1);");
