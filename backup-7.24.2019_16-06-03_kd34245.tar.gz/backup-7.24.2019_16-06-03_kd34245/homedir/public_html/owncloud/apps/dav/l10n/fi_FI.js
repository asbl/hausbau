OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Syntymäpäivät",
    "Personal" : "Henkilökohtainen",
    "Contacts" : "Yhteystiedot",
    "Technical details" : "Tekniset tiedot",
    "Remote Address: %s" : "Etäosoite: %s",
    "Request ID: %s" : "Pyynnön tunniste: %s"
},
"nplurals=2; plural=(n != 1);");
