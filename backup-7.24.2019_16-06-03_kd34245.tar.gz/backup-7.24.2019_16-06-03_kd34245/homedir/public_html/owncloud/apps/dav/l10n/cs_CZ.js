OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Narozeniny kontaktů",
    "Personal" : "Osobní",
    "Contacts" : "Kontakty",
    "Technical details" : "Technické detaily",
    "Remote Address: %s" : "Vzdálená adresa: %s",
    "Request ID: %s" : "ID požadavku: %s"
},
"nplurals=3; plural=(n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2;");
