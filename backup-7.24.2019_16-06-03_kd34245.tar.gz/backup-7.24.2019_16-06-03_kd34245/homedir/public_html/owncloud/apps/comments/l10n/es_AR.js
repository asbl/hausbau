OC.L10N.register(
    "comments",
    {
    "Cancel" : "Cancelar",
    "Save" : "Guardar"
},
"nplurals=2; plural=(n != 1);");
