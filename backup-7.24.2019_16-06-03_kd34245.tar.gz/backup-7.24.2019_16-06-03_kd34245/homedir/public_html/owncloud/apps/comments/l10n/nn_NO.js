OC.L10N.register(
    "comments",
    {
    "Cancel" : "Avbryt",
    "Save" : "Lagra"
},
"nplurals=2; plural=(n != 1);");
