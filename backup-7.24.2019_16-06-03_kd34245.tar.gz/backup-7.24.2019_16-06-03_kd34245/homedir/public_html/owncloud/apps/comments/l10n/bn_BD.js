OC.L10N.register(
    "comments",
    {
    "Cancel" : "বাতিল",
    "Save" : "সংরক্ষণ",
    "Comment" : "মন্তব্য"
},
"nplurals=2; plural=(n != 1);");
