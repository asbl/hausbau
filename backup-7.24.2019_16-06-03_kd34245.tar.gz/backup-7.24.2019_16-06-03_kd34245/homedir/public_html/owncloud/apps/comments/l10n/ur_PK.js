OC.L10N.register(
    "comments",
    {
    "Cancel" : "منسوخ کریں",
    "Save" : "حفظ"
},
"nplurals=2; plural=(n != 1);");
