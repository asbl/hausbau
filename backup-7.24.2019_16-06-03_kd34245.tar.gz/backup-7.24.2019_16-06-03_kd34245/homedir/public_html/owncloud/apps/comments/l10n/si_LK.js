OC.L10N.register(
    "comments",
    {
    "Type in a new comment..." : "අලුත් අදහසක් දක්වන්න",
    "Delete comment" : "අදහස මකන්න",
    "Post" : "ලිපිය",
    "Cancel" : "එපා",
    "Comments" : "අදහස්",
    "More comments..." : "වැඩිදුර අදහස්",
    "Save" : "සුරකින්න",
    "Comment" : "අදහස"
},
"nplurals=2; plural=(n != 1);");
