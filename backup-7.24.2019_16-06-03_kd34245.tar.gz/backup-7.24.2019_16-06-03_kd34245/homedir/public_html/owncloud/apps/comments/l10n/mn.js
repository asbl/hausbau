OC.L10N.register(
    "comments",
    {
    "Save" : "Хадгалах"
},
"nplurals=2; plural=(n != 1);");
