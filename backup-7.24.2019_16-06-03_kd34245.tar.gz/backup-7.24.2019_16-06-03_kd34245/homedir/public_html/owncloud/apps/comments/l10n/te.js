OC.L10N.register(
    "comments",
    {
    "Cancel" : "రద్దుచేయి",
    "Save" : "భద్రపరచు"
},
"nplurals=2; plural=(n != 1);");
