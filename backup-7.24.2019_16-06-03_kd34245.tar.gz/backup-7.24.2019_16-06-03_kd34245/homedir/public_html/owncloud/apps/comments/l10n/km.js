OC.L10N.register(
    "comments",
    {
    "Type in a new comment..." : "សរសេរ​មតិ​ថ្មី​មួយ...",
    "Delete comment" : "លុប​មតិ​ចោល",
    "Cancel" : "បោះបង់",
    "Edit comment" : "កែសម្រួល​មតិ",
    "[Deleted user]" : "[អ្នក​ប្រើ​ដែល​បាន​លុប]",
    "Comments" : "មតិ",
    "No other comments available" : "មិនមាន​មតិ​ផ្សេង​ទៀត​ទេ",
    "More comments..." : "មតិ​ថែម​ទៀត...",
    "Save" : "រក្សាទុក",
    "Comment" : "មតិ",
    "You commented" : "អ្នក​បាន​បញ្ចេញ​មតិ​ថា",
    "%1$s commented" : "%1$s បាន​បញ្ចេញ​មតិ",
    "You commented on %2$s" : "អ្នក​បាន​បញ្ចេញ​មតិ​នៅ​លើ %2$s",
    "%1$s commented on %2$s" : "%1$s បាន​បញ្ចេញ​មតិ​នៅ​លើ %2$s"
},
"nplurals=1; plural=0;");
