OC.L10N.register(
    "comments",
    {
    "Cancel" : "Cancellar",
    "Save" : "Salveguardar"
},
"nplurals=2; plural=(n != 1);");
