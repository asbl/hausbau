-- MySQL dump 10.15  Distrib 10.0.38-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: kd34245_ghos850
-- ------------------------------------------------------
-- Server version	10.0.38-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accesstokens`
--

DROP TABLE IF EXISTS `accesstokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accesstokens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `token` varchar(255) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `expires` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accesstokens_token_unique` (`token`),
  KEY `accesstokens_user_id_foreign` (`user_id`),
  KEY `accesstokens_client_id_foreign` (`client_id`),
  CONSTRAINT `accesstokens_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `accesstokens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accesstokens`
--

LOCK TABLES `accesstokens` WRITE;
/*!40000 ALTER TABLE `accesstokens` DISABLE KEYS */;
INSERT INTO `accesstokens` (`id`, `token`, `user_id`, `client_id`, `expires`) VALUES (23,'RlHBRI7oOJpNbdPrRfnhaztR0OOYipkhOck46nUHuCvdm5FwIqUH5fGxU2I7HDjK8N6Olxb2agsk5Y9KnLTeh9tyJQKUQxRCkS4KezAp11BXD2vpBusxlWCDgdYbrtGjOJS80T5ixdQkP3drZt0O4OjMkUJeSsBBIEr5i5u15i0BvbEYbpC9caYUg2NNTxfkmHrwAhpXO8oFItc00Gro0Yp6tC5d9pzbi0d7lbZMWwT5U2LijgPlVW1fptHPBp7',1,1,1507445421933),(24,'6It3u1fHjb8LqaSbi5VI8ksmYbqDTHr5UtC4s8kpMBVnfzWNkit1r6sgkSiu3lgUvQNsSKVRpOxrqfDAg0yzGRJSFiPTrsjY9le4zFCiIev7RsdjvbMJGvbAmmfESHPRCHGLqQCCqe2DmnAbRRW7QHXDwj3FP0pv74wXtr9IGJaJfvyRdD9SRX0lYjvgASLezpVFCoRCweOMYtW8mLG78OZREiFT5QTakCRjvDQnjZ384qxPfPvEMXN8eKWC6ww',1,1,1507443382664),(25,'hIOALTdA3slTh95Cri3KlUIegk2B6eOQfJ5z0PQEi3zyitr4tRIzw9QVSCURVUwEUQhWTuB5OxjjsKMHxffXXyoiBwBgO6N9XBnSoxgFPoUHYIZdKfYdpFQpvfqLwdKof6hlO865KRf40P73X3urGZ58jNHVnXqigWTt9U3vdJxRqjdEpCSib71jihD0sjSubtrJ5Ylko6obpyrJbiaEGolopzbvJKwvtMugDVIUI4TURj3apU983svGAmiOmPl',1,1,1507624777189),(26,'BqJe5iBJTsQmV6sHxiUPQwg1crXJftZXlQPNtsgHKEAdyTTn5k7b0P5LKFnJOIBucB1tHHg3bLhDL0uf5ubRL1Of23KYZP7NJk1QwSijazUCmzHdZkt18f2Nc9PlVkR7QSry4vLg42Aclip79hule84QOuif0hsOdSCPHAJYZivhc37MaUQH8lcQHo4ltdPW4Z8daJehfjo3rfsNijLjexOhbJhlCmiWHbQY3gs17KVQjIE6IGMrFP2gzb6Ffhy',1,1,1507448098682),(27,'mru5lPq2I62zvqtnjO4IHCWf5X5sQtoW2ReJmk10XZAcBgz8PniaNPoxZfNBiQFuEPKWZN7Udv07pQPzjsdep9lnXtuF3UMy3Z0DWZ98woaKlFloksFU86CNYffFz1MHKujedjeIDVaWEcSPi9FuKy80W16HvxexS8oGIWhJKFD87Rh87DmtaJHukaF0xxgSeZ0ExPua57YcYcKgW8EbJ6kuYefec8bRfAUlIT9xP7T2f6x4igZoLRQudWjqyup',1,1,1507450159682),(28,'P6uLIQsNKrNFFlOGLSY2vfVlVPK3db8c7Jep2oyqWwTKfqyq4I5a2YIQAuRifeEKJ8A3atx5rH2AjZ7Yn0LuOKpyeVtHMI8K7dCuslBh4FnBfPqgxNG02tJh32E1EkG6ruTjkDldQoYDusXgm10AoNylt9rgpejco4Bqjfb4GniyGN3Cl0k72ZjVKs5kL6QZuf3qd0hGkDFItamT72l7HD3xOgIWmzGitne8dVK3EPfbuQ2eia3BH51V5yz4uXJ',1,1,1507476536662),(29,'pcXkup9IBkyDjVyJhwsCqOdwjl48W0zxhtFDMR8KZchhbRsoqcteNqlNYx7G2wcXF99qhB310CkNSi3idUeFMiCVcXUQW6i6pE5Bj1Q3514P7BhJti7Fq2zfCq31iaDaOYaW4VxQmJyULFDWHxrMJeV8eP0WVHkMvPzB47sqEmNTTn4j442hfoUb1oiVR52jEVDLuuYr4kbnwhDAGdG0DZMkANQFAhLUYrhnpFmo7a3XhOJOOmZ0x2X6Z6VHvvG',1,1,1507476559329),(30,'JA5efdIbOv8RM5zkDRF24lauQ0sCahUv948UzTP3fGIqmyx0CSMQIruZUvghS0pvl9GfaeNGTsUducF7HJAESWZWVbqGd7quCk8TjmFsnTvvxJYqnVVozrmYTRkHoKjPsQflxFO0ZMkxtinkScy7zqNmGNssrgBsV6ImylQf7936heqHT7GBfCU78uSiRf1OC2rMbOyiXDdQUBZ5lFGGWGRQjMgA32UMYT4IebhjIj8N5Xyyxo7t0TRwUs1utqm',1,1,1507476820562),(31,'RfJTEDn4zXXJKdTTLFBfZuAuAuYCfTC0TNHgQVTN97NOo5GCa33oOkP5riYiMbCdtGtiBIGUKQqstpEOJVUAlStliGtOQV9ArsaAJmXV0Ad2eGYi4Hua2hXEFCF6YHVu053AmfBs2BjenNB9TjEugW5EDC4oGe26qmfNNNvx6FKwEdQibUoNXbxYE89KBM2uCtQbveB65aHtiqgVYxKPM8T8VgovIhdf6sllMHx7dVs5h2EbYwM9YIirKYSlCAf',1,1,1510104520560),(32,'2FTfGBSBg1KTw9AJUPWEbkZB6u24ImYwZAjWmWOdgcRASo9mpnosi1VCLUfJDh5Re5lqk1rZFvczvLmEc8WF2YFqnxGvYFdi4LIH51byYNKlwEcfH4eAPqFyuXHzo0boDxTY8QzB4uQS9mjRfz4SX0aYqUjYRkW9NmVmfQnVOHyowvGIye5UOpBj2cZpiJizMzAEB0DwxnVyfuHTcJXn1tB2T6HQtYlQ6HqRylhCGQK22wCqsqsWK5QvAeBJgrn',1,1,1510252477181);
/*!40000 ALTER TABLE `accesstokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_fields`
--

DROP TABLE IF EXISTS `app_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `key` varchar(150) NOT NULL,
  `value` text,
  `type` varchar(150) NOT NULL DEFAULT 'html',
  `app_id` int(10) unsigned NOT NULL,
  `relatable_id` int(10) unsigned NOT NULL,
  `relatable_type` varchar(150) NOT NULL DEFAULT 'posts',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `app_fields_app_id_foreign` (`app_id`),
  CONSTRAINT `app_fields_app_id_foreign` FOREIGN KEY (`app_id`) REFERENCES `apps` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_fields`
--

LOCK TABLES `app_fields` WRITE;
/*!40000 ALTER TABLE `app_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_settings`
--

DROP TABLE IF EXISTS `app_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `key` varchar(150) NOT NULL,
  `value` text,
  `app_id` int(10) unsigned NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_settings_key_unique` (`key`),
  KEY `app_settings_app_id_foreign` (`app_id`),
  CONSTRAINT `app_settings_app_id_foreign` FOREIGN KEY (`app_id`) REFERENCES `apps` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_settings`
--

LOCK TABLES `app_settings` WRITE;
/*!40000 ALTER TABLE `app_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apps`
--

DROP TABLE IF EXISTS `apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apps` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `version` varchar(150) NOT NULL,
  `status` varchar(150) NOT NULL DEFAULT 'inactive',
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `apps_name_unique` (`name`),
  UNIQUE KEY `apps_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apps`
--

LOCK TABLES `apps` WRITE;
/*!40000 ALTER TABLE `apps` DISABLE KEYS */;
/*!40000 ALTER TABLE `apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_trusted_domains`
--

DROP TABLE IF EXISTS `client_trusted_domains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_trusted_domains` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `trusted_domain` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client_trusted_domains_client_id_foreign` (`client_id`),
  CONSTRAINT `client_trusted_domains_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_trusted_domains`
--

LOCK TABLES `client_trusted_domains` WRITE;
/*!40000 ALTER TABLE `client_trusted_domains` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_trusted_domains` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `secret` varchar(150) NOT NULL,
  `redirection_uri` varchar(2000) DEFAULT NULL,
  `logo` varchar(2000) DEFAULT NULL,
  `status` varchar(150) NOT NULL DEFAULT 'development',
  `type` varchar(150) NOT NULL DEFAULT 'ua',
  `description` varchar(200) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clients_name_unique` (`name`),
  UNIQUE KEY `clients_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` (`id`, `uuid`, `name`, `slug`, `secret`, `redirection_uri`, `logo`, `status`, `type`, `description`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES (1,'fc081896-9477-425c-b3a8-7fbe85f718c1','Ghost Admin','ghost-admin','589768115230',NULL,NULL,'enabled','ua',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(2,'c7114aa0-4e8e-4287-9493-5347bcc63a27','Ghost Frontend','ghost-frontend','370c992139cf',NULL,NULL,'enabled','ua',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(3,'5aab6cec-9aa0-44e9-b619-ac3d00a4b076','Ghost Scheduler','ghost-scheduler','ad54b4295d6a',NULL,NULL,'enabled','web',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1);
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `name` varchar(150) NOT NULL,
  `object_type` varchar(150) NOT NULL,
  `action_type` varchar(150) NOT NULL,
  `object_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` (`id`, `uuid`, `name`, `object_type`, `action_type`, `object_id`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES (1,'1a1c1663-288f-4493-a3d3-af7276ca69c6','Export database','db','exportContent',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(2,'27a54eae-0eff-4983-a4a7-9bf5d5c97e8b','Import database','db','importContent',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(3,'4521eaad-fa8c-4bac-9198-3e745dbb6a1b','Delete all content','db','deleteAllContent',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(4,'42627cf8-aa14-4f75-a564-78495823d7fb','Send mail','mail','send',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(5,'9b742ad8-8310-46ed-936a-5c599fa080b6','Browse notifications','notification','browse',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(6,'ea2a18bf-93db-4ba9-8670-d3f584ae813e','Add notifications','notification','add',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(7,'0a809680-d20c-4edb-afa1-5f417f12c3b1','Delete notifications','notification','destroy',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(8,'a528db93-2902-4419-87b0-49d60458504a','Browse posts','post','browse',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(9,'15708ee6-1349-4987-b329-cf86fabddcac','Read posts','post','read',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(10,'c6cbebd7-78c5-4428-b602-6a3dd2ca8c68','Edit posts','post','edit',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(11,'21de5bbc-df32-4b19-ad97-600c825faa1b','Add posts','post','add',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(12,'139c19b8-0175-4fd8-a366-9bd26ae55a11','Delete posts','post','destroy',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(13,'da4d58bf-de1c-4c48-b5f0-580a36c46ad4','Browse settings','setting','browse',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(14,'4f5d1869-3a71-4265-8db3-2d16b3935c85','Read settings','setting','read',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(15,'679ee173-5385-4f45-a580-acfb3267e29d','Edit settings','setting','edit',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(16,'0a290ce2-7a3a-48e8-8d87-cf3147c355f6','Generate slugs','slug','generate',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(17,'850c3538-1adf-43ed-83dd-ec460113c14f','Browse tags','tag','browse',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(18,'2a483b6a-9d8a-4eb9-9c5a-17f304b09c71','Read tags','tag','read',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(19,'e7152a43-4aa3-42c5-b41a-6686b20ac66f','Edit tags','tag','edit',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(20,'3256da0e-2ae3-4371-8fd0-8e2410ff17b8','Add tags','tag','add',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(21,'354b2215-bb2b-4c83-aff9-a73852d61490','Delete tags','tag','destroy',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(22,'02db76f0-300f-40d2-854b-8f77ffde4a6b','Browse themes','theme','browse',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(23,'29c6ed35-6627-42dc-a639-5c0bf40684db','Edit themes','theme','edit',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(24,'363d9079-26cd-4be2-bb39-c1cf05844b3b','Upload themes','theme','add',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(25,'f94c275c-6213-43b5-ab67-b656132f4dc6','Download themes','theme','read',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(26,'841c2a15-3198-4ce1-8746-2bfba79d50ab','Delete themes','theme','destroy',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(27,'c151abe9-f7dc-4f99-8222-fc0e5564ddbd','Browse users','user','browse',NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(28,'fd2c57f4-c83f-4540-b303-8e603f1a47fb','Read users','user','read',NULL,'2017-07-27 20:28:39',1,'2017-07-27 20:28:39',1),(29,'d8a7c4f1-35cb-4f84-ad09-53e047ea8eb7','Edit users','user','edit',NULL,'2017-07-27 20:28:39',1,'2017-07-27 20:28:39',1),(30,'a0a6d8c0-e548-4cad-9fb6-2416e695b18c','Add users','user','add',NULL,'2017-07-27 20:28:39',1,'2017-07-27 20:28:39',1),(31,'e78b059c-8558-475c-84bc-3a03b1f6903f','Delete users','user','destroy',NULL,'2017-07-27 20:28:39',1,'2017-07-27 20:28:39',1),(32,'604b24d7-12f1-49a6-9445-d1fe4c04e557','Assign a role','role','assign',NULL,'2017-07-27 20:28:39',1,'2017-07-27 20:28:39',1),(33,'4b496597-08ea-453a-b067-2d47ff4282f8','Browse roles','role','browse',NULL,'2017-07-27 20:28:39',1,'2017-07-27 20:28:39',1),(34,'dd6287a5-fb81-4383-9990-eef5e49cf33f','Browse clients','client','browse',NULL,'2017-07-27 20:28:39',1,'2017-07-27 20:28:39',1),(35,'23de25a6-db74-4e62-8cde-bf60778c41e5','Read clients','client','read',NULL,'2017-07-27 20:28:39',1,'2017-07-27 20:28:39',1),(36,'475b6299-121e-4b0a-8919-3c74b9a5c467','Edit clients','client','edit',NULL,'2017-07-27 20:28:39',1,'2017-07-27 20:28:39',1),(37,'b57c0836-30ac-4fff-9a25-d28499401dda','Add clients','client','add',NULL,'2017-07-27 20:28:39',1,'2017-07-27 20:28:39',1),(38,'51332baa-c8a4-423b-b980-fae9156975e9','Delete clients','client','destroy',NULL,'2017-07-27 20:28:39',1,'2017-07-27 20:28:39',1),(39,'cc87f431-5717-4bce-95f6-ad33e11c77db','Browse subscribers','subscriber','browse',NULL,'2017-07-27 20:28:39',1,'2017-07-27 20:28:39',1),(40,'29e7ec00-72ac-44c3-8da9-7666480b8e13','Read subscribers','subscriber','read',NULL,'2017-07-27 20:28:39',1,'2017-07-27 20:28:39',1),(41,'23c07394-382b-4d9d-8f32-ebf8b130351d','Edit subscribers','subscriber','edit',NULL,'2017-07-27 20:28:39',1,'2017-07-27 20:28:39',1),(42,'f1f7dd1d-2ffb-4969-a036-5d3286fe0419','Add subscribers','subscriber','add',NULL,'2017-07-27 20:28:39',1,'2017-07-27 20:28:39',1),(43,'e3567395-a51b-438e-9050-d431c629a4ae','Delete subscribers','subscriber','destroy',NULL,'2017-07-27 20:28:39',1,'2017-07-27 20:28:39',1);
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions_apps`
--

DROP TABLE IF EXISTS `permissions_apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions_apps` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions_apps`
--

LOCK TABLES `permissions_apps` WRITE;
/*!40000 ALTER TABLE `permissions_apps` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions_apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions_roles`
--

DROP TABLE IF EXISTS `permissions_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions_roles`
--

LOCK TABLES `permissions_roles` WRITE;
/*!40000 ALTER TABLE `permissions_roles` DISABLE KEYS */;
INSERT INTO `permissions_roles` (`id`, `role_id`, `permission_id`) VALUES (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5),(6,1,6),(7,1,7),(8,1,8),(9,1,9),(10,1,10),(11,1,11),(12,1,12),(13,1,13),(14,1,14),(15,1,15),(16,1,16),(17,1,17),(18,1,18),(19,1,19),(20,1,20),(21,1,21),(22,1,22),(23,1,23),(24,1,24),(25,1,25),(26,1,26),(27,1,27),(28,1,28),(29,1,29),(30,1,30),(31,1,31),(32,1,32),(33,1,33),(34,1,34),(35,1,35),(36,1,36),(37,1,37),(38,1,38),(39,1,39),(40,1,40),(41,1,41),(42,1,42),(43,1,43),(44,2,8),(45,2,9),(46,2,10),(47,2,11),(48,2,12),(49,2,13),(50,2,14),(51,2,16),(52,2,17),(53,2,18),(54,2,19),(55,2,20),(56,2,21),(57,2,27),(58,2,28),(59,2,29),(60,2,30),(61,2,31),(62,2,32),(63,2,33),(64,2,34),(65,2,35),(66,2,36),(67,2,37),(68,2,38),(69,2,42),(70,3,8),(71,3,9),(72,3,11),(73,3,13),(74,3,14),(75,3,16),(76,3,17),(77,3,18),(78,3,20),(79,3,27),(80,3,28),(81,3,33),(82,3,34),(83,3,35),(84,3,36),(85,3,37),(86,3,38),(87,3,42);
/*!40000 ALTER TABLE `permissions_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions_users`
--

DROP TABLE IF EXISTS `permissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions_users`
--

LOCK TABLES `permissions_users` WRITE;
/*!40000 ALTER TABLE `permissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `title` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `markdown` mediumtext,
  `mobiledoc` longtext,
  `html` mediumtext,
  `amp` mediumtext,
  `image` text,
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `page` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(150) NOT NULL DEFAULT 'draft',
  `language` varchar(6) NOT NULL DEFAULT 'en_US',
  `visibility` varchar(150) NOT NULL DEFAULT 'public',
  `meta_title` varchar(150) DEFAULT NULL,
  `meta_description` varchar(200) DEFAULT NULL,
  `author_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `published_at` datetime DEFAULT NULL,
  `published_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `posts_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` (`id`, `uuid`, `title`, `slug`, `markdown`, `mobiledoc`, `html`, `amp`, `image`, `featured`, `page`, `status`, `language`, `visibility`, `meta_title`, `meta_description`, `author_id`, `created_at`, `created_by`, `updated_at`, `updated_by`, `published_at`, `published_by`) VALUES (2,'2e97d558-0805-43e1-ba56-bd76010fd9fd','Tinkercad','tinkercad','Ich habe fÃ¼r den Geometrie-Unterricht ein Tool gesucht, mit dem ich einfach geometrische KÃ¶rper erstellen kann, auch solche die aus mehreren KÃ¶rpern zusammengebaut sind oder bei denen KÃ¶rper aus anderen ausgeschnitten sind.\n\n![Prisma](/blog/content/images/2017/07/tinkercad1-1.png)\n\nTinkercad ( www.tinkercad.com ) ist nach meinem ersten Eindruck gut fÃ¼r die Aufgabe geeignet. Die Software, welche eigentlich dazu gedacht ist, 3d-Modelle fÃ¼r 3d-Drucker zu erstellen ist einfach zu bediene, kostenlos und erfÃ¼llt bisher alle meine Anforderungen.\n\n![Ausgeschnittener Quader](/blog/content/images/2017/07/tinkercad2.png)',NULL,'<p>Ich habe fÃ¼r den Geometrie-Unterricht ein Tool gesucht, mit dem ich einfach geometrische KÃ¶rper erstellen kann, auch solche die aus mehreren KÃ¶rpern zusammengebaut sind oder bei denen KÃ¶rper aus anderen ausgeschnitten sind.</p>\n\n<p><img src=\"/blog/content/images/2017/07/tinkercad1-1.png\" alt=\"Prisma\" /></p>\n\n<p>Tinkercad ( www.tinkercad.com ) ist nach meinem ersten Eindruck gut fÃ¼r die Aufgabe geeignet. Die Software, welche eigentlich dazu gedacht ist, 3d-Modelle fÃ¼r 3d-Drucker zu erstellen ist einfach zu bediene, kostenlos und erfÃ¼llt bisher alle meine Anforderungen.</p>\n\n<p><img src=\"/blog/content/images/2017/07/tinkercad2.png\" alt=\"Ausgeschnittener Quader\" /></p>',NULL,'',0,0,'published','en_US','public',NULL,NULL,1,'2017-07-27 20:31:16',1,'2017-07-27 20:47:20',1,'2017-07-27 20:44:03',1),(3,'f12cef76-38e7-4d94-9dd2-7219397a633a','Welche Informationen interpretiert man aus Statistiken?','statistiken','WÃ¤hrend die Zeit aus der PISA Studie den Erfolg des finnischen Bildungssystems in Zweifel stellt [1], kritisiert der Schweizer Lehrerverband die Studie 2015 stark und zweifelt aufgrund der Umstellung von Papier auf Computer die Vergleichbarkeit mit frÃ¼heren Studien an [2] .\n\nDiese Kritik wurde vom Schweizer Lehrerverband geÃ¤uÃŸert obwohl die Schweizer bei der PISA Studie herausragende Mathematikleistungen zeigten (und das sogar trotz der Tatsache, dass in den Schweizer MathematikbÃ¼chern auf jeder Doppelseite ein neues Thema prÃ¤sentiert wird, wie jÃ¼ngst ein Brandbrief von deutschen Professoren an unserem Schulsystem kritisierte Â [3])\n\nFazit: Man sollte generell etwas vorsichtig sein, welche SchlÃ¼sse man aus solchen internationalen Vergleichsstudien zieht.\n\n[1]:Â http://www.zeit.de/â€¦/finnland-bildung-schulen-pisa-studie-sâ€¦\n\n[2]Â https://www.nzz.ch/â€¦/pisa-studie-2015-schweizer-15-jaehrigeâ€¦\n\n[3]Â http://www.tagesspiegel.de/dowâ€¦/19549926/2/offener-brief.pdf',NULL,'<p>WÃ¤hrend die Zeit aus der PISA Studie den Erfolg des finnischen Bildungssystems in Zweifel stellt [1], kritisiert der Schweizer Lehrerverband die Studie 2015 stark und zweifelt aufgrund der Umstellung von Papier auf Computer die Vergleichbarkeit mit frÃ¼heren Studien an [2] .</p>\n\n<p>Diese Kritik wurde vom Schweizer Lehrerverband geÃ¤uÃŸert obwohl die Schweizer bei der PISA Studie herausragende Mathematikleistungen zeigten (und das sogar trotz der Tatsache, dass in den Schweizer MathematikbÃ¼chern auf jeder Doppelseite ein neues Thema prÃ¤sentiert wird, wie jÃ¼ngst ein Brandbrief von deutschen Professoren an unserem Schulsystem kritisierte Â [3])</p>\n\n<p>Fazit: Man sollte generell etwas vorsichtig sein, welche SchlÃ¼sse man aus solchen internationalen Vergleichsstudien zieht.</p>\n\n<p>[1]:Â <a href=\"http://www.zeit.de/â€¦/finnland-bildung-schulen-pisa-studie-sâ€¦\">http://www.zeit.de/â€¦/finnland-bildung-schulen-pisa-studie-sâ€¦</a></p>\n\n<p>[2]Â <a href=\"https://www.nzz.ch/â€¦/pisa-studie-2015-schweizer-15-jaehrigeâ€¦\">https://www.nzz.ch/â€¦/pisa-studie-2015-schweizer-15-jaehrigeâ€¦</a></p>\n\n<p>[3]Â <a href=\"http://www.tagesspiegel.de/dowâ€¦/19549926/2/offener-brief.pdf\">http://www.tagesspiegel.de/dowâ€¦/19549926/2/offener-brief.pdf</a></p>',NULL,NULL,0,0,'published','en_US','public',NULL,NULL,1,'2017-07-27 20:45:46',1,'2017-07-27 20:46:55',1,'2017-07-27 20:46:20',1),(4,'0d6c7c00-a83a-47a6-8579-233dbf685b7c','Brandbrief zum Mathematikunterricht - Reaktionen','brandbrief-reaktionen','Im Folgenden eine Ãœbersicht auf die unterschiedlichen Reaktionen auf einen von 130 Professoren, Dozenten und Lehrern verÃ¶ffentlichten Brandbrief, der die StudierfÃ¤higkeit der jetzigen Absolventen anzweifelt:\n\n##### Neutral\n\n  * http://www.spiegel.de/lebenundlernen/uni/mathematik-professoren-beklagen-fehlendes-schuelerwissen-a-1139881.html\n\n  * http://www.tagesspiegel.de/wissen/streit-um-den-matheunterricht-mathe-richtig-durchdringen/19593046.html\n\n  * http://www.stuttgarter-zeitung.de/inhalt.studierende-scheitern-an-mittelstufenaufgaben-stuttgarter-unis-kaempfen-gegen-matheluecken.62ac0862-5cb6-4c1a-adee-4c53216e3753.html\n\n##### BefÃ¼rworter\n  *  http://www.danisch.de/blog/2017/03/23/gurken-mathematik-und-so/\n\n  *  http://www.tagesspiegel.de/berlin/brandbrief-zum-mathematikunterricht-deutschland-verrechnet-sich/19558664.html\n\n  * https://bildung-wissen.eu/fachbeitraege/schule-und-unterricht/mathematik-brandbrief-gegen-bildungsstandards.html\n\n  * http://afd-fraktion-sachsen.de/presse/pressemitteilungen/bildungsmisere-brandbrief-von-professoren-und-lehrern-kommt-zu-spaet.html\n\n  * http://www.feuerwaechter.org/2017/03/aufstand-der-mathelehrer/\n\n\n\n##### Kritiker\n\n  * https://www.jmwiarda.de/2017/03/23/bitte-an-die-fakten-halten\n\n  * http://www.tagesspiegel.de/downloads/19590132/1/mathematiker-distanzieren-sich-vom-mathematiker-brandbrief.pdf\n\n  * http://www.sueddeutsche.de/politik/gastkommentar-mehr-gauss-weniger-goethe-1.3455512#redirectedFromLandingpage',NULL,'<p>Im Folgenden eine Ãœbersicht auf die unterschiedlichen Reaktionen auf einen von 130 Professoren, Dozenten und Lehrern verÃ¶ffentlichten Brandbrief, der die StudierfÃ¤higkeit der jetzigen Absolventen anzweifelt:</p>\n\n<h5 id=\"neutral\">Neutral</h5>\n\n<ul>\n<li><p><a href=\"http://www.spiegel.de/lebenundlernen/uni/mathematik-professoren-beklagen-fehlendes-schuelerwissen-a-1139881.html\">http://www.spiegel.de/lebenundlernen/uni/mathematik-professoren-beklagen-fehlendes-schuelerwissen-a-1139881.html</a></p></li>\n<li><p><a href=\"http://www.tagesspiegel.de/wissen/streit-um-den-matheunterricht-mathe-richtig-durchdringen/19593046.html\">http://www.tagesspiegel.de/wissen/streit-um-den-matheunterricht-mathe-richtig-durchdringen/19593046.html</a></p></li>\n<li><p><a href=\"http://www.stuttgarter-zeitung.de/inhalt.studierende-scheitern-an-mittelstufenaufgaben-stuttgarter-unis-kaempfen-gegen-matheluecken.62ac0862-5cb6-4c1a-adee-4c53216e3753.html\">http://www.stuttgarter-zeitung.de/inhalt.studierende-scheitern-an-mittelstufenaufgaben-stuttgarter-unis-kaempfen-gegen-matheluecken.62ac0862-5cb6-4c1a-adee-4c53216e3753.html</a></p></li>\n</ul>\n\n<h5 id=\"befrworter\">BefÃ¼rworter</h5>\n\n<ul>\n<li><p><a href=\"http://www.danisch.de/blog/2017/03/23/gurken-mathematik-und-so/\">http://www.danisch.de/blog/2017/03/23/gurken-mathematik-und-so/</a></p></li>\n<li><p><a href=\"http://www.tagesspiegel.de/berlin/brandbrief-zum-mathematikunterricht-deutschland-verrechnet-sich/19558664.html\">http://www.tagesspiegel.de/berlin/brandbrief-zum-mathematikunterricht-deutschland-verrechnet-sich/19558664.html</a></p></li>\n<li><p><a href=\"https://bildung-wissen.eu/fachbeitraege/schule-und-unterricht/mathematik-brandbrief-gegen-bildungsstandards.html\">https://bildung-wissen.eu/fachbeitraege/schule-und-unterricht/mathematik-brandbrief-gegen-bildungsstandards.html</a></p></li>\n<li><p><a href=\"http://afd-fraktion-sachsen.de/presse/pressemitteilungen/bildungsmisere-brandbrief-von-professoren-und-lehrern-kommt-zu-spaet.html\">http://afd-fraktion-sachsen.de/presse/pressemitteilungen/bildungsmisere-brandbrief-von-professoren-und-lehrern-kommt-zu-spaet.html</a></p></li>\n<li><p><a href=\"http://www.feuerwaechter.org/2017/03/aufstand-der-mathelehrer/\">http://www.feuerwaechter.org/2017/03/aufstand-der-mathelehrer/</a></p></li>\n</ul>\n\n<h5 id=\"kritiker\">Kritiker</h5>\n\n<ul>\n<li><p><a href=\"https://www.jmwiarda.de/2017/03/23/bitte-an-die-fakten-halten\">https://www.jmwiarda.de/2017/03/23/bitte-an-die-fakten-halten</a></p></li>\n<li><p><a href=\"http://www.tagesspiegel.de/downloads/19590132/1/mathematiker-distanzieren-sich-vom-mathematiker-brandbrief.pdf\">http://www.tagesspiegel.de/downloads/19590132/1/mathematiker-distanzieren-sich-vom-mathematiker-brandbrief.pdf</a></p></li>\n<li><p><a href=\"http://www.sueddeutsche.de/politik/gastkommentar-mehr-gauss-weniger-goethe-1.3455512#redirectedFromLandingpage\">http://www.sueddeutsche.de/politik/gastkommentar-mehr-gauss-weniger-goethe-1.3455512#redirectedFromLandingpage</a></p></li>\n</ul>',NULL,NULL,0,0,'published','en_US','public',NULL,NULL,1,'2017-07-27 20:47:41',1,'2017-07-27 20:51:13',1,'2017-07-27 20:49:47',1),(5,'7d50c87d-af06-43e4-9d96-88965fd58925','Gnome!','ubuntu-gnome','Zur Zeit benutze ich zwar mal wieder Windows (Office sei dank), aber es wird sicherlich nur eine Frage der Zeit sein, bis ich mal wieder auf Linux umsteige.\n\nDa freut es mich zu hÃ¶ren, dassÂ Mark Shuttleworth angekÃ¼ndigt hat von Unity auf Gnome zu wechseln. Gnome ist meiner Meinung nach die beste Linux-Desktop Umgebung und erhÃ¤lt auf diese Weise massive UnterstÃ¼tzung.',NULL,'<p>Zur Zeit benutze ich zwar mal wieder Windows (Office sei dank), aber es wird sicherlich nur eine Frage der Zeit sein, bis ich mal wieder auf Linux umsteige.</p>\n\n<p>Da freut es mich zu hÃ¶ren, dassÂ Mark Shuttleworth angekÃ¼ndigt hat von Unity auf Gnome zu wechseln. Gnome ist meiner Meinung nach die beste Linux-Desktop Umgebung und erhÃ¤lt auf diese Weise massive UnterstÃ¼tzung.</p>',NULL,NULL,0,0,'published','en_US','public',NULL,NULL,1,'2017-07-27 20:51:17',1,'2017-07-27 20:51:50',1,'2017-07-27 20:51:50',1),(6,'03a8bd91-e610-478f-a9e2-25b51c877f5e','Onlyoffice -Eine Alternative zu MS-Office?','onlyoffice-eine-alternative-zu-ms-office','Wie im letzten Beitrag erwÃ¤hnt benutze ich (zur Zeit) Microsoft Windows, hauptsÃ¤chlich weil das Officepaket von Microsoft in einer anderen Liga spielt als Openoffice bzw. Libreoffice und ich mit den LÃ¶sungen Ã¼ber Wine/Virtualbox niemals wirklich glÃ¼cklich geworden bin. Sollte es aber einmal eine Office-Version geben, die Microsoft Office ablÃ¶st, wÃ¼rde die Sache sofort wieder ganz anders aussehen.\n\nHeute habe ich Onlyoffice installiert, um mal einen Office-Konkurrenten zu testen. Onlyoffice besticht durch ein aufgerÃ¤umtes Interface, kann kostenlos heruntergeladen werden und steht inzwischen sogar unter einer Open-Source Lizenz. Ãœber die wichtigsten Funktionen (Vorlagen, Formeln) verfÃ¼gt es zudem. WPS Office war bei mir erst vor einiger Zeit vom Rechner geflogen, weil der Formel-Editor fÃ¼r mich als Mathematiklehrer unverzichtbar ist.\n\nHier mal meine ersten Erfahrungen\n\nFormeln:\n![](/blog/content/images/2017/07/onlyoffice.png)\n\n\nPrinzipiell kann man Formeln hinzufÃ¼gen. Dies ist nicht ganz so komfortabel wie bei Office, da man sich jedesmal durch die UntermenÃ¼s quÃ¤len muss, Shortcuts der Form \\sqrt(3) funktionieren (noch) nicht.Â Die Online Hilfe ist allerdings durchaus nutzbar:Â https://helpcenter.onlyoffice.com/onlyoffice-editors/onlyoffice-document-editor/usageinstructions/insertequation.aspx\n\nWas mir zur Zeit fehlt ist die MÃ¶glichkeit die erstellten Dokumentenvorlagen zu speichern. \n\n##### Fazit\n\nAbgesehen von den eingeschrÃ¤nkten oder fehlenden Features wirkt das Programm zwar sehr reduziert aber ansonsten funktional. Insgesamt wÃ¼rde ich es allerdings als einen Konkurrenten zu Google-Docs einschÃ¤tzen und weniger als eine echte Alternative zu Microsoft-Office.\n\nDamit bleibt Windows mit Microsoft Office wohl vorerst weiterhin mein Betriebssystem Nr.1',NULL,'<p>Wie im letzten Beitrag erwÃ¤hnt benutze ich (zur Zeit) Microsoft Windows, hauptsÃ¤chlich weil das Officepaket von Microsoft in einer anderen Liga spielt als Openoffice bzw. Libreoffice und ich mit den LÃ¶sungen Ã¼ber Wine/Virtualbox niemals wirklich glÃ¼cklich geworden bin. Sollte es aber einmal eine Office-Version geben, die Microsoft Office ablÃ¶st, wÃ¼rde die Sache sofort wieder ganz anders aussehen.</p>\n\n<p>Heute habe ich Onlyoffice installiert, um mal einen Office-Konkurrenten zu testen. Onlyoffice besticht durch ein aufgerÃ¤umtes Interface, kann kostenlos heruntergeladen werden und steht inzwischen sogar unter einer Open-Source Lizenz. Ãœber die wichtigsten Funktionen (Vorlagen, Formeln) verfÃ¼gt es zudem. WPS Office war bei mir erst vor einiger Zeit vom Rechner geflogen, weil der Formel-Editor fÃ¼r mich als Mathematiklehrer unverzichtbar ist.</p>\n\n<p>Hier mal meine ersten Erfahrungen</p>\n\n<p>Formeln: <br />\n<img src=\"/blog/content/images/2017/07/onlyoffice.png\" alt=\"\" /></p>\n\n<p>Prinzipiell kann man Formeln hinzufÃ¼gen. Dies ist nicht ganz so komfortabel wie bei Office, da man sich jedesmal durch die UntermenÃ¼s quÃ¤len muss, Shortcuts der Form \\sqrt(3) funktionieren (noch) nicht.Â Die Online Hilfe ist allerdings durchaus nutzbar:Â <a href=\"https://helpcenter.onlyoffice.com/onlyoffice-editors/onlyoffice-document-editor/usageinstructions/insertequation.aspx\">https://helpcenter.onlyoffice.com/onlyoffice-editors/onlyoffice-document-editor/usageinstructions/insertequation.aspx</a></p>\n\n<p>Was mir zur Zeit fehlt ist die MÃ¶glichkeit die erstellten Dokumentenvorlagen zu speichern. </p>\n\n<h5 id=\"fazit\">Fazit</h5>\n\n<p>Abgesehen von den eingeschrÃ¤nkten oder fehlenden Features wirkt das Programm zwar sehr reduziert aber ansonsten funktional. Insgesamt wÃ¼rde ich es allerdings als einen Konkurrenten zu Google-Docs einschÃ¤tzen und weniger als eine echte Alternative zu Microsoft-Office.</p>\n\n<p>Damit bleibt Windows mit Microsoft Office wohl vorerst weiterhin mein Betriebssystem Nr.1</p>',NULL,NULL,0,0,'published','en_US','public',NULL,NULL,1,'2017-07-27 20:52:10',1,'2017-07-27 20:56:50',1,'2017-07-27 20:56:50',1),(7,'304b5df3-85d5-49aa-b606-2aec602620c2','Shortcuts Word-Formeleditor','formeleditor','Viele Jahre habe ich Openoffice genutzt und den Formeleditor lieben (und manchmal auch hassen) gelernt. Da im Berufsalltag Geschwindigkeit und ZuverlÃ¤ssigkeit eine Rolle spielt, bin ich vor einiger Zeit auf Word gewechselt. In der Summe funktioniert dies einfach besser und zuverlÃ¤ssiger. Ã„rgerlich ist allerdings der Formeleditor, insbesondere weil die Shortcuts nicht so gut dokumentiert sind wie bei Openoffice.\n\n##### Vorbereitung\n\nZunÃ¤chst muss man unter Datei->Optionen->MenÃ¼band anpassen->Tastenkombinationen eine Tastenkombination einstellen mit der man eine neue Formel einfÃ¼gen kann. (Achtung: Bei mir war die Kategorie Registerkarte EinfÃ¼gen zweimal vorhanden und nur in dem zweiten Bereich fand ich das EinfÃ¼gen von Formeln)\n\n![](/blog/content/images/2017/07/formel.png)\n\n##### Formatierungen\n\nFormatierungen erden durch Leertaste hinzufÃ¼gt:\n\n4 / 5 Leertaste wird zum entsprechenden Bruch\n4^5 Leertaste wird zu 4 hoch 5\n4_5 Leertaste wird zu 4 mit Index 5\n\n\n##### Nachschlagen\n\nMehr Infos findest du [hier](https://support.office.com/de-de/article/Lineares-Format-Formeln-mithilfe-von-UnicodeMath-und-LaTeX-in-Word-2e00618d-b1fd-49d8-8cb4-8d17f25754f8)',NULL,'<p>Viele Jahre habe ich Openoffice genutzt und den Formeleditor lieben (und manchmal auch hassen) gelernt. Da im Berufsalltag Geschwindigkeit und ZuverlÃ¤ssigkeit eine Rolle spielt, bin ich vor einiger Zeit auf Word gewechselt. In der Summe funktioniert dies einfach besser und zuverlÃ¤ssiger. Ã„rgerlich ist allerdings der Formeleditor, insbesondere weil die Shortcuts nicht so gut dokumentiert sind wie bei Openoffice.</p>\n\n<h5 id=\"vorbereitung\">Vorbereitung</h5>\n\n<p>ZunÃ¤chst muss man unter Datei->Optionen->MenÃ¼band anpassen->Tastenkombinationen eine Tastenkombination einstellen mit der man eine neue Formel einfÃ¼gen kann. (Achtung: Bei mir war die Kategorie Registerkarte EinfÃ¼gen zweimal vorhanden und nur in dem zweiten Bereich fand ich das EinfÃ¼gen von Formeln)</p>\n\n<p><img src=\"/blog/content/images/2017/07/formel.png\" alt=\"\" /></p>\n\n<h5 id=\"formatierungen\">Formatierungen</h5>\n\n<p>Formatierungen erden durch Leertaste hinzufÃ¼gt:</p>\n\n<p>4 / 5 Leertaste wird zum entsprechenden Bruch <br />\n4^5 Leertaste wird zu 4 hoch 5 <br />\n4_5 Leertaste wird zu 4 mit Index 5</p>\n\n<h5 id=\"nachschlagen\">Nachschlagen</h5>\n\n<p>Mehr Infos findest du <a href=\"https://support.office.com/de-de/article/Lineares-Format-Formeln-mithilfe-von-UnicodeMath-und-LaTeX-in-Word-2e00618d-b1fd-49d8-8cb4-8d17f25754f8\">hier</a></p>',NULL,NULL,0,0,'published','en_US','public',NULL,NULL,1,'2017-07-27 20:56:56',1,'2017-10-08 06:21:11',1,'2017-07-27 20:59:51',1),(8,'4dbc35c8-0c6a-423f-8ad4-87270f20e39d','Der MIT App-Inventor','untitled','Der MIT-App Inventor ist hier zu findenÂ http://appinventor.mit.edu/explore/ und ist eine groÃŸartige Software. In einem 1-Tag Kurs haben die SchÃ¼ler ein Malprogramm entwickelt, dessen Hintergrund per Handy-Foto aufgenommen werden konnte. Am Ende durften die SchÃ¼ler ihr Programm weiterentwickeln. Die Begeisterung war sehr groÃŸ, als eine SchÃ¼lerin herausfand, wie man das Programm via What\'s App mit seinen Freunden teilen kann.\n\nDas folgende GIF zeigt, wie einfach es ist, die Kamera des Handys zu verwenden:\n\n![](/blog/content/images/2017/07/12-camera.gif)\n\nEin paar Details zur Umsetzung:\n\nIch habeÂ nicht die App AICompanion verwendet, sondern die SchÃ¼ler haben fertig programmierte Apps direkt per QR-Code auf ihr Handy aufgeladen. Daher konnte ich mit meinem Handy ein eigenes WLAN aufspannen. Da man fÃ¼r die Entwicklung Google-Accounts benutzt, habe ich vorher einige anonymisierte Accounts erstellt. Allerdings habe ich auch gelernt, dass ein WLAN Hotspot, den man mit seinem Handy einrichtet, nicht mehr als ein Dutzend Besucher zulÃ¤sst. ',NULL,'<p>Der MIT-App Inventor ist hier zu findenÂ <a href=\"http://appinventor.mit.edu/explore/\">http://appinventor.mit.edu/explore/</a> und ist eine groÃŸartige Software. In einem 1-Tag Kurs haben die SchÃ¼ler ein Malprogramm entwickelt, dessen Hintergrund per Handy-Foto aufgenommen werden konnte. Am Ende durften die SchÃ¼ler ihr Programm weiterentwickeln. Die Begeisterung war sehr groÃŸ, als eine SchÃ¼lerin herausfand, wie man das Programm via What\'s App mit seinen Freunden teilen kann.</p>\n\n<p>Das folgende GIF zeigt, wie einfach es ist, die Kamera des Handys zu verwenden:</p>\n\n<p><img src=\"/blog/content/images/2017/07/12-camera.gif\" alt=\"\" /></p>\n\n<p>Ein paar Details zur Umsetzung:</p>\n\n<p>Ich habeÂ nicht die App AICompanion verwendet, sondern die SchÃ¼ler haben fertig programmierte Apps direkt per QR-Code auf ihr Handy aufgeladen. Daher konnte ich mit meinem Handy ein eigenes WLAN aufspannen. Da man fÃ¼r die Entwicklung Google-Accounts benutzt, habe ich vorher einige anonymisierte Accounts erstellt. Allerdings habe ich auch gelernt, dass ein WLAN Hotspot, den man mit seinem Handy einrichtet, nicht mehr als ein Dutzend Besucher zulÃ¤sst. </p>',NULL,NULL,0,0,'published','en_US','public',NULL,NULL,1,'2017-07-27 21:00:10',1,'2017-07-27 21:02:10',1,'2017-07-27 21:02:10',1),(9,'7bc445af-8dea-4af3-911a-eba845f9da1f','Greeps','greeps','Insgesamt war ich enttÃ¤uscht von der JAVA-Lernplattform Greenfoot ( https://www.greenfoot.org/door ): Zwar ist die IDE schÃ¶n, die Idee mit den Miniwelten toll, aber in den letzten Monaten sind meinen SchÃ¼lern so viele Greenfoot-Bugs begegnet, das alle nur noch genervt waren. Vielleicht war es auch ein Fehler auf die 3er Version zu setzen.\n\nDennoch gab es ein Highlight: Â In der Greeps Miniwelt ( https://www.greenfoot.org/competition/greeps/ ) mÃ¼ssen Aliens Tomaten einsammeln, die Teams traten gegeneinander an und konnten auf 3 Karten ihre Greeps trainieren, wÃ¤hrend auf den restlichen Karten dann der Sieger ausgetragen wurde:Â https://www.greenfoot.org/competition/greeps/ . Alleine fÃ¼r diese Miniwelt hat sich Greenfoot dann doch gelohnt. Im Greenroom gibt es Ã¼brigens einen Nachfolger, vielleicht probiere ich diesen mal aus...\n\n![](/blog/content/images/2017/07/greeps.png)\n',NULL,'<p>Insgesamt war ich enttÃ¤uscht von der JAVA-Lernplattform Greenfoot ( <a href=\"https://www.greenfoot.org/door\">https://www.greenfoot.org/door</a> ): Zwar ist die IDE schÃ¶n, die Idee mit den Miniwelten toll, aber in den letzten Monaten sind meinen SchÃ¼lern so viele Greenfoot-Bugs begegnet, das alle nur noch genervt waren. Vielleicht war es auch ein Fehler auf die 3er Version zu setzen.</p>\n\n<p>Dennoch gab es ein Highlight: Â In der Greeps Miniwelt ( <a href=\"https://www.greenfoot.org/competition/greeps/\">https://www.greenfoot.org/competition/greeps/</a> ) mÃ¼ssen Aliens Tomaten einsammeln, die Teams traten gegeneinander an und konnten auf 3 Karten ihre Greeps trainieren, wÃ¤hrend auf den restlichen Karten dann der Sieger ausgetragen wurde:Â <a href=\"https://www.greenfoot.org/competition/greeps/\">https://www.greenfoot.org/competition/greeps/</a> . Alleine fÃ¼r diese Miniwelt hat sich Greenfoot dann doch gelohnt. Im Greenroom gibt es Ã¼brigens einen Nachfolger, vielleicht probiere ich diesen mal aus...</p>\n\n<p><img src=\"/blog/content/images/2017/07/greeps.png\" alt=\"\" /></p>',NULL,NULL,0,0,'published','en_US','public',NULL,NULL,1,'2017-07-27 21:02:35',1,'2017-07-27 21:03:51',1,'2017-07-27 21:03:51',1),(10,'49c9816b-a925-4781-bfed-d7f5373b174d','Eclipse+Windowsbuilder','eclipse-windowsbuilder','Greenfoot war ich aufgrund der Bugs leid (Â https://itteaching.wordpress.com/2017/04/25/greeps/), der Java-Editor (http://javaeditor.org/doku.php) hat mich im ersten Durchlauf auch noch nicht vollends Ã¼berzeugt, lÃ¤uft auÃŸerdem nur unter Windows, was meiner Meinung nach ein Riesen-Nachteil ist (Hausaufgaben? Nur auf Windows-Rechnern mÃ¶glich).\n\nMein neuester Versuch: Eclipse+Window-Builder.\n\nEclipse ist eine der besten IDEs auf den Markt und wird auch von Profis verwendet. FÃ¼r meine SchÃ¼ler habe ich eine Portable-Version gewÃ¤hlt und dieses mit einer portablen Java-Version kombiniert. Auf diese Weise spart man sich das setzen von PATH-Variablen und Ã¤hnlichen Fallstricken. Wie jeder GUI-Builder hat auch dieser so seine TÃ¼cken (so wÃ¤re es praktischer, wenn die Variablen fÃ¼r die einzelnen Fensterelemente komplett zuerst definiert wÃ¼rden, so muss man gelegentlich Code schieben), dafÃ¼r bekommt man mit Eclipse auch inkrementelle FehlerÃ¼berprÃ¼fung geschenkt, was ein Riesenvorteil ist und auch aus didaktischer Perspektive Sinn macht.\n\n![](/blog/content/images/2017/07/eclipse.png)',NULL,'<p>Greenfoot war ich aufgrund der Bugs leid (Â <a href=\"https://itteaching.wordpress.com/2017/04/25/greeps/\">https://itteaching.wordpress.com/2017/04/25/greeps/</a>), der Java-Editor (<a href=\"http://javaeditor.org/doku.php\">http://javaeditor.org/doku.php</a>) hat mich im ersten Durchlauf auch noch nicht vollends Ã¼berzeugt, lÃ¤uft auÃŸerdem nur unter Windows, was meiner Meinung nach ein Riesen-Nachteil ist (Hausaufgaben? Nur auf Windows-Rechnern mÃ¶glich).</p>\n\n<p>Mein neuester Versuch: Eclipse+Window-Builder.</p>\n\n<p>Eclipse ist eine der besten IDEs auf den Markt und wird auch von Profis verwendet. FÃ¼r meine SchÃ¼ler habe ich eine Portable-Version gewÃ¤hlt und dieses mit einer portablen Java-Version kombiniert. Auf diese Weise spart man sich das setzen von PATH-Variablen und Ã¤hnlichen Fallstricken. Wie jeder GUI-Builder hat auch dieser so seine TÃ¼cken (so wÃ¤re es praktischer, wenn die Variablen fÃ¼r die einzelnen Fensterelemente komplett zuerst definiert wÃ¼rden, so muss man gelegentlich Code schieben), dafÃ¼r bekommt man mit Eclipse auch inkrementelle FehlerÃ¼berprÃ¼fung geschenkt, was ein Riesenvorteil ist und auch aus didaktischer Perspektive Sinn macht.</p>\n\n<p><img src=\"/blog/content/images/2017/07/eclipse.png\" alt=\"\" /></p>',NULL,NULL,0,0,'published','en_US','public',NULL,NULL,1,'2017-07-27 21:04:12',1,'2017-07-27 21:05:02',1,'2017-07-27 21:05:02',1),(11,'664ec8b0-d1c0-4a03-8558-04a715a71bd1','Gamegrid','gamegrid','Prinzipiell mag ich Entwicklungsumgebungen wie GreenfootÂ https://www.greenfoot.org/door . Ich denke, dass diese dabei helfen kÃ¶nnen\n\na) Die Motivation der SchÃ¼ler zu steigern\n\nb) Ein VerstÃ¤ndnis Ã¼ber den Zusammenhang von Klassen und Objekten zu fÃ¶rdern\n\nLeider hat sich bei mir die 3er Version von Greenfoot als nicht stabil genug herausgestellt. Am Ende waren die SchÃ¼ler hauptsÃ¤chlich frustriert, da ihr Programm oft abstÃ¼rzt. AuÃŸerdem ist die Fehlersuche -einer der Kernelemente des Programmierens- in Greenfoot wirklich schlecht gelÃ¶st.\n\nEclipse hat sich bei ersten Versuchen schonmal als bessere Alternative bewiesen. Zwar mÃ¼ssen die SchÃ¼ler zunÃ¤chst mal mit einigem Overhead klarkommen, wenn dieser aber aus dem Weg gerÃ¤umt wurde hat man die Vorteile einer mÃ¤chtigen Entwicklungsumgebung auf seiner Seite. Insbesondere die inkrementelle Fehlersuche erfÃ¼llt im schulischen Umfeld auch eine didaktische Funktion, da die SchÃ¼ler direktes Feedback auf ihre Aktionen erhalten und nicht warten mÃ¼ssen, bis sie auf compilieren gedrÃ¼ckt haben. Dennoch vermisste ich zunÃ¤chst die VorzÃ¼ge von Greenfoot, bis mir folgende Alternative ins Auge fiel:\n\nhttp://www.java-online.ch/gamegrid/index.php\n\nGameGrid ist ein Framework zum Programmieren von Spielen, dass sehr stark an Greenfoot erinnert. Es gibt hier aber keine graphische Entwicklungsumgebung, sondern die Programme kÃ¶nnen in jeder Umgebung geschrieben werden, die man bevorzugt (z.B. Eclipse). Alternativ gibt es auch einen Online-Editor, mit dem man Programme direkt bearbeiten kann. Man findet online auch eine Android-Version, so dass es mit dem Online-Editor ohne weiteres mÃ¶glich ist, auch Android-Spiele mit GameGrid zu entwickeln.\n\nSowohl die Syntax als auch die MenÃ¼leiste bei einem neu erstellten Spiel erinnern extrem stark an Greenfoot\n\n![](/blog/content/images/2017/07/gamegrid.png)\n\nJeder Actor verfÃ¼gt wie bei Greenfoot Ã¼ber eine act()-Funktion, die nach einem Klick auf Run in einer Endlosschleife ausgefÃ¼hrt wird, Grafiken und Sounds kÃ¶nnen ohne grÃ¶ÃŸere Schwierigkeiten hinzugefÃ¼gt werden. Â Nicht nur Spiele in einem Grid, sondern auch Pixel-basierte Spiele sind mÃ¶glich (Mein erstes Spiel handelte von einer Rakete, die Meteoren ausweicht).\n\nBei meinen ersten Experimenten bin ich auch auf einige Grenzen gestoÃŸen. Die Umgebung ist definitiv nicht fÃ¼r Personen geeignet, die sich tiefer in die 2D-Spieleentwicklung vertiefen wollen. FÃ¼r schulische Zwecke halte ich sie aber sehr geeignet, auch weil hier einige gute didaktische Vereinfachungen getroffen wurden\n\nIch habe eine allererste Version von \"GameGridCards\" erstellt, mit denen die SchÃ¼ler mit Gamegrid+Eclipse relativ selbststÃ¤ndig erste Projekte erstellen kÃ¶nnen. Ich stelle diese zur VerfÃ¼gung (mit dem Hinweis, dass diese sicher noch an einigen Stellen Arbeit benÃ¶tigen).\n\n[-> Download Gamegridcards](https://it-teaching.de/uploader/public/gamegridcards.pdf)',NULL,'<p>Prinzipiell mag ich Entwicklungsumgebungen wie GreenfootÂ <a href=\"https://www.greenfoot.org/door\">https://www.greenfoot.org/door</a> . Ich denke, dass diese dabei helfen kÃ¶nnen</p>\n\n<p>a) Die Motivation der SchÃ¼ler zu steigern</p>\n\n<p>b) Ein VerstÃ¤ndnis Ã¼ber den Zusammenhang von Klassen und Objekten zu fÃ¶rdern</p>\n\n<p>Leider hat sich bei mir die 3er Version von Greenfoot als nicht stabil genug herausgestellt. Am Ende waren die SchÃ¼ler hauptsÃ¤chlich frustriert, da ihr Programm oft abstÃ¼rzt. AuÃŸerdem ist die Fehlersuche -einer der Kernelemente des Programmierens- in Greenfoot wirklich schlecht gelÃ¶st.</p>\n\n<p>Eclipse hat sich bei ersten Versuchen schonmal als bessere Alternative bewiesen. Zwar mÃ¼ssen die SchÃ¼ler zunÃ¤chst mal mit einigem Overhead klarkommen, wenn dieser aber aus dem Weg gerÃ¤umt wurde hat man die Vorteile einer mÃ¤chtigen Entwicklungsumgebung auf seiner Seite. Insbesondere die inkrementelle Fehlersuche erfÃ¼llt im schulischen Umfeld auch eine didaktische Funktion, da die SchÃ¼ler direktes Feedback auf ihre Aktionen erhalten und nicht warten mÃ¼ssen, bis sie auf compilieren gedrÃ¼ckt haben. Dennoch vermisste ich zunÃ¤chst die VorzÃ¼ge von Greenfoot, bis mir folgende Alternative ins Auge fiel:</p>\n\n<p><a href=\"http://www.java-online.ch/gamegrid/index.php\">http://www.java-online.ch/gamegrid/index.php</a></p>\n\n<p>GameGrid ist ein Framework zum Programmieren von Spielen, dass sehr stark an Greenfoot erinnert. Es gibt hier aber keine graphische Entwicklungsumgebung, sondern die Programme kÃ¶nnen in jeder Umgebung geschrieben werden, die man bevorzugt (z.B. Eclipse). Alternativ gibt es auch einen Online-Editor, mit dem man Programme direkt bearbeiten kann. Man findet online auch eine Android-Version, so dass es mit dem Online-Editor ohne weiteres mÃ¶glich ist, auch Android-Spiele mit GameGrid zu entwickeln.</p>\n\n<p>Sowohl die Syntax als auch die MenÃ¼leiste bei einem neu erstellten Spiel erinnern extrem stark an Greenfoot</p>\n\n<p><img src=\"/blog/content/images/2017/07/gamegrid.png\" alt=\"\" /></p>\n\n<p>Jeder Actor verfÃ¼gt wie bei Greenfoot Ã¼ber eine act()-Funktion, die nach einem Klick auf Run in einer Endlosschleife ausgefÃ¼hrt wird, Grafiken und Sounds kÃ¶nnen ohne grÃ¶ÃŸere Schwierigkeiten hinzugefÃ¼gt werden. Â Nicht nur Spiele in einem Grid, sondern auch Pixel-basierte Spiele sind mÃ¶glich (Mein erstes Spiel handelte von einer Rakete, die Meteoren ausweicht).</p>\n\n<p>Bei meinen ersten Experimenten bin ich auch auf einige Grenzen gestoÃŸen. Die Umgebung ist definitiv nicht fÃ¼r Personen geeignet, die sich tiefer in die 2D-Spieleentwicklung vertiefen wollen. FÃ¼r schulische Zwecke halte ich sie aber sehr geeignet, auch weil hier einige gute didaktische Vereinfachungen getroffen wurden</p>\n\n<p>Ich habe eine allererste Version von \"GameGridCards\" erstellt, mit denen die SchÃ¼ler mit Gamegrid+Eclipse relativ selbststÃ¤ndig erste Projekte erstellen kÃ¶nnen. Ich stelle diese zur VerfÃ¼gung (mit dem Hinweis, dass diese sicher noch an einigen Stellen Arbeit benÃ¶tigen).</p>\n\n<p><a href=\"https://it-teaching.de/uploader/public/gamegridcards.pdf\">-> Download Gamegridcards</a></p>',NULL,NULL,0,0,'published','en_US','public',NULL,NULL,1,'2017-07-27 21:05:25',1,'2017-08-03 09:52:24',1,'2017-07-27 21:10:45',1),(12,'6fc2b011-d337-4757-9700-a7a61c585217','GesprÃ¤ch 5. Klasse','hausaufgaben','Ein GesprÃ¤ch wÃ¤hrend einer Mathestunde, 5. Klasse\n\nS: \"Ich lese aus ihrem Gesicht, wie viel Hausaufgaben sie uns heute geben wollen... Es wird gerade sogarÂ immer mehr...\"\n\nL: \"Wieso das denn?\"\n\nS: \"Sie grinsen immer breiter, je mehr sie grinsen, umso mehr Hausaufgaben geben sie uns auf!\"',NULL,'<p>Ein GesprÃ¤ch wÃ¤hrend einer Mathestunde, 5. Klasse</p>\n\n<p>S: \"Ich lese aus ihrem Gesicht, wie viel Hausaufgaben sie uns heute geben wollen... Es wird gerade sogarÂ immer mehr...\"</p>\n\n<p>L: \"Wieso das denn?\"</p>\n\n<p>S: \"Sie grinsen immer breiter, je mehr sie grinsen, umso mehr Hausaufgaben geben sie uns auf!\"</p>',NULL,NULL,0,0,'published','en_US','public',NULL,NULL,1,'2017-07-27 21:09:39',1,'2017-07-27 21:10:18',1,'2017-07-27 21:10:18',1),(13,'c12ac410-37a9-4d77-8aa2-a26ce55a0ee8','Die Herkunft des Biberwettbewerbs','herkunft-biber','Am Montag fand die Preisverleihung unserer SchÃ¼ler statt, auch meiner E-Phase die am Informatik-Biber teilgenommen hatte. Leider war dies die einzige Klasse, da der Wettbewerb zeitgleich mit der Geburt unseres Kindes fiel, konnte ich nicht koordinieren, dass wir noch mit mehr Klassen teilnehmen, obwohl dieser gerade fÃ¼r jÃ¼ngere SchÃ¼ler sehr gut geeignet ist. NÃ¤chstes Jahr mÃ¶chte ich auf jeden Fall mit mehr Klassen teilnehmen und auch mit einigen Kursen am BWInf Wettbewerb teilnehmen.\n\nEs gibt auch einen Zeitungsartikel, indem die Siegerehrung des Kurses abgelichtet ist:Â http://www.usinger-anzeiger.de/lokales/usingen/erfolg-kommt-durch-harte-arbeit_17960903.htm . Leider fand auch eine kurze, nicht ernsthaft gemeinte Frage unserer Fachbereichsleitung den Weg in die Presse: \"Sehr erfolgreich auch die Informatiker, die von Andreas Siebel betreut werden. Warum es ausgerechnet â€žInformatik-Biberâ€œ heiÃŸe, wisse er nicht so genau.\". Ich konnte mir zwar vorstellen, warum der Biber als Tier das den ganzen Tag nichts anderes macht, als immer perfektere DÃ¤mme zu bauen als Vorbild genommen wurde, wollte aber auch nicht spekulieren... naja, jetzt lÃ¤sst es sich nicht mehr Ã¤ndern. Marcel Inhoff vom Biber-Team gab mir dankenswerterweise einen Tipp, wo man dies nachlesen kann:Â http://www.bebras.org/?q=history.\n\nDas nÃ¤chste mal weiÃŸ ich Bescheid.',NULL,'<p>Am Montag fand die Preisverleihung unserer SchÃ¼ler statt, auch meiner E-Phase die am Informatik-Biber teilgenommen hatte. Leider war dies die einzige Klasse, da der Wettbewerb zeitgleich mit der Geburt unseres Kindes fiel, konnte ich nicht koordinieren, dass wir noch mit mehr Klassen teilnehmen, obwohl dieser gerade fÃ¼r jÃ¼ngere SchÃ¼ler sehr gut geeignet ist. NÃ¤chstes Jahr mÃ¶chte ich auf jeden Fall mit mehr Klassen teilnehmen und auch mit einigen Kursen am BWInf Wettbewerb teilnehmen.</p>\n\n<p>Es gibt auch einen Zeitungsartikel, indem die Siegerehrung des Kurses abgelichtet ist:Â <a href=\"http://www.usinger-anzeiger.de/lokales/usingen/erfolg-kommt-durch-harte-arbeit_17960903.htm\">http://www.usinger-anzeiger.de/lokales/usingen/erfolg-kommt-durch-harte-arbeit_17960903.htm</a> . Leider fand auch eine kurze, nicht ernsthaft gemeinte Frage unserer Fachbereichsleitung den Weg in die Presse: \"Sehr erfolgreich auch die Informatiker, die von Andreas Siebel betreut werden. Warum es ausgerechnet â€žInformatik-Biberâ€œ heiÃŸe, wisse er nicht so genau.\". Ich konnte mir zwar vorstellen, warum der Biber als Tier das den ganzen Tag nichts anderes macht, als immer perfektere DÃ¤mme zu bauen als Vorbild genommen wurde, wollte aber auch nicht spekulieren... naja, jetzt lÃ¤sst es sich nicht mehr Ã¤ndern. Marcel Inhoff vom Biber-Team gab mir dankenswerterweise einen Tipp, wo man dies nachlesen kann:Â <a href=\"http://www.bebras.org/?q=history\">http://www.bebras.org/?q=history</a>.</p>\n\n<p>Das nÃ¤chste mal weiÃŸ ich Bescheid.</p>',NULL,NULL,0,0,'published','en_US','public',NULL,NULL,1,'2017-07-27 21:23:57',1,'2017-07-27 21:25:36',1,'2017-07-27 21:25:13',1),(14,'cc6666b7-0b19-49be-952d-352fb0d2b34e','Differenz gewinnt','differenz-gewinnt','Differenz gewinnt ist ein Spiel fÃ¼r den Mathematikunterricht, die Spieler verteilen Chips auf die Zahlen 0-5 und versuchen mit der besten Gewinnstrategie ihre Chips schnell abzurÃ¤umen.\n\nDas Gute an dem Spiel: Es ist nicht sofort ersichtlich, was die beste Strategie ist, viele Spieler hatten beim Auswerten nochmal ein \"Aha\"-Erlebnis. Das Arbeitsblatt kÃ¶nnt\n\nZum Download: [-> Differenz gewinnt](https://it-teaching.de/uploader/public/differenz-gewinnt.pdf)',NULL,'<p>Differenz gewinnt ist ein Spiel fÃ¼r den Mathematikunterricht, die Spieler verteilen Chips auf die Zahlen 0-5 und versuchen mit der besten Gewinnstrategie ihre Chips schnell abzurÃ¤umen.</p>\n\n<p>Das Gute an dem Spiel: Es ist nicht sofort ersichtlich, was die beste Strategie ist, viele Spieler hatten beim Auswerten nochmal ein \"Aha\"-Erlebnis. Das Arbeitsblatt kÃ¶nnt</p>\n\n<p>Zum Download: <a href=\"https://it-teaching.de/uploader/public/differenz-gewinnt.pdf\">-> Differenz gewinnt</a></p>',NULL,NULL,0,0,'published','en_US','public',NULL,NULL,1,'2017-07-27 21:26:00',1,'2017-08-03 09:51:11',1,'2017-07-27 21:31:35',1),(15,'d70c124d-dff0-498f-a4f4-27b2a29b8382','Blender - Projektwoche','blender-projektwoche','FÃ¼r ein gemeinsames Projekt bei der kommenden Projektwoche arbeite ich mich gerade wieder in Blender ein.\n\nIch habe Blender zweimal im Informatikunterricht angeboten und mich selbst mÃ¼hsam eingearbeitet - Im Studium habe ich zwar einen Raytracer programmiert, aber nicht mit einem Modellierungstool gearbeitet. Jetzt habe ich das GlÃ¼ck mit einem erfahrenen Kollegen zusammenzuarbeiten, der in seiner Freizeit mit Blender modelliert. Ich freue mich schon auf alles, was ich in den kommenden Tagen lernen kann, so dass ich die Kenntnisse das nÃ¤chste mal in einen WU-Informatik einbauen kann.\n\nIn dem Zuge habe ich auf Anraten meines Kollegen die Tutorial-Videos aufÂ https://www.blenderguru.com angeschaut und konnte noch mal einiges lernen und systematisieren. Die folgende Tutorial-Serie kann ich daher nur fÃ¼r euch empfehlen, wenn ihr in Blender einsteigen wollt:Â https://www.blenderguru.com/tutorials/blender-beginner-tutorial-series\n\n![](/blog/content/images/2017/07/alleranfangistschwer.png)\n\nHier meine Â Umsetzung des Tutorials (An einigen Stellen bin ich etwas faul vorgegangen, da ich die Schritte vorher schon einmal separat gemacht hatte und keine Lust hatte mehr sie mit gleichem Aufwand genauso detailliert und genau zu machen.\n\nUnd noch eines der Lieblingsspielzeuge unseres Kindes:\n\n![](/blog/content/images/2017/07/tyos.png)\n\nEDIT: Das schÃ¶ne an solchen Projekten ist ja, dass talentierte SchÃ¼ler mit dem Input denen man ihnen gibt alles mÃ¶gliche umsetzen. Einige der Resultate waren wirklich beeindruckend.\n\n',NULL,'<p>FÃ¼r ein gemeinsames Projekt bei der kommenden Projektwoche arbeite ich mich gerade wieder in Blender ein.</p>\n\n<p>Ich habe Blender zweimal im Informatikunterricht angeboten und mich selbst mÃ¼hsam eingearbeitet - Im Studium habe ich zwar einen Raytracer programmiert, aber nicht mit einem Modellierungstool gearbeitet. Jetzt habe ich das GlÃ¼ck mit einem erfahrenen Kollegen zusammenzuarbeiten, der in seiner Freizeit mit Blender modelliert. Ich freue mich schon auf alles, was ich in den kommenden Tagen lernen kann, so dass ich die Kenntnisse das nÃ¤chste mal in einen WU-Informatik einbauen kann.</p>\n\n<p>In dem Zuge habe ich auf Anraten meines Kollegen die Tutorial-Videos aufÂ <a href=\"https://www.blenderguru.com\">https://www.blenderguru.com</a> angeschaut und konnte noch mal einiges lernen und systematisieren. Die folgende Tutorial-Serie kann ich daher nur fÃ¼r euch empfehlen, wenn ihr in Blender einsteigen wollt:Â <a href=\"https://www.blenderguru.com/tutorials/blender-beginner-tutorial-series\">https://www.blenderguru.com/tutorials/blender-beginner-tutorial-series</a></p>\n\n<p><img src=\"/blog/content/images/2017/07/alleranfangistschwer.png\" alt=\"\" /></p>\n\n<p>Hier meine Â Umsetzung des Tutorials (An einigen Stellen bin ich etwas faul vorgegangen, da ich die Schritte vorher schon einmal separat gemacht hatte und keine Lust hatte mehr sie mit gleichem Aufwand genauso detailliert und genau zu machen.</p>\n\n<p>Und noch eines der Lieblingsspielzeuge unseres Kindes:</p>\n\n<p><img src=\"/blog/content/images/2017/07/tyos.png\" alt=\"\" /></p>\n\n<p>EDIT: Das schÃ¶ne an solchen Projekten ist ja, dass talentierte SchÃ¼ler mit dem Input denen man ihnen gibt alles mÃ¶gliche umsetzen. Einige der Resultate waren wirklich beeindruckend.</p>',NULL,NULL,0,0,'published','en_US','public',NULL,NULL,1,'2017-07-27 21:27:22',1,'2017-07-27 21:31:49',1,'2017-07-27 21:31:19',1),(16,'72eaf253-70f8-45f5-9fba-a1b32d65f57d','Umzug von Wordpress auf Ghost','umzug-von-wordpress-auf-ghost','Ich nutze gerade die Sommerferien, um meine ganzen Server/Webspaces/Clouds zu sortieren, die ich fÃ¼r verschiedene AnlÃ¤sse benutze.\n\nIn diesem Zuge habe ich auch das Blog auf einen eigenen Webspace umgezogen und dabei die Software gewechselt, weg von wordpress.com und hin zu Ghost (in der Hoffnung dadurch von mehr automatisierten Angriffen verschont zu werden).\n\nInnerhalb von kÃ¼rzester Zeit habe ich mich in Ghost verliebt, was hauptsÃ¤chlich am Markdowneditor liegt - Ich liebe Markdown! \n\n(Markdown ist eine Markup-Sprache (Ã¤hnlich wie HTML oder dem Blockcode von Bulletin-Boards), die schÃ¶n einfach und elegant ist.)',NULL,'<p>Ich nutze gerade die Sommerferien, um meine ganzen Server/Webspaces/Clouds zu sortieren, die ich fÃ¼r verschiedene AnlÃ¤sse benutze.</p>\n\n<p>In diesem Zuge habe ich auch das Blog auf einen eigenen Webspace umgezogen und dabei die Software gewechselt, weg von wordpress.com und hin zu Ghost (in der Hoffnung dadurch von mehr automatisierten Angriffen verschont zu werden).</p>\n\n<p>Innerhalb von kÃ¼rzester Zeit habe ich mich in Ghost verliebt, was hauptsÃ¤chlich am Markdowneditor liegt - Ich liebe Markdown! </p>\n\n<p>(Markdown ist eine Markup-Sprache (Ã¤hnlich wie HTML oder dem Blockcode von Bulletin-Boards), die schÃ¶n einfach und elegant ist.)</p>',NULL,NULL,0,0,'published','en_US','public',NULL,NULL,1,'2017-07-27 21:32:43',1,'2017-07-27 21:48:01',1,'2017-07-27 21:48:01',1),(17,'19a97b18-adea-44f3-934d-538cf1e7723e','Auch in den Ferien wird gearbeitet...','untitled-2','\n\n',NULL,'',NULL,'/blog/content/images/2017/07/upload-1501422657-1.jpg',0,0,'published','en_US','public',NULL,NULL,1,'2017-07-30 13:49:41',1,'2017-07-30 13:54:01',1,'2017-07-30 13:53:47',1),(18,'6b427e3f-1ef5-4764-a9b0-348f111efb6a','Have I been pwned?','have-i-been-pwned','Man kann hier Ã¼berprÃ¼fen, ob Emailadressen oder PasswÃ¶rter(!) schonmal irgendwo gehackt wurden und offen sichtbar in einer Datenbank stehen.\n\nAus Neugier habe ich mal getestet, ob ein altes Passwort von mir schonmal gehackt wurde: https://haveibeenpwned.com (Antwort: Ja)\n\nMeine neueren PasswÃ¶rter traue ich mich aber nicht im Formular einzugeben. :-D',NULL,'<p>Man kann hier Ã¼berprÃ¼fen, ob Emailadressen oder PasswÃ¶rter(!) schonmal irgendwo gehackt wurden und offen sichtbar in einer Datenbank stehen.</p>\n\n<p>Aus Neugier habe ich mal getestet, ob ein altes Passwort von mir schonmal gehackt wurde: <a href=\"https://haveibeenpwned.com\">https://haveibeenpwned.com</a> (Antwort: Ja)</p>\n\n<p>Meine neueren PasswÃ¶rter traue ich mich aber nicht im Formular einzugeben. :-D</p>',NULL,'/blog/content/images/2017/08/haveibeenpwned2.png',0,0,'published','en_US','public',NULL,NULL,1,'2017-08-04 07:38:03',1,'2017-10-08 07:31:55',1,'2017-08-04 07:40:16',1),(19,'88a654b9-7b0d-412e-82d5-1590199fb77e','Tablet-Klassen: Gesammelte Infos','tablet-klassen-gesammelte-infos','Dies wird eine Linksammlung zur Umsetzung von Tablet-Projekten in der Schule\n\n##### Tipps zur Umsetzung\n\n  * Betzold - 8 Tipps zur Umsetzung: https://www.betzold.de/blog/tablets-in-der-schule/\n\n##### Erfahrungsberichte (positiv)\n\n  * Tablet-in-der-Schule - 5 Jahre ERfahrung mit IPAD-Klassen: http://www.tablet-in-der-schule.de/2016-10-15/ipads-im-klassenzimmer-zwischenbilanz-nach-fuenf-jahren-tablet-unterricht\n\n\n#### Erfahrungsberichte (Kritik)\n\n  * Hoppla! - Unkontrollierte Kritik an jungen Menschen: http://www2.hs-fulda.de/~grams/hoppla/wordpress/?p=657\n\n  * Taz - http://www.taz.de/!5321687/\n\n  \"Eine alleinerziehende Mutter wehrt sich gegen den Kauf des Tablets. Nicht vornehmlich aus Geldnot, wie das Hamburger Abendblatt Ã¼ber Sandra Kittelmann schreibt. Sie wolle weder ihre finanzielle Lage der Schule offenlegen mÃ¼ssen noch sei sie der Ansicht, dass die Kosten in einem vernÃ¼nftigen VerhÃ¤ltnis zum Nutzen stÃ¼nden. Dass die Kinder durch die GerÃ¤te stÃ¤ndig fÃ¼r die Lehrer erreichbar seien, berge Stresspotenzial, sagt Kittelmann. Zudem verhindere die RechtschreibprÃ¼fung ein selbststÃ¤ndiges Erlernen der korrekten Orthografie â€“ vor allem aber drohe eine Ausgrenzung der Kinder in den Klassen ohne iPad.\"\n\n#### Umsetzungen\n\n- FAQ der Eichenschule in ScheeÃŸel http://www.eichenschule.de/index.php/fragen-und-antworten.html',NULL,'<p>Dies wird eine Linksammlung zur Umsetzung von Tablet-Projekten in der Schule</p>\n\n<h5 id=\"tippszurumsetzung\">Tipps zur Umsetzung</h5>\n\n<ul>\n<li>Betzold - 8 Tipps zur Umsetzung: <a href=\"https://www.betzold.de/blog/tablets-in-der-schule/\">https://www.betzold.de/blog/tablets-in-der-schule/</a></li>\n</ul>\n\n<h5 id=\"erfahrungsberichtepositiv\">Erfahrungsberichte (positiv)</h5>\n\n<ul>\n<li>Tablet-in-der-Schule - 5 Jahre ERfahrung mit IPAD-Klassen: <a href=\"http://www.tablet-in-der-schule.de/2016-10-15/ipads-im-klassenzimmer-zwischenbilanz-nach-fuenf-jahren-tablet-unterricht\">http://www.tablet-in-der-schule.de/2016-10-15/ipads-im-klassenzimmer-zwischenbilanz-nach-fuenf-jahren-tablet-unterricht</a></li>\n</ul>\n\n<h4 id=\"erfahrungsberichtekritik\">Erfahrungsberichte (Kritik)</h4>\n\n<ul>\n<li><p>Hoppla! - Unkontrollierte Kritik an jungen Menschen: <a href=\"http://www2.hs-fulda.de/~grams/hoppla/wordpress/?p=657\">http://www2.hs-fulda.de/~grams/hoppla/wordpress/?p=657</a></p></li>\n<li><p>Taz - <a href=\"http://www.taz.de/!5321687/\">http://www.taz.de/!5321687/</a></p>\n\n<p>\"Eine alleinerziehende Mutter wehrt sich gegen den Kauf des Tablets. Nicht vornehmlich aus Geldnot, wie das Hamburger Abendblatt Ã¼ber Sandra Kittelmann schreibt. Sie wolle weder ihre finanzielle Lage der Schule offenlegen mÃ¼ssen noch sei sie der Ansicht, dass die Kosten in einem vernÃ¼nftigen VerhÃ¤ltnis zum Nutzen stÃ¼nden. Dass die Kinder durch die GerÃ¤te stÃ¤ndig fÃ¼r die Lehrer erreichbar seien, berge Stresspotenzial, sagt Kittelmann. Zudem verhindere die RechtschreibprÃ¼fung ein selbststÃ¤ndiges Erlernen der korrekten Orthografie â€“ vor allem aber drohe eine Ausgrenzung der Kinder in den Klassen ohne iPad.\"</p></li>\n</ul>\n\n<h4 id=\"umsetzungen\">Umsetzungen</h4>\n\n<ul>\n<li>FAQ der Eichenschule in ScheeÃŸel <a href=\"http://www.eichenschule.de/index.php/fragen-und-antworten.html\">http://www.eichenschule.de/index.php/fragen-und-antworten.html</a></li>\n</ul>',NULL,'/blog/content/images/2017/09/tablet.png',0,0,'published','en_US','public',NULL,NULL,1,'2017-09-24 10:10:38',1,'2017-09-24 10:25:49',1,'2017-09-24 10:23:23',1),(20,'16985ee4-e5df-43fd-992b-10a51e5085d3','Informatik - Was ist der \"Kern\" des Faches?','informatik-was-ist-der-kern-des-faches','Im Informatikunterricht bin ich nach meinen ersten Berufsjahren noch am rÃ¤tseln darÃ¼ber, was der \"Kern\" des Faches ist.\n\nAm meisten bin ich da am Ã¼berlegen, wo ich die PrioritÃ¤ten in der Q1 legen soll. Die Themen in dieser Jahrgangsstufe sind objektorientiertes Programmieren, sowie Algorithmen.\n\nBeim Programmieren gibt es zwei vollkommen unterschiedliche AnsÃ¤tze:\n  \n  * Ein Ansatz versucht mit Hilfe von spielerischer Umgebungen wie [GameGrid](http://www.java-online.ch/gamegrid/index.php), [Greenfoot](https://www.greenfoot.org/door) oder dem Programmieren von IDEs mit integrierten GUI-Erzeugern wie z.B. dem [Java-Editor](http://javaeditor.org/doku.php) den SpaÃŸ am Programmieren zu fÃ¶rdern. Dadurch, dass die SchÃ¼ler schnell Ergebnisse erzeugen kÃ¶nnen, Spiele und interaktive Windows-Anwendungen programmieren, soll die Motivation gefÃ¶rdert werden. Das Problem bei diesem Ansatz: Dadurch, dass man gleichzeitig sowohl mit imperativen Sprachelementen und mit Klassen und Objekten arbeiten muss, mÃ¼ssen die SchÃ¼ler sehr viele Sprachkonstrukte gleichzeitig lernen, oft fÃ¼hrt kein Weg daran vorbei Sprachelemente erst einmal zu nutzen und spÃ¤ter genauer zu verstehen.\n\n  * Ein weiterer Ansatz setzt die Programmierkonzepte in den Vordergrund, Man verzichtet auf optisch ansprechende Anwendungen zugunsten einer Fokussierung auf Sprachkonstrukte. Es reicht dann, die Ausgabe auf eine Kommandozeile auszugeben, dafÃ¼r kÃ¶nnen die SchÃ¼ler ein Programmierkonzept nach dem Anderen lernen.\n\n  * Weiterhin gibt es noch Konzepte wie LOGO oder verschiedene Implementierungen von Turtle-Grafik. Das schÃ¶ne an diesem Ansatz ist, dass hier die grundlegenden Programmierkonzepte gelernt werden kÃ¶nnen und gleichzeitig Ergebnisse sichtbar sind. \n\nNachdem ich jetzt das erste Jahr komplett mit Greenfoot gearbeitet habe, muss ich sagen, dass ich mit dem ersten Ansatz nicht glÃ¼cklich geworden bin. Die SchÃ¼ler mit Vorerfahrungen haben hier zwar tolle Sachen gemacht. Ich hatte aber das GefÃ¼hl, dass gerade die SchÃ¼ler, die Schwierigkeiten beim Programmieren hatten, es einfacher gehabt hÃ¤tten, wenn sich der Unterricht auf die wesentlichen Konzepte beschrÃ¤nkt hÃ¤tte.\n\nDas nÃ¤chste mal werde ich hier also einen anderen Weg gehen und nach einigen Wochen Turtle-Grafik systematisch nacheinander einzelne Programmierkonzepte einfÃ¼hren und schauen, ob meine SchÃ¼ler und ich damit glÃ¼cklicher werden.\n\nMein zweites Problem folgt dann aber auch schon: Wie wichtig ist mir das Programmieren eigentlich Ã¼berhaupt?\n\nIm Informatikunterricht der E2 und Q1 ist es so, dass sich beim Programmieren die Spreu vom Weizen trennt: Der gerne programmiert und dies auch in seiner Freizeit tut, der wird auch in der Q-Phase glÃ¼cklich werden. Wer nur die 2 Stunden  absitzt und sich ansonsten nicht mit Informatik beschÃ¤ftigt, der wird auch am Programmieren scheitern.\n\nDies ist deshalb schade, weil das Fach Informatik noch so viel mehr bietet als das. Entweder man kann beim Programmieren in die Tiefe gehen und sich immer mehr Techniken aneignen, um Probleme zu lÃ¶sen, oder man kann die Breite des Faches entdecken und z.B. die unterschiedlichsten Algorithmen explorieren. Mein aktueller Q1-Kurs hat z.B. nach einem programmierintensiven Start in das Schuljahr und erster Untersuchung von Such- und Sortieralgorithmen den Wunsch geÃ¤uÃŸert einen stÃ¤rkeren Fokus auf die Algorithmik zu legen. \n\nDabei kam mir der Gedanke, dass man sogar fast komplett auf das Programmieren verzichten kÃ¶nnte. Die Informatik ist schlieÃŸlich ein Fach, dass eine unglaubliche Bandbreite an Themen und Gebieten vorzuweisen hat. Was ist im Sinne der Vorbereitung auf das Studium wichtiger? Den SchÃ¼lern gute Programmierkenntnisse beibringen (zweifellos eine wichtige FÃ¤higkeit) oder die ganze Bandbreite des Faches Informatik aufzeigen, um die VielfÃ¤ltigkeit dieser Wissenschaft zu vermitteln?\n\nDie grundlegenden Fragen \"Wie viel Programmierung braucht der SchÃ¼ler und wie fÃ¼hrt man diese am besten ein?\" werden mich auf jeden Fall noch eine ganze Zeit lang beschÃ¤ftigen.',NULL,'<p>Im Informatikunterricht bin ich nach meinen ersten Berufsjahren noch am rÃ¤tseln darÃ¼ber, was der \"Kern\" des Faches ist.</p>\n\n<p>Am meisten bin ich da am Ã¼berlegen, wo ich die PrioritÃ¤ten in der Q1 legen soll. Die Themen in dieser Jahrgangsstufe sind objektorientiertes Programmieren, sowie Algorithmen.</p>\n\n<p>Beim Programmieren gibt es zwei vollkommen unterschiedliche AnsÃ¤tze:</p>\n\n<ul>\n<li><p>Ein Ansatz versucht mit Hilfe von spielerischer Umgebungen wie <a href=\"http://www.java-online.ch/gamegrid/index.php\">GameGrid</a>, <a href=\"https://www.greenfoot.org/door\">Greenfoot</a> oder dem Programmieren von IDEs mit integrierten GUI-Erzeugern wie z.B. dem <a href=\"http://javaeditor.org/doku.php\">Java-Editor</a> den SpaÃŸ am Programmieren zu fÃ¶rdern. Dadurch, dass die SchÃ¼ler schnell Ergebnisse erzeugen kÃ¶nnen, Spiele und interaktive Windows-Anwendungen programmieren, soll die Motivation gefÃ¶rdert werden. Das Problem bei diesem Ansatz: Dadurch, dass man gleichzeitig sowohl mit imperativen Sprachelementen und mit Klassen und Objekten arbeiten muss, mÃ¼ssen die SchÃ¼ler sehr viele Sprachkonstrukte gleichzeitig lernen, oft fÃ¼hrt kein Weg daran vorbei Sprachelemente erst einmal zu nutzen und spÃ¤ter genauer zu verstehen.</p></li>\n<li><p>Ein weiterer Ansatz setzt die Programmierkonzepte in den Vordergrund, Man verzichtet auf optisch ansprechende Anwendungen zugunsten einer Fokussierung auf Sprachkonstrukte. Es reicht dann, die Ausgabe auf eine Kommandozeile auszugeben, dafÃ¼r kÃ¶nnen die SchÃ¼ler ein Programmierkonzept nach dem Anderen lernen.</p></li>\n<li><p>Weiterhin gibt es noch Konzepte wie LOGO oder verschiedene Implementierungen von Turtle-Grafik. Das schÃ¶ne an diesem Ansatz ist, dass hier die grundlegenden Programmierkonzepte gelernt werden kÃ¶nnen und gleichzeitig Ergebnisse sichtbar sind. </p></li>\n</ul>\n\n<p>Nachdem ich jetzt das erste Jahr komplett mit Greenfoot gearbeitet habe, muss ich sagen, dass ich mit dem ersten Ansatz nicht glÃ¼cklich geworden bin. Die SchÃ¼ler mit Vorerfahrungen haben hier zwar tolle Sachen gemacht. Ich hatte aber das GefÃ¼hl, dass gerade die SchÃ¼ler, die Schwierigkeiten beim Programmieren hatten, es einfacher gehabt hÃ¤tten, wenn sich der Unterricht auf die wesentlichen Konzepte beschrÃ¤nkt hÃ¤tte.</p>\n\n<p>Das nÃ¤chste mal werde ich hier also einen anderen Weg gehen und nach einigen Wochen Turtle-Grafik systematisch nacheinander einzelne Programmierkonzepte einfÃ¼hren und schauen, ob meine SchÃ¼ler und ich damit glÃ¼cklicher werden.</p>\n\n<p>Mein zweites Problem folgt dann aber auch schon: Wie wichtig ist mir das Programmieren eigentlich Ã¼berhaupt?</p>\n\n<p>Im Informatikunterricht der E2 und Q1 ist es so, dass sich beim Programmieren die Spreu vom Weizen trennt: Der gerne programmiert und dies auch in seiner Freizeit tut, der wird auch in der Q-Phase glÃ¼cklich werden. Wer nur die 2 Stunden  absitzt und sich ansonsten nicht mit Informatik beschÃ¤ftigt, der wird auch am Programmieren scheitern.</p>\n\n<p>Dies ist deshalb schade, weil das Fach Informatik noch so viel mehr bietet als das. Entweder man kann beim Programmieren in die Tiefe gehen und sich immer mehr Techniken aneignen, um Probleme zu lÃ¶sen, oder man kann die Breite des Faches entdecken und z.B. die unterschiedlichsten Algorithmen explorieren. Mein aktueller Q1-Kurs hat z.B. nach einem programmierintensiven Start in das Schuljahr und erster Untersuchung von Such- und Sortieralgorithmen den Wunsch geÃ¤uÃŸert einen stÃ¤rkeren Fokus auf die Algorithmik zu legen. </p>\n\n<p>Dabei kam mir der Gedanke, dass man sogar fast komplett auf das Programmieren verzichten kÃ¶nnte. Die Informatik ist schlieÃŸlich ein Fach, dass eine unglaubliche Bandbreite an Themen und Gebieten vorzuweisen hat. Was ist im Sinne der Vorbereitung auf das Studium wichtiger? Den SchÃ¼lern gute Programmierkenntnisse beibringen (zweifellos eine wichtige FÃ¤higkeit) oder die ganze Bandbreite des Faches Informatik aufzeigen, um die VielfÃ¤ltigkeit dieser Wissenschaft zu vermitteln?</p>\n\n<p>Die grundlegenden Fragen \"Wie viel Programmierung braucht der SchÃ¼ler und wie fÃ¼hrt man diese am besten ein?\" werden mich auf jeden Fall noch eine ganze Zeit lang beschÃ¤ftigen.</p>',NULL,NULL,0,0,'published','en_US','public',NULL,NULL,1,'2017-10-08 06:21:53',1,'2017-10-08 07:30:10',1,'2017-10-08 06:39:35',1);
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts_tags`
--

DROP TABLE IF EXISTS `posts_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) unsigned NOT NULL,
  `tag_id` int(10) unsigned NOT NULL,
  `sort_order` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `posts_tags_post_id_foreign` (`post_id`),
  KEY `posts_tags_tag_id_foreign` (`tag_id`),
  CONSTRAINT `posts_tags_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`),
  CONSTRAINT `posts_tags_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts_tags`
--

LOCK TABLES `posts_tags` WRITE;
/*!40000 ALTER TABLE `posts_tags` DISABLE KEYS */;
INSERT INTO `posts_tags` (`id`, `post_id`, `tag_id`, `sort_order`) VALUES (2,3,2,0),(3,3,3,1),(4,2,4,0),(5,2,5,1),(6,4,2,0),(7,4,3,1),(8,5,6,0),(9,7,4,0),(10,7,6,1),(11,10,4,0),(12,10,7,1),(13,11,4,0),(14,11,7,1),(15,12,8,0),(16,13,8,0),(17,13,9,1),(18,13,7,2),(19,14,10,0),(20,15,8,0),(21,15,9,1),(22,15,11,2),(23,16,4,0),(24,17,9,0),(25,19,9,0),(26,19,8,1),(27,19,12,2),(28,20,7,0),(29,18,6,0),(30,18,13,1);
/*!40000 ALTER TABLE `posts_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refreshtokens`
--

DROP TABLE IF EXISTS `refreshtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refreshtokens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `token` varchar(255) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `client_id` int(10) unsigned NOT NULL,
  `expires` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `refreshtokens_token_unique` (`token`),
  KEY `refreshtokens_user_id_foreign` (`user_id`),
  KEY `refreshtokens_client_id_foreign` (`client_id`),
  CONSTRAINT `refreshtokens_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `refreshtokens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refreshtokens`
--

LOCK TABLES `refreshtokens` WRITE;
/*!40000 ALTER TABLE `refreshtokens` DISABLE KEYS */;
INSERT INTO `refreshtokens` (`id`, `token`, `user_id`, `client_id`, `expires`) VALUES (1,'rFMleTPguxL188HF8KWAvwPyGKMKpgb03oIJDp8E9yrki5QKGPigjg626rLFgHZg0hQslAsnCrtJFGA6UyxTG84erGzvP6Oz5XvNc4tgHsxahGFNo2mjzPDrhFzjX5vs3zbmJao3LY4BWJsbM1fiNKMfHvokHGN3K9onbtFf8EFXlOZYmsyBlzhFkQHhoHGZvIhHknXPVKK3i2IZwKF1VhrF3AkcclCR1Mj6e8AKlJrKgV9wq44mOnBdbumkKqs',1,1,1519585560980),(2,'dwmgFUkTCzgePPqSs5QAzjtbqzI2kJbejPhccf2k8ith9GR68YQUuLi6bbjBdpCLyI5xfofWgbUlmpHol8d4ob4eTShnB6uN1ITxdR3SSrlCyng3cg7amBEGaFKVHprVZCFXtBwVvyRxNh9TfQpJTCIg2cTSSg3rdf8fhIV3Jtnm7qC97loszdxaFSkFrMGPpxf96FawsDSXJ4SCJoTeDuYvkt0IOAOSMNUui8vKRnsgNnDrAmgULUlzKt4S24T',1,1,1506852502207),(3,'2WNaUvMzSnnQcXiSbBvKp13KehFiL7XMjXTM1tI86Zv4Z8LAT9pxpgoUhAHKxYW9AYduL270vDeari0HkH7Pjpkp32WZuARux54njjtBqlz0PBVlMZtpRcT20mj4ExjZJMvK37HBxmodzS7JaY0IFMxOm31M2UcHHyY79pTDASqGw15OgnvKkYSRS7Cs4HJLZL0h7b1EcaZuC90ff7x8HaceJOM5EkrOLePVnItKmIavij6IFqCVN8jIaorPnD2',1,1,1508046621933),(4,'rUW5hjXTPU3jwACXi66iD3Kq4L9816SAEOOJZXrhAj4lKL1VVmmHZpAH69gCsEQoO28zWeAbVKKaZd1bIrvhfDs4EAym0FwQ11Bq60UPfdxxBgqZdQqA7OGlV38fGfCAVhumQQSoFtB9NU7mUqYLcdfTbpipfhh7v8oaPGIJEXlv4VRmanSFvBZrBFxXfQjVDDJt5HwX1ZnRB9fV79RqXCgLLFjfQt0JSEWpzmgUFp8Ky4t4shcc1XCusjnqfU8',1,1,1523392477181),(5,'349rkbt25W21ZMkuGhm6iFzgVCL2tgMqTOPL6NJqv8zMqCl5PBVZ5XqPASJq5t4nWPA2kiV7hYEMAQAuGFjKVPsn2Y8p340Xi4ysCYBmv63HxKltGWCqB2v8qLuUXJHAXyH5aIT6Kkb09clswdNtU4773TKgr72VcWqcz42amO2zmkwr5KnlovTQfBWooCbduu7X2KDjL9oAk71cvYbGY7AciNqtuGHo7mrTaTo8NVhNAaP1nnaQZGZ23DcRlyw',1,1,1523244520560);
/*!40000 ALTER TABLE `refreshtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`id`, `uuid`, `name`, `description`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES (1,'3aff5b73-d845-4adc-8f91-24ff87494567','Administrator','Administrators','2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(2,'6545d861-d9ec-45bc-9a82-4e1ffb9aff08','Editor','Editors','2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(3,'c81f8800-6f3c-4de1-a2c4-b7c49be45db2','Author','Authors','2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(4,'1d0823fa-425c-4211-8924-415a8ce2427f','Owner','Blog Owner','2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles_users`
--

DROP TABLE IF EXISTS `roles_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles_users`
--

LOCK TABLES `roles_users` WRITE;
/*!40000 ALTER TABLE `roles_users` DISABLE KEYS */;
INSERT INTO `roles_users` (`id`, `role_id`, `user_id`) VALUES (1,4,1);
/*!40000 ALTER TABLE `roles_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `key` varchar(150) NOT NULL,
  `value` text,
  `type` varchar(150) NOT NULL DEFAULT 'core',
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` (`id`, `uuid`, `key`, `value`, `type`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES (1,'fea1c714-0ba5-4962-9e0c-2ce131de4ae7','databaseVersion','009','core','2017-07-27 20:28:40',1,'2017-07-27 20:28:40',1),(2,'e0832e46-6d96-4a1f-943f-e2e2034b5337','dbHash','cc0a2fc2-ba5c-4e2e-a2ac-be0600d99e57','core','2017-07-27 20:28:40',1,'2017-07-27 20:28:41',1),(3,'7846865e-c42f-401c-882a-a928c0659871','nextUpdateCheck','1510024655','core','2017-07-27 20:28:40',1,'2017-11-06 03:17:34',1),(4,'6230fd1d-e1fa-45d8-bf93-4078bc939e7a','displayUpdateNotification','0.11.12','core','2017-07-27 20:28:40',1,'2017-11-06 03:17:34',1),(5,'71241ced-15a1-4154-af98-9a4d24d188ec','seenNotifications','[]','core','2017-07-27 20:28:40',1,'2017-07-27 20:28:40',1),(6,'a9e013c7-de27-4af0-bfe7-fe6b271bc08c','migrations','{}','core','2017-07-27 20:28:40',1,'2017-07-27 20:28:40',1),(7,'9a753a9a-6af2-4c1d-97e7-5723d48a9c16','title','IT-Teaching Blog','blog','2017-07-27 20:28:40',1,'2017-10-08 15:30:40',1),(8,'089ac232-a99b-4052-a857-b089ea2b9b7f','description','Gedanken und Ideen...\n\nBetreiber: Andreas Siebel\nKontakt: a.siebel@cws-usingen.de','blog','2017-07-27 20:28:40',1,'2017-10-08 15:30:40',1),(9,'5a66e460-fd59-4733-be66-13845dc5e5b0','logo','','blog','2017-07-27 20:28:40',1,'2017-10-08 15:30:40',1),(10,'910930ac-db20-4ed6-817c-ecfe16b92945','cover','/blog/content/images/2017/08/it-teaching.jpg','blog','2017-07-27 20:28:40',1,'2017-10-08 15:30:40',1),(11,'a95e6564-7e39-499e-90f9-77116c726c63','defaultLang','en_US','blog','2017-07-27 20:28:40',1,'2017-10-08 15:30:40',1),(12,'69e621a1-3c21-422e-badc-58867f812ef9','postsPerPage','15','blog','2017-07-27 20:28:40',1,'2017-10-08 15:30:40',1),(13,'7125952d-0ba2-4ed1-8829-83b5956acbd3','activeTimezone','Etc/UTC','blog','2017-07-27 20:28:40',1,'2017-10-08 15:30:40',1),(14,'23fdfc87-d1aa-4200-962f-2a4b3e68b547','forceI18n','true','blog','2017-07-27 20:28:40',1,'2017-10-08 15:30:40',1),(15,'6778c9a1-a428-47de-94df-c9a07b1895ba','permalinks','/:slug/','blog','2017-07-27 20:28:40',1,'2017-10-08 15:30:40',1),(16,'02421a7c-c82d-49a0-9754-78781522799b','amp','true','blog','2017-07-27 20:28:40',1,'2017-10-08 15:30:40',1),(17,'a3141f9d-cd14-4386-a14e-9645f913a76b','ghost_head','','blog','2017-07-27 20:28:40',1,'2017-10-08 15:30:40',1),(18,'08878511-e606-4cdc-a4e2-3d3ab86a4132','ghost_foot','','blog','2017-07-27 20:28:40',1,'2017-10-08 15:30:40',1),(19,'5a9923cc-b5f8-4021-ab19-5430bfb44bf5','facebook','','blog','2017-07-27 20:28:40',1,'2017-10-08 15:30:40',1),(20,'2be0d705-d580-4362-956c-5a25766ba12a','twitter','','blog','2017-07-27 20:28:40',1,'2017-10-08 15:30:40',1),(21,'65d616c7-c9dd-4f22-b60b-a20e0fe4218f','labs','{\"subscribers\":true}','blog','2017-07-27 20:28:40',1,'2017-10-08 15:30:40',1),(22,'587f5e73-4247-4623-8a73-4b3fb776e7b7','navigation','[{\"label\":\"Moodle\",\"url\":\"https://it-teaching.de/moodle/\"}]','blog','2017-07-27 20:28:40',1,'2017-10-08 15:30:40',1),(23,'4c746cac-00cf-4fb0-8aa1-d0dfb95a6886','slack','[{\"url\":\"\"}]','blog','2017-07-27 20:28:40',1,'2017-10-08 15:30:40',1),(24,'39476920-190a-40e8-b2b2-b8e3ee28233d','activeApps','[]','app','2017-07-27 20:28:40',1,'2017-07-27 20:28:40',1),(25,'077ffeb7-4768-4a33-9702-22ca20b7182c','installedApps','[]','app','2017-07-27 20:28:40',1,'2017-09-26 17:50:45',1),(26,'250a635f-04c7-4ff4-a899-6becd5c7537c','isPrivate','false','private','2017-07-27 20:28:40',1,'2017-10-08 15:30:40',1),(27,'83c6df0c-c21a-4784-b92b-7665b5f8c9af','password','','private','2017-07-27 20:28:40',1,'2017-10-08 15:30:40',1),(28,'64719db1-a252-4c35-84af-b65c314e37c2','activeTheme','uno-zen-master','theme','2017-07-27 20:28:40',1,'2017-10-08 15:30:40',1);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscribers`
--

DROP TABLE IF EXISTS `subscribers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscribers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `email` varchar(254) NOT NULL,
  `status` varchar(150) NOT NULL DEFAULT 'pending',
  `post_id` int(10) unsigned DEFAULT NULL,
  `subscribed_url` text,
  `subscribed_referrer` text,
  `unsubscribed_url` text,
  `unsubscribed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subscribers_email_unique` (`email`),
  KEY `subscribers_post_id_foreign` (`post_id`),
  CONSTRAINT `subscribers_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscribers`
--

LOCK TABLES `subscribers` WRITE;
/*!40000 ALTER TABLE `subscribers` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscribers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `image` text,
  `parent_id` int(11) DEFAULT NULL,
  `visibility` varchar(150) NOT NULL DEFAULT 'public',
  `meta_title` varchar(150) DEFAULT NULL,
  `meta_description` varchar(200) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` (`id`, `uuid`, `name`, `slug`, `description`, `image`, `parent_id`, `visibility`, `meta_title`, `meta_description`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES (1,'788c1ac5-0751-4734-9571-44452be679f2','Getting Started','getting-started',NULL,NULL,NULL,'public',NULL,NULL,'2017-07-27 20:28:38',1,'2017-07-27 20:28:38',1),(2,'8b50c931-5995-4176-909a-bd5d76cf2c22','Schule','schule',NULL,NULL,NULL,'public',NULL,NULL,'2017-07-27 20:46:55',1,'2017-07-27 20:46:55',1),(3,'0d20fdc2-4675-4a4a-a6d7-ed421c7ac959','Politik','politik',NULL,NULL,NULL,'public',NULL,NULL,'2017-07-27 20:46:55',1,'2017-07-27 20:46:55',1),(4,'53e5d609-d0ef-4151-aa20-a4f135992f97','Tools','tools',NULL,NULL,NULL,'public',NULL,NULL,'2017-07-27 20:47:20',1,'2017-07-27 20:47:20',1),(5,'69dec4ef-19a0-4153-b55e-a7b43846f17c','Mathematik','mathematik',NULL,NULL,NULL,'public',NULL,NULL,'2017-07-27 20:47:20',1,'2017-07-27 20:47:20',1),(6,'7365d56f-852a-40f4-9ca0-96493dab53f7','IT','it',NULL,NULL,NULL,'public',NULL,NULL,'2017-07-27 20:51:50',1,'2017-07-27 20:51:50',1),(7,'1605a8b0-fc31-4446-a948-bd5e618ce820','Informatikunterricht','informatikunterricht',NULL,NULL,NULL,'public',NULL,NULL,'2017-07-27 21:04:57',1,'2017-07-27 21:04:57',1),(8,'1d80dd02-06a1-4e94-8787-13f5b3d07718','Unterricht','unterricht',NULL,NULL,NULL,'public',NULL,NULL,'2017-07-27 21:10:18',1,'2017-07-27 21:10:18',1),(9,'b9d835ae-5081-4ee8-9960-b647ae51b3c9','Schulalltag','schulalltag',NULL,NULL,NULL,'public',NULL,NULL,'2017-07-27 21:25:36',1,'2017-07-27 21:25:36',1),(10,'43d49d57-009a-42be-8be1-451984a3b5c9','Mathematikunterricht','mathematikunterricht',NULL,NULL,NULL,'public',NULL,NULL,'2017-07-27 21:26:00',1,'2017-07-27 21:26:00',1),(11,'a61ce97f-ff66-4630-8dc8-0885c6e88b7e','Blender','blender',NULL,NULL,NULL,'public',NULL,NULL,'2017-07-27 21:31:19',1,'2017-07-27 21:31:19',1),(12,'f232bf77-7a91-4b86-b0cd-8b9f8000db6c','Tablets','tablets',NULL,NULL,NULL,'public',NULL,NULL,'2017-09-24 10:25:49',1,'2017-09-24 10:25:49',1),(13,'1bc98d14-fe13-4d6b-a901-6359878ccdd0','IT-Sicherheit','it-sicherheit',NULL,NULL,NULL,'public',NULL,NULL,'2017-10-08 07:31:55',1,'2017-10-08 07:31:55',1);
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `password` varchar(60) NOT NULL,
  `email` varchar(254) NOT NULL,
  `image` text,
  `cover` text,
  `bio` varchar(200) DEFAULT NULL,
  `website` text,
  `location` text,
  `facebook` text,
  `twitter` text,
  `accessibility` text,
  `status` varchar(150) NOT NULL DEFAULT 'active',
  `language` varchar(6) NOT NULL DEFAULT 'en_US',
  `visibility` varchar(150) NOT NULL DEFAULT 'public',
  `meta_title` varchar(150) DEFAULT NULL,
  `meta_description` varchar(200) DEFAULT NULL,
  `tour` text,
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_slug_unique` (`slug`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `uuid`, `name`, `slug`, `password`, `email`, `image`, `cover`, `bio`, `website`, `location`, `facebook`, `twitter`, `accessibility`, `status`, `language`, `visibility`, `meta_title`, `meta_description`, `tour`, `last_login`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES (1,'7810238a-0266-499e-a0e2-343d43ae7861','sbl','sbl','$2a$10$W8i5nwWyVBlaf181w.zZJuqkAVt442fQm5LVYNt9WGnAb3BNNG1aq','a.siebel@cws-usingen.de','/blog/content/images/2017/09/as-1.png',NULL,'Andreas Siebel unterrichtet die FÃ¤cher Mathematik und Informatik an der CWS in Usingen.',NULL,'Deutschland',NULL,NULL,NULL,'active','en_US','public',NULL,NULL,NULL,'2017-10-10 08:34:37','2017-07-27 20:28:40',1,'2017-10-10 08:34:37',1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'kd34245_ghos850'
--

--
-- Dumping routines for database 'kd34245_ghos850'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-24 16:07:15
