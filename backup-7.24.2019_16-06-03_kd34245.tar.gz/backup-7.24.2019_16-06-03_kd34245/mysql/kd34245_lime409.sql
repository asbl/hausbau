-- MySQL dump 10.15  Distrib 10.0.38-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: kd34245_lime409
-- ------------------------------------------------------
-- Server version	10.0.38-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lszb_answers`
--

DROP TABLE IF EXISTS `lszb_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_answers` (
  `qid` int(11) NOT NULL,
  `code` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sortorder` int(11) NOT NULL,
  `assessment_value` int(11) NOT NULL DEFAULT '0',
  `language` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `scale_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`qid`,`code`,`language`,`scale_id`),
  KEY `lszb_answers_idx2` (`sortorder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_answers`
--

LOCK TABLES `lszb_answers` WRITE;
/*!40000 ALTER TABLE `lszb_answers` DISABLE KEYS */;
INSERT INTO `lszb_answers` (`qid`, `code`, `answer`, `sortorder`, `assessment_value`, `language`, `scale_id`) VALUES (2,'A3','Ich hatte vor dem Kurs mittlere Programmiererfahrungen - Ich hatte bereits  eigene Projekte umgesetzt',3,0,'de',0),(2,'A2','Ich hatte vor dem Kurs geringe Programmiererfahrungen - Einige Grundkenntnisse waren vorhanden',2,0,'de',0),(2,'A1','Ich hatte vor dem Kurs keine Programmiererfahrungen',1,0,'de',0),(3,'A1','Ich habe nichts neues gelernt',1,0,'de',0),(3,'A2','Ich habe wenig neues gelernt',2,0,'de',0),(3,'A3','Ich habe viel neues gelernt',3,0,'de',0),(2,'A4','Ich hatte vor dem Kurs hohe Programmiererfahrungen - Programmieren ist mein Hobby',4,0,'de',0),(9,'A1','Keine Vorerfahrungen',1,0,'de',0),(9,'A2','Geringe Vorerfahrungen',2,0,'de',0),(9,'A3','Mittlere Vorerfahrungen',3,0,'de',0),(9,'A4','Umfangreiche Vorerfahrungen',4,0,'de',0),(11,'A1','Ich habe nichts neues gelernt',1,0,'de',0),(11,'A2','Ich habe wenig neues gelernt',2,0,'de',0),(11,'A3','Ich habe viel neues gelernt',3,0,'de',0),(12,'A1','zu leicht',1,0,'de',0),(12,'A2','mittelschwer',2,0,'de',0),(12,'A3','zu schwer',3,0,'de',0),(144,'A1','1 - Trifft voll zu',1,0,'de',0),(145,'A3','3',3,0,'de',0),(145,'A4','4',4,0,'de',0),(145,'A2','2',2,0,'de',0),(110,'A1','Ich verstehe mathematische Sachverhalte oft gut',1,0,'de',0),(110,'A2','Ich verstehe Sachverhalte meistens gut. Manchmal habe ich Schwierigkeiten',2,0,'de',0),(110,'A3','Ich habe oft Schwierigkeiten und muss mich wirklich anstrengen um Sachverhalte zu verstehen.',3,0,'de',0),(111,'A1','Ich habe ein fundiertes Grundwissen in den Bereichen Bruchrechnung, Prozentrechnung und Zuordnungen',1,0,'de',0),(111,'A3','Ich habe ein solides Grundwissen in den Bereichen Bruchrechnung, Prozentrechnung und Zuordnungen mit kleinen Lücken',2,0,'de',0),(111,'A2','Ich habe ein lückenhaftes Grundwissen in den Bereichen Bruchrechnung, Prozentrechnung und Zuordnungen',3,0,'de',0),(113,'A5','5',5,0,'de',0),(113,'A6','6 - Trifft gar nicht zu',6,0,'de',0),(112,'A2','2',2,0,'de',0),(112,'A3','3',3,0,'de',0),(112,'A4','4',4,0,'de',0),(112,'A5','5',5,0,'de',0),(112,'A6','6 - Trifft gar nicht zu',6,0,'de',0),(113,'A1','1 - Trifft voll zu',1,0,'de',0),(113,'A2','2',2,0,'de',0),(113,'A3','3',3,0,'de',0),(113,'A4','4',4,0,'de',0),(112,'A1','1 - Trifft voll zu',1,0,'de',0),(142,'A1','Ich verstehe mathematische Sachverhalte oft gut',1,0,'de',0),(142,'A2','Ich verstehe Sachverhalte meistens gut. Manchmal habe ich Schwierigkeiten',2,0,'de',0),(142,'A3','Ich habe oft Schwierigkeiten und muss mich wirklich anstrengen um Sachverhalte zu verstehen.',3,0,'de',0),(143,'A1','Ich habe ein fundiertes Grundwissen in den Bereichen Bruchrechnung, Prozentrechnung und Zuordnungen',1,0,'de',0),(143,'A3','Ich habe ein solides Grundwissen in den Bereichen Bruchrechnung, Prozentrechnung und Zuordnungen mit kleinen Lücken',2,0,'de',0),(143,'A2','Ich habe ein lückenhaftes Grundwissen in den Bereichen Bruchrechnung, Prozentrechnung und Zuordnungen',3,0,'de',0),(145,'A5','5',5,0,'de',0),(145,'A6','6 - Trifft gar nicht zu',6,0,'de',0),(144,'A2','2',2,0,'de',0),(144,'A3','3',3,0,'de',0),(144,'A4','4',4,0,'de',0),(144,'A5','5',5,0,'de',0),(144,'A6','6 - Trifft gar nicht zu',6,0,'de',0),(145,'A1','1 - Trifft voll zu',1,0,'de',0),(77,'A1','Ich verstehe mathematische Sachverhalte oft gut',1,0,'de',0),(77,'A2','Ich verstehe Sachverhalte meistens gut. Manchmal habe ich Schwierigkeiten',2,0,'de',0),(77,'A3','Ich habe oft Schwierigkeiten und muss mich wirklich anstrengen um Sachverhalte zu verstehen.',3,0,'de',0),(78,'A1','Ich habe ein fundiertes Grundwissen in den Bereichen Bruchrechnung, Prozentrechnung und Zuordnungen',1,0,'de',0),(78,'A3','Ich habe ein solides Grundwissen in den Bereichen Bruchrechnung, Prozentrechnung und Zuordnungen mit kleinen Lücken',2,0,'de',0),(78,'A2','Ich habe ein lückenhaftes Grundwissen in den Bereichen Bruchrechnung, Prozentrechnung und Zuordnungen',3,0,'de',0),(80,'A5','5',5,0,'de',0),(80,'A6','6 - Trifft gar nicht zu',6,0,'de',0),(79,'A2','2',2,0,'de',0),(79,'A3','3',3,0,'de',0),(79,'A4','4',4,0,'de',0),(79,'A5','5',5,0,'de',0),(79,'A6','6 - Trifft gar nicht zu',6,0,'de',0),(80,'A1','1 - Trifft voll zu',1,0,'de',0),(80,'A2','2',2,0,'de',0),(80,'A3','3',3,0,'de',0),(80,'A4','4',4,0,'de',0),(79,'A1','1 - Trifft voll zu',1,0,'de',0);
/*!40000 ALTER TABLE `lszb_answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_assessments`
--

DROP TABLE IF EXISTS `lszb_assessments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_assessments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL DEFAULT '0',
  `scope` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gid` int(11) NOT NULL DEFAULT '0',
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `minimum` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `maximum` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  PRIMARY KEY (`id`,`language`),
  KEY `lszb_assessments_idx2` (`sid`),
  KEY `lszb_assessments_idx3` (`gid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_assessments`
--

LOCK TABLES `lszb_assessments` WRITE;
/*!40000 ALTER TABLE `lszb_assessments` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_assessments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_asset_version`
--

DROP TABLE IF EXISTS `lszb_asset_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_asset_version` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_asset_version`
--

LOCK TABLES `lszb_asset_version` WRITE;
/*!40000 ALTER TABLE `lszb_asset_version` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_asset_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_boxes`
--

DROP TABLE IF EXISTS `lszb_boxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_boxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` int(11) DEFAULT NULL,
  `url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ico` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `page` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `usergroup` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_boxes`
--

LOCK TABLES `lszb_boxes` WRITE;
/*!40000 ALTER TABLE `lszb_boxes` DISABLE KEYS */;
INSERT INTO `lszb_boxes` (`id`, `position`, `url`, `title`, `ico`, `desc`, `page`, `usergroup`) VALUES (1,1,'admin/survey/sa/newsurvey','Create survey','icon-add','Create a new survey','welcome',-2),(2,2,'admin/survey/sa/listsurveys','List surveys','icon-list','List available surveys','welcome',-1),(3,3,'admin/globalsettings','Global settings','icon-settings','Edit global settings','welcome',-2),(4,4,'admin/update','ComfortUpdate','icon-shield','Stay safe and up to date','welcome',-2),(5,5,'https://www.limesurvey.org/limestore','LimeStore','fa fa-cart-plus','LimeSurvey extension marketplace','welcome',-2),(6,6,'admin/themeoptions','Themes','icon-templates','Themes','welcome',-2);
/*!40000 ALTER TABLE `lszb_boxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_conditions`
--

DROP TABLE IF EXISTS `lszb_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_conditions` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL DEFAULT '0',
  `cqid` int(11) NOT NULL DEFAULT '0',
  `cfieldname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `method` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `scenario` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`cid`),
  KEY `lszb_conditions_idx` (`qid`),
  KEY `lszb_conditions_idx3` (`cqid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_conditions`
--

LOCK TABLES `lszb_conditions` WRITE;
/*!40000 ALTER TABLE `lszb_conditions` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_conditions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_defaultvalues`
--

DROP TABLE IF EXISTS `lszb_defaultvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_defaultvalues` (
  `qid` int(11) NOT NULL DEFAULT '0',
  `scale_id` int(11) NOT NULL DEFAULT '0',
  `sqid` int(11) NOT NULL DEFAULT '0',
  `language` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `specialtype` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `defaultvalue` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`qid`,`specialtype`,`language`,`scale_id`,`sqid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_defaultvalues`
--

LOCK TABLES `lszb_defaultvalues` WRITE;
/*!40000 ALTER TABLE `lszb_defaultvalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_defaultvalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_expression_errors`
--

DROP TABLE IF EXISTS `lszb_expression_errors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_expression_errors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `errortime` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sid` int(11) DEFAULT NULL,
  `gid` int(11) DEFAULT NULL,
  `qid` int(11) DEFAULT NULL,
  `gseq` int(11) DEFAULT NULL,
  `qseq` int(11) DEFAULT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `eqn` text COLLATE utf8mb4_unicode_ci,
  `prettyprint` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_expression_errors`
--

LOCK TABLES `lszb_expression_errors` WRITE;
/*!40000 ALTER TABLE `lszb_expression_errors` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_expression_errors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_failed_login_attempts`
--

DROP TABLE IF EXISTS `lszb_failed_login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_failed_login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_attempt` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_attempts` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_failed_login_attempts`
--

LOCK TABLES `lszb_failed_login_attempts` WRITE;
/*!40000 ALTER TABLE `lszb_failed_login_attempts` DISABLE KEYS */;
INSERT INTO `lszb_failed_login_attempts` (`id`, `ip`, `last_attempt`, `number_attempts`) VALUES (3,'109.91.35.150','2019-05-03 15:48:12',2),(4,'80.72.254.135','2019-05-05 17:24:08',4),(6,'93.202.105.109','2019-05-07 21:46:14',4),(7,'84.131.183.216','2019-05-08 16:45:04',4),(8,'95.222.19.61','2019-05-08 17:23:03',3);
/*!40000 ALTER TABLE `lszb_failed_login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_groups`
--

DROP TABLE IF EXISTS `lszb_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_groups` (
  `gid` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL DEFAULT '0',
  `group_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `group_order` int(11) NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_unicode_ci,
  `language` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `randomization_group` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `grelevance` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`gid`,`language`),
  KEY `lszb_idx1_groups` (`sid`),
  KEY `lszb_idx2_groups` (`group_name`),
  KEY `lszb_idx3_groups` (`language`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_groups`
--

LOCK TABLES `lszb_groups` WRITE;
/*!40000 ALTER TABLE `lszb_groups` DISABLE KEYS */;
INSERT INTO `lszb_groups` (`gid`, `sid`, `group_name`, `group_order`, `description`, `language`, `randomization_group`, `grelevance`) VALUES (1,632936,'Über mich',0,'','de','',''),(2,632936,'Kurs',1,'Über den Kurs','de','',''),(3,632936,'Programmieren',2,'Programmieren','de','',''),(4,579638,'Über mich',1,'Über mich','de','',''),(5,579638,'Über den Kurs',2,'','de','',''),(15,236889,'Über mich',1,'','de','',''),(13,976696,'Über mich',1,'','de','',''),(14,976696,'Mein Feedback',2,'','de','',''),(11,184888,'Über mich',1,'','de','',''),(12,184888,'Mein Feedback',2,'','de','',''),(16,236889,'Mein Feedback',2,'','de','','');
/*!40000 ALTER TABLE `lszb_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_labels`
--

DROP TABLE IF EXISTS `lszb_labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_labels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL DEFAULT '0',
  `code` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title` text COLLATE utf8mb4_unicode_ci,
  `sortorder` int(11) NOT NULL,
  `language` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `assessment_value` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `lszb_idx1_labels` (`code`),
  KEY `lszb_idx2_labels` (`sortorder`),
  KEY `lszb_idx3_labels` (`language`),
  KEY `lszb_idx4_labels` (`lid`,`sortorder`,`language`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_labels`
--

LOCK TABLES `lszb_labels` WRITE;
/*!40000 ALTER TABLE `lszb_labels` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_labels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_labelsets`
--

DROP TABLE IF EXISTS `lszb_labelsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_labelsets` (
  `lid` int(11) NOT NULL AUTO_INCREMENT,
  `label_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `languages` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT 'en',
  PRIMARY KEY (`lid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_labelsets`
--

LOCK TABLES `lszb_labelsets` WRITE;
/*!40000 ALTER TABLE `lszb_labelsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_labelsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_map_tutorial_users`
--

DROP TABLE IF EXISTS `lszb_map_tutorial_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_map_tutorial_users` (
  `tid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `taken` int(11) DEFAULT '1',
  PRIMARY KEY (`uid`,`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_map_tutorial_users`
--

LOCK TABLES `lszb_map_tutorial_users` WRITE;
/*!40000 ALTER TABLE `lszb_map_tutorial_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_map_tutorial_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_notifications`
--

DROP TABLE IF EXISTS `lszb_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entity` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `importance` int(11) NOT NULL DEFAULT '1',
  `display_class` varchar(31) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `hash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `first_read` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lszb_notifications_pk` (`entity`,`entity_id`,`status`),
  KEY `lszb_idx1_notifications` (`hash`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_notifications`
--

LOCK TABLES `lszb_notifications` WRITE;
/*!40000 ALTER TABLE `lszb_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_old_survey_184888_20190619064108`
--

DROP TABLE IF EXISTS `lszb_old_survey_184888_20190619064108`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_old_survey_184888_20190619064108` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `submitdate` datetime DEFAULT NULL,
  `lastpage` int(11) DEFAULT NULL,
  `startlanguage` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seed` varchar(31) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X11X76` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X11X77` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X11X78` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X79SQ001` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X79SQ002` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X79SQ004` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X79SQ005` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X80SQ007` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X80SQ008` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X80SQ009` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X80SQ010` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X81SQ002` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X81SQ003` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X81SQ004` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X81SQ005` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X81SQ006` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X82` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_old_survey_184888_20190619064108`
--

LOCK TABLES `lszb_old_survey_184888_20190619064108` WRITE;
/*!40000 ALTER TABLE `lszb_old_survey_184888_20190619064108` DISABLE KEYS */;
INSERT INTO `lszb_old_survey_184888_20190619064108` (`id`, `submitdate`, `lastpage`, `startlanguage`, `seed`, `184888X11X76`, `184888X11X77`, `184888X11X78`, `184888X12X79SQ001`, `184888X12X79SQ002`, `184888X12X79SQ004`, `184888X12X79SQ005`, `184888X12X80SQ007`, `184888X12X80SQ008`, `184888X12X80SQ009`, `184888X12X80SQ010`, `184888X12X81SQ002`, `184888X12X81SQ003`, `184888X12X81SQ004`, `184888X12X81SQ005`, `184888X12X81SQ006`, `184888X12X82`) VALUES (1,NULL,1,'de','1027302319','F','A2','A3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,NULL,1,'de','285051722','F','A1','A1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,NULL,1,'de','1241227813','F','A2','A1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,NULL,1,'de','135643703','F','A2','A3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,NULL,1,'de','1859197340','M','A1','A3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,NULL,NULL,'de','367671663',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,NULL,1,'de','1970585181','F','A2','A3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,NULL,1,'de','1815731244','F','A1','A1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(9,NULL,1,'de','262558502','F','A2','A3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `lszb_old_survey_184888_20190619064108` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_old_survey_632936_20190421193442`
--

DROP TABLE IF EXISTS `lszb_old_survey_632936_20190421193442`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_old_survey_632936_20190421193442` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(35) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `submitdate` datetime DEFAULT NULL,
  `lastpage` int(11) DEFAULT NULL,
  `startlanguage` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seed` varchar(31) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `startdate` datetime NOT NULL,
  `datestamp` datetime NOT NULL,
  `refurl` text COLLATE utf8mb4_unicode_ci,
  `632936X1X1` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `632936X1X2` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `632936X1X2comment` text COLLATE utf8mb4_unicode_ci,
  `632936X2X3` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `632936X2X3comment` text COLLATE utf8mb4_unicode_ci,
  `632936X2X4` text COLLATE utf8mb4_unicode_ci,
  `632936X2X5` text COLLATE utf8mb4_unicode_ci,
  `632936X2X6` text COLLATE utf8mb4_unicode_ci,
  `632936X3X7` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_survey_token_632936_1336` (`token`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_old_survey_632936_20190421193442`
--

LOCK TABLES `lszb_old_survey_632936_20190421193442` WRITE;
/*!40000 ALTER TABLE `lszb_old_survey_632936_20190421193442` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_old_survey_632936_20190421193442` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_old_survey_632936_20190421194107`
--

DROP TABLE IF EXISTS `lszb_old_survey_632936_20190421194107`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_old_survey_632936_20190421194107` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(35) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `submitdate` datetime DEFAULT NULL,
  `lastpage` int(11) DEFAULT NULL,
  `startlanguage` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seed` varchar(31) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `632936X1X1` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `632936X1X2` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `632936X1X2comment` text COLLATE utf8mb4_unicode_ci,
  `632936X2X3` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `632936X2X3comment` text COLLATE utf8mb4_unicode_ci,
  `632936X2X4` text COLLATE utf8mb4_unicode_ci,
  `632936X2X5` text COLLATE utf8mb4_unicode_ci,
  `632936X2X6` text COLLATE utf8mb4_unicode_ci,
  `632936X3X7` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_survey_token_632936_5235` (`token`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_old_survey_632936_20190421194107`
--

LOCK TABLES `lszb_old_survey_632936_20190421194107` WRITE;
/*!40000 ALTER TABLE `lszb_old_survey_632936_20190421194107` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_old_survey_632936_20190421194107` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_old_survey_632936_timings_20190421193442`
--

DROP TABLE IF EXISTS `lszb_old_survey_632936_timings_20190421193442`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_old_survey_632936_timings_20190421193442` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `interviewtime` float DEFAULT NULL,
  `632936X1time` float DEFAULT NULL,
  `632936X1X1time` float DEFAULT NULL,
  `632936X1X2time` float DEFAULT NULL,
  `632936X2time` float DEFAULT NULL,
  `632936X2X3time` float DEFAULT NULL,
  `632936X2X4time` float DEFAULT NULL,
  `632936X2X5time` float DEFAULT NULL,
  `632936X2X6time` float DEFAULT NULL,
  `632936X3time` float DEFAULT NULL,
  `632936X3X7time` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_old_survey_632936_timings_20190421193442`
--

LOCK TABLES `lszb_old_survey_632936_timings_20190421193442` WRITE;
/*!40000 ALTER TABLE `lszb_old_survey_632936_timings_20190421193442` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_old_survey_632936_timings_20190421193442` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_old_tokens_184888_20190619064108`
--

DROP TABLE IF EXISTS `lszb_old_tokens_184888_20190619064108`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_old_tokens_184888_20190619064108` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `participant_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `firstname` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` text COLLATE utf8mb4_unicode_ci,
  `emailstatus` text COLLATE utf8mb4_unicode_ci,
  `token` varchar(35) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `language` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blacklisted` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sent` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `remindersent` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `remindercount` int(11) DEFAULT '0',
  `completed` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `usesleft` int(11) DEFAULT '1',
  `validfrom` datetime DEFAULT NULL,
  `validuntil` datetime DEFAULT NULL,
  `mpid` int(11) DEFAULT NULL,
  PRIMARY KEY (`tid`),
  KEY `idx_token_token_184888_40789` (`token`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_old_tokens_184888_20190619064108`
--

LOCK TABLES `lszb_old_tokens_184888_20190619064108` WRITE;
/*!40000 ALTER TABLE `lszb_old_tokens_184888_20190619064108` DISABLE KEYS */;
INSERT INTO `lszb_old_tokens_184888_20190619064108` (`tid`, `participant_id`, `firstname`, `lastname`, `email`, `emailstatus`, `token`, `language`, `blacklisted`, `sent`, `remindersent`, `remindercount`, `completed`, `usesleft`, `validfrom`, `validuntil`, `mpid`) VALUES (1,NULL,'','','','OK','emathe','de',NULL,'N','N',0,'N',1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `lszb_old_tokens_184888_20190619064108` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_old_tokens_632936_20190421193442`
--

DROP TABLE IF EXISTS `lszb_old_tokens_632936_20190421193442`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_old_tokens_632936_20190421193442` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `participant_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `firstname` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` text COLLATE utf8mb4_unicode_ci,
  `emailstatus` text COLLATE utf8mb4_unicode_ci,
  `token` varchar(35) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `language` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blacklisted` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sent` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `remindersent` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `remindercount` int(11) DEFAULT '0',
  `completed` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `usesleft` int(11) DEFAULT '1',
  `validfrom` datetime DEFAULT NULL,
  `validuntil` datetime DEFAULT NULL,
  `mpid` int(11) DEFAULT NULL,
  PRIMARY KEY (`tid`),
  KEY `idx_token_token_632936_32004` (`token`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_old_tokens_632936_20190421193442`
--

LOCK TABLES `lszb_old_tokens_632936_20190421193442` WRITE;
/*!40000 ALTER TABLE `lszb_old_tokens_632936_20190421193442` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_old_tokens_632936_20190421193442` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_participant_attribute`
--

DROP TABLE IF EXISTS `lszb_participant_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_participant_attribute` (
  `participant_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_id` int(11) NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`participant_id`,`attribute_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_participant_attribute`
--

LOCK TABLES `lszb_participant_attribute` WRITE;
/*!40000 ALTER TABLE `lszb_participant_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_participant_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_participant_attribute_names`
--

DROP TABLE IF EXISTS `lszb_participant_attribute_names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_participant_attribute_names` (
  `attribute_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_type` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `defaultname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visible` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`attribute_id`,`attribute_type`),
  KEY `lszb_idx_participant_attribute_names` (`attribute_id`,`attribute_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_participant_attribute_names`
--

LOCK TABLES `lszb_participant_attribute_names` WRITE;
/*!40000 ALTER TABLE `lszb_participant_attribute_names` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_participant_attribute_names` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_participant_attribute_names_lang`
--

DROP TABLE IF EXISTS `lszb_participant_attribute_names_lang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_participant_attribute_names_lang` (
  `attribute_id` int(11) NOT NULL,
  `attribute_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`attribute_id`,`lang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_participant_attribute_names_lang`
--

LOCK TABLES `lszb_participant_attribute_names_lang` WRITE;
/*!40000 ALTER TABLE `lszb_participant_attribute_names_lang` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_participant_attribute_names_lang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_participant_attribute_values`
--

DROP TABLE IF EXISTS `lszb_participant_attribute_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_participant_attribute_values` (
  `value_id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`value_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_participant_attribute_values`
--

LOCK TABLES `lszb_participant_attribute_values` WRITE;
/*!40000 ALTER TABLE `lszb_participant_attribute_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_participant_attribute_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_participant_shares`
--

DROP TABLE IF EXISTS `lszb_participant_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_participant_shares` (
  `participant_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `share_uid` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  `can_edit` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`participant_id`,`share_uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_participant_shares`
--

LOCK TABLES `lszb_participant_shares` WRITE;
/*!40000 ALTER TABLE `lszb_participant_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_participant_shares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_participants`
--

DROP TABLE IF EXISTS `lszb_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_participants` (
  `participant_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` text COLLATE utf8mb4_unicode_ci,
  `language` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blacklisted` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_uid` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`participant_id`),
  KEY `lszb_idx1_participants` (`firstname`),
  KEY `lszb_idx2_participants` (`lastname`),
  KEY `lszb_idx3_participants` (`language`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_participants`
--

LOCK TABLES `lszb_participants` WRITE;
/*!40000 ALTER TABLE `lszb_participants` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_permissions`
--

DROP TABLE IF EXISTS `lszb_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entity` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `permission` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `create_p` int(11) NOT NULL DEFAULT '0',
  `read_p` int(11) NOT NULL DEFAULT '0',
  `update_p` int(11) NOT NULL DEFAULT '0',
  `delete_p` int(11) NOT NULL DEFAULT '0',
  `import_p` int(11) NOT NULL DEFAULT '0',
  `export_p` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `lszb_idx1_permissions` (`entity_id`,`entity`,`permission`,`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_permissions`
--

LOCK TABLES `lszb_permissions` WRITE;
/*!40000 ALTER TABLE `lszb_permissions` DISABLE KEYS */;
INSERT INTO `lszb_permissions` (`id`, `entity`, `entity_id`, `uid`, `permission`, `create_p`, `read_p`, `update_p`, `delete_p`, `import_p`, `export_p`) VALUES (1,'global',0,1,'superadmin',0,1,0,0,0,0),(2,'survey',632936,1,'responses',1,1,1,1,1,1),(3,'survey',632936,1,'assessments',1,1,1,1,0,0),(4,'survey',632936,1,'translations',0,1,1,0,0,0),(5,'survey',632936,1,'statistics',0,1,0,0,0,0),(6,'survey',632936,1,'quotas',1,1,1,1,0,0),(7,'survey',632936,1,'survey',0,1,0,1,0,0),(8,'survey',632936,1,'surveysettings',0,1,1,0,0,0),(9,'survey',632936,1,'surveysecurity',1,1,1,1,0,0),(10,'survey',632936,1,'surveylocale',0,1,1,0,0,0),(11,'survey',632936,1,'surveyactivation',0,0,1,0,0,0),(12,'survey',632936,1,'surveycontent',1,1,1,1,1,1),(13,'survey',632936,1,'tokens',1,1,1,1,1,1),(14,'survey',579638,1,'responses',1,1,1,1,1,1),(15,'survey',579638,1,'assessments',1,1,1,1,0,0),(16,'survey',579638,1,'translations',0,1,1,0,0,0),(17,'survey',579638,1,'statistics',0,1,0,0,0,0),(18,'survey',579638,1,'quotas',1,1,1,1,0,0),(19,'survey',579638,1,'survey',0,1,0,1,0,0),(20,'survey',579638,1,'surveysettings',0,1,1,0,0,0),(21,'survey',579638,1,'surveysecurity',1,1,1,1,0,0),(22,'survey',579638,1,'surveylocale',0,1,1,0,0,0),(23,'survey',579638,1,'surveyactivation',0,0,1,0,0,0),(24,'survey',579638,1,'surveycontent',1,1,1,1,1,1),(25,'survey',579638,1,'tokens',1,1,1,1,1,1),(78,'survey',236889,1,'quotas',1,1,1,1,0,0),(77,'survey',236889,1,'statistics',0,1,0,0,0,0),(76,'survey',236889,1,'translations',0,1,1,0,0,0),(75,'survey',236889,1,'assessments',1,1,1,1,0,0),(74,'survey',236889,1,'responses',1,1,1,1,1,1),(73,'survey',976696,1,'tokens',1,1,1,1,1,1),(62,'survey',976696,1,'responses',1,1,1,1,1,1),(63,'survey',976696,1,'assessments',1,1,1,1,0,0),(64,'survey',976696,1,'translations',0,1,1,0,0,0),(65,'survey',976696,1,'statistics',0,1,0,0,0,0),(66,'survey',976696,1,'quotas',1,1,1,1,0,0),(67,'survey',976696,1,'survey',0,1,0,1,0,0),(68,'survey',976696,1,'surveysettings',0,1,1,0,0,0),(69,'survey',976696,1,'surveysecurity',1,1,1,1,0,0),(70,'survey',976696,1,'surveylocale',0,1,1,0,0,0),(71,'survey',976696,1,'surveyactivation',0,0,1,0,0,0),(72,'survey',976696,1,'surveycontent',1,1,1,1,1,1),(50,'survey',184888,1,'responses',1,1,1,1,1,1),(51,'survey',184888,1,'assessments',1,1,1,1,0,0),(52,'survey',184888,1,'translations',0,1,1,0,0,0),(53,'survey',184888,1,'statistics',0,1,0,0,0,0),(54,'survey',184888,1,'quotas',1,1,1,1,0,0),(55,'survey',184888,1,'survey',0,1,0,1,0,0),(56,'survey',184888,1,'surveysettings',0,1,1,0,0,0),(57,'survey',184888,1,'surveysecurity',1,1,1,1,0,0),(58,'survey',184888,1,'surveylocale',0,1,1,0,0,0),(59,'survey',184888,1,'surveyactivation',0,0,1,0,0,0),(60,'survey',184888,1,'surveycontent',1,1,1,1,1,1),(61,'survey',184888,1,'tokens',1,1,1,1,1,1),(79,'survey',236889,1,'survey',0,1,0,1,0,0),(80,'survey',236889,1,'surveysettings',0,1,1,0,0,0),(81,'survey',236889,1,'surveysecurity',1,1,1,1,0,0),(82,'survey',236889,1,'surveylocale',0,1,1,0,0,0),(83,'survey',236889,1,'surveyactivation',0,0,1,0,0,0),(84,'survey',236889,1,'surveycontent',1,1,1,1,1,1),(85,'survey',236889,1,'tokens',1,1,1,1,1,1);
/*!40000 ALTER TABLE `lszb_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_plugin_settings`
--

DROP TABLE IF EXISTS `lszb_plugin_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_plugin_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plugin_id` int(11) NOT NULL,
  `model` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `key` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_plugin_settings`
--

LOCK TABLES `lszb_plugin_settings` WRITE;
/*!40000 ALTER TABLE `lszb_plugin_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_plugin_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_plugins`
--

DROP TABLE IF EXISTS `lszb_plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  `version` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_plugins`
--

LOCK TABLES `lszb_plugins` WRITE;
/*!40000 ALTER TABLE `lszb_plugins` DISABLE KEYS */;
INSERT INTO `lszb_plugins` (`id`, `name`, `active`, `version`) VALUES (1,'Authdb',1,NULL),(2,'AuditLog',0,NULL),(3,'AuthLDAP',0,NULL),(4,'Authwebserver',1,NULL),(5,'ExportR',0,NULL),(6,'ExportSTATAxml',0,NULL),(7,'oldUrlCompat',0,NULL);
/*!40000 ALTER TABLE `lszb_plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_question_attributes`
--

DROP TABLE IF EXISTS `lszb_question_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_question_attributes` (
  `qaid` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL DEFAULT '0',
  `attribute` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `language` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`qaid`),
  KEY `lszb_idx1_question_attributes` (`qid`),
  KEY `lszb_idx2_question_attributes` (`attribute`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_question_attributes`
--

LOCK TABLES `lszb_question_attributes` WRITE;
/*!40000 ALTER TABLE `lszb_question_attributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_question_attributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_questions`
--

DROP TABLE IF EXISTS `lszb_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_questions` (
  `qid` int(11) NOT NULL AUTO_INCREMENT,
  `parent_qid` int(11) NOT NULL DEFAULT '0',
  `sid` int(11) NOT NULL DEFAULT '0',
  `gid` int(11) NOT NULL DEFAULT '0',
  `type` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'T',
  `title` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `question` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `preg` text COLLATE utf8mb4_unicode_ci,
  `help` text COLLATE utf8mb4_unicode_ci,
  `other` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `mandatory` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `question_order` int(11) NOT NULL,
  `language` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `scale_id` int(11) NOT NULL DEFAULT '0',
  `same_default` int(11) NOT NULL DEFAULT '0',
  `relevance` text COLLATE utf8mb4_unicode_ci,
  `modulename` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`qid`,`language`),
  KEY `lszb_idx1_questions` (`sid`),
  KEY `lszb_idx2_questions` (`gid`),
  KEY `lszb_idx3_questions` (`type`),
  KEY `lszb_idx4_questions` (`title`),
  KEY `lszb_idx5_questions` (`parent_qid`)
) ENGINE=MyISAM AUTO_INCREMENT=173 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_questions`
--

LOCK TABLES `lszb_questions` WRITE;
/*!40000 ALTER TABLE `lszb_questions` DISABLE KEYS */;
INSERT INTO `lszb_questions` (`qid`, `parent_qid`, `sid`, `gid`, `type`, `title`, `question`, `preg`, `help`, `other`, `mandatory`, `question_order`, `language`, `scale_id`, `same_default`, `relevance`, `modulename`) VALUES (1,0,632936,1,'G','geschlecht','Mein Geschlecht:','','','N','N',1,'de',0,0,'1',''),(2,0,632936,1,'O','Vorerfahrungen','Das waren meine Programmierkenntnisse vor Beginn des Kurses','','','N','Y',2,'de',0,0,'1',''),(3,0,632936,2,'O','neueerfahrungen','Soviel habe ich im Kurs gelernt','','','N','Y',1,'de',0,0,'1',NULL),(4,0,632936,2,'T','gut','Das fand ich am Kurs besonders gut!','','','N','Y',2,'de',0,0,'1',NULL),(5,0,632936,2,'T','mehr','Davon wünsche ich mir mehr/weniger:','','','N','Y',3,'de',0,0,'1',NULL),(6,0,632936,2,'T','unterricht','<p>(Nur für Schüler der CWS) Das hat mir am Unterricht gefallen/nicht gefallen. Davon wünsche ich mir mehr/weniger:</p>\r\n\r\n<p><em><strong>Hinweis</strong>: Ziel des Kurses ist es, das systematische Lernen in die Hausaufgaben zu verlegen, wo jeder so viel Zeit investieren kann, wie er braucht. Im Unterricht sollen dafür öfters auch Anwendungsbeispiele aufgezeigt werden, mehr experimentiert und mehr \"gespielt\" werden. Du darfst an dieser Stelle gerne angeben, wie gut dieses Konzept zu dir passt, was dir beim Lernen geholfen hat, und wovon du mehr bräuchtest.</em></p>\r\n','','','N','N',4,'de',0,0,'1',NULL),(7,0,632936,3,'T','programmierenbedeute','<p>Das verstehe ich bis jetzt unter dem Wort \"Programmieren\".</p>\r\n','','','N','Y',1,'de',0,0,'1',NULL),(8,0,579638,4,'G','geschlecht','Mein Geschlecht','','','N','N',0,'de',0,0,'1',NULL),(9,0,579638,4,'O','vorerfahrungen','So würde ich meine allgemeine Informatikvorerfahrungen <strong>vor</strong> dem Kurs beschreiben','','','N','Y',2,'de',0,0,'1',''),(10,0,579638,4,'Y','cws','Ich bin Schüler*in der CWS...','','','N','Y',1,'de',0,0,'1',''),(11,0,579638,5,'O','neugelernt','Soviel habe ich im Kurs gelernt','','','N','Y',0,'de',0,0,'1',''),(12,0,579638,5,'O','aufgaben','Die Aufgaben im Kurs waren...','','','N','Y',1,'de',0,0,'1',''),(13,0,579638,5,'T','gut','Das fand ich am Kurs besonders gut.','','','N','Y',2,'de',0,0,'1',''),(14,0,579638,5,'T','mehr','Davon wünsche ich mir im Kurs mehr/weniger','','','N','Y',3,'de',0,0,'1',NULL),(136,113,976696,14,'T','77500','Ich werde im Unterricht gefordert ',NULL,NULL,'N','N',9,'de',0,0,'1',''),(135,113,976696,14,'T','72615','Klassenarbeiten sind zu schwer ',NULL,NULL,'N','N',8,'de',0,0,'1',''),(133,113,976696,14,'T','SQ012','Das Unterrichtstempo ist zu langsam ',NULL,NULL,'N','N',6,'de',0,0,'1',''),(134,113,976696,14,'T','80432','Die Schwierigkeiten der Klassenarbeiten ist angemessen ',NULL,NULL,'N','N',7,'de',0,0,'1',''),(132,113,976696,14,'T','SQ013','Das Unterrichtstempo ist zu schnell ',NULL,NULL,'N','N',5,'de',0,0,'1',''),(130,112,976696,14,'T','SQ011','Der Lehrer kann gut erklären',NULL,NULL,'N','N',6,'de',0,0,'1',NULL),(131,112,976696,14,'T','SQ012','Der Lehrer ist gerecht',NULL,NULL,'N','N',7,'de',0,0,'1',NULL),(126,112,976696,14,'T','SQ007','Der Lehrer hält es für wichtig, dass wir etwas lernen.',NULL,NULL,'N','N',2,'de',0,0,'1',NULL),(127,112,976696,14,'T','SQ008','Der Lehrer traut uns etwas zu.',NULL,NULL,'N','N',3,'de',0,0,'1',NULL),(128,112,976696,14,'T','SQ009','Der Lehrer nimmt unsere Anliegen ernst',NULL,NULL,'N','N',4,'de',0,0,'1',NULL),(129,112,976696,14,'T','SQ010','Der Lehrer gestaltet den Unterricht interesant',NULL,NULL,'N','N',5,'de',0,0,'1',NULL),(142,0,236889,15,'L','selbsteinschaetzung','Schätze deine eigene Leistung im Matheunterricht ein:','','','N','Y',1,'de',0,0,'1',''),(123,114,976696,14,'T','SQ005','Vorstellen von Aufgaben durch Schüler (z.B. Hausaufgaben)',NULL,NULL,'N','N',4,'de',0,0,'1',''),(124,114,976696,14,'T','SQ006','Eigenes Erarbeiten von neuen Themen',NULL,NULL,'N','N',5,'de',0,0,'1',''),(125,112,976696,14,'T','SQ006','Der Lehrer hat einen Überblick über das Klassengeschehen.',NULL,NULL,'N','N',1,'de',0,0,'1',NULL),(141,0,236889,15,'G','geschlecht','Gebe dein Geschlecht an','','','N','N',0,'de',0,0,'1',''),(139,114,976696,14,'T','SQ008','Lerntheken',NULL,NULL,'N',NULL,7,'de',0,0,'1',''),(140,114,976696,14,'T','SQ009','Kopfübungen (wie in den letzten Stunden)',NULL,NULL,'N',NULL,8,'de',0,0,'1',''),(122,114,976696,14,'T','SQ004','Erklärungen an der Tafel durch den Lehrer',NULL,NULL,'N','N',3,'de',0,0,'1',''),(121,114,976696,14,'T','SQ003','Partnerarbeit',NULL,NULL,'N','N',2,'de',0,0,'1',''),(120,114,976696,14,'T','SQ002','Gruppenarbeit',NULL,NULL,'N','N',1,'de',0,0,'1',''),(119,113,976696,14,'F','SQ010','Bei Schwierigkeiten wird mir geholfen ',NULL,NULL,'N','N',4,'de',0,0,'1',''),(137,113,976696,14,'T','SQ011','Ich habe im Unterricht viel gelernt ',NULL,NULL,'N','N',10,'de',0,0,'1',''),(138,114,976696,14,'T','SQ007','Langzeithausaufgaben (wie im ersten Halbjahr über eine Woche)',NULL,NULL,'N',NULL,6,'de',0,0,'1',''),(118,113,976696,14,'F','SQ009','Neue Themen werden verständlich eingeführt ',NULL,NULL,'N','N',3,'de',0,0,'1',''),(117,113,976696,14,'F','SQ008','Der Unterricht ist abwechslungsreich ',NULL,NULL,'N','N',2,'de',0,0,'1',''),(116,113,976696,14,'F','SQ007','Ich verstehe die Inhalte im Unterricht ',NULL,NULL,'N','N',1,'de',0,0,'1',''),(109,0,976696,13,'G','geschlecht','Gebe dein Geschlecht an','','','N','N',0,'de',0,0,'1',''),(110,0,976696,13,'L','selbsteinschaetzung','Schätze deine eigene Leistung im Matheunterricht ein:','','','N','Y',1,'de',0,0,'1',''),(111,0,976696,13,'L','vorwissen','Schätze dein Vorwissen ein.','','','N','N',2,'de',0,0,'1',NULL),(112,0,976696,14,'F','bewertung','Bewerte deinen Lehrer','','','N','Y',0,'de',0,0,'1',''),(113,0,976696,14,'F','Unterricht','Bewerte den Unterricht','','','N','Y',1,'de',0,0,'1',''),(114,0,976696,14,'E','mehrweniger','Gebe an, wovon du dir mehr/weniger wünschst','','','N','Y',2,'de',0,0,'1',''),(115,0,976696,14,'T','eigenes','Hier ist Platz für weitere eigene Anmerkungen. Was möchtest du gerne noch loswerden?','','','N','N',3,'de',0,0,'1',''),(76,0,184888,11,'G','geschlecht','Gebe dein Geschlecht an','','','N','N',0,'de',0,0,'1',''),(77,0,184888,11,'L','selbsteinschaetzung','Schätze deine eigene Leistung im Matheunterricht ein:','','','N','Y',1,'de',0,0,'1',''),(78,0,184888,11,'L','vorwissen','Schätze dein Vorwissen ein.','','','N','N',2,'de',0,0,'1',NULL),(79,0,184888,12,'F','bewertung','Bewerte deinen Lehrer','','','N','Y',0,'de',0,0,'1',''),(80,0,184888,12,'F','Unterricht','Bewerte den Unterricht','','','N','Y',1,'de',0,0,'1',''),(81,0,184888,12,'E','mehrweniger','Gebe an, wovon du dir mehr/weniger wünschst','','','N','Y',2,'de',0,0,'1',''),(82,0,184888,12,'T','eigenes','Hier ist Platz für weitere eigene Anmerkungen. Was möchtest du gerne noch loswerden?','','','N','N',3,'de',0,0,'1',''),(96,79,184888,12,'T','SQ006','Der Lehrer hat einen Überblick über das Klassengeschehen.',NULL,NULL,'N',NULL,1,'de',0,0,'1',NULL),(97,79,184888,12,'T','SQ007','Der Lehrer hält es für wichtig, dass wir etwas lernen.',NULL,NULL,'N',NULL,2,'de',0,0,'1',NULL),(86,80,184888,12,'F','SQ007','Ich verstehe die Inhalte im Unterricht ',NULL,NULL,'N','N',1,'de',0,0,'1',''),(87,80,184888,12,'F','SQ008','Der Unterricht ist abwechslungsreich ',NULL,NULL,'N','N',2,'de',0,0,'1',''),(88,80,184888,12,'F','SQ009','Neue Themen werden verständlich eingeführt ',NULL,NULL,'N','N',3,'de',0,0,'1',''),(89,80,184888,12,'F','SQ010','Bei Schwierigkeiten wird mir geholfen ',NULL,NULL,'N','N',4,'de',0,0,'1',''),(90,81,184888,12,'T','SQ002','Gruppenarbeit',NULL,NULL,'N','N',1,'de',0,0,'1',''),(92,81,184888,12,'T','SQ003','Partnerarbeit',NULL,NULL,'N','N',2,'de',0,0,'1',NULL),(93,81,184888,12,'T','SQ004','Erklärungen an der Tafel',NULL,NULL,'N','N',3,'de',0,0,'1',NULL),(94,81,184888,12,'T','SQ005','Vorstellen von Aufgaben',NULL,NULL,'N','N',4,'de',0,0,'1',NULL),(95,81,184888,12,'T','SQ006','Geogebra',NULL,NULL,'N','N',5,'de',0,0,'1',NULL),(98,79,184888,12,'T','SQ008','Der Lehrer traut uns etwas zu.',NULL,NULL,'N',NULL,3,'de',0,0,'1',NULL),(99,79,184888,12,'T','SQ009','Der Lehrer nimmt unsere Anliegen ernst',NULL,NULL,'N',NULL,4,'de',0,0,'1',NULL),(100,79,184888,12,'T','SQ010','Der Lehrer gestaltet den Unterricht interesant',NULL,NULL,'N',NULL,5,'de',0,0,'1',NULL),(101,79,184888,12,'T','SQ011','Der Lehrer kann gut erklären',NULL,NULL,'N',NULL,6,'de',0,0,'1',NULL),(102,79,184888,12,'T','SQ012','Der Lehrer ist gerecht',NULL,NULL,'N',NULL,7,'de',0,0,'1',NULL),(103,80,184888,12,'T','SQ013','Das Unterrichtstempo ist zu schnell ',NULL,NULL,'N',NULL,5,'de',0,0,'1',NULL),(104,80,184888,12,'T','SQ012','Das Unterrichtstempo ist zu langsam ',NULL,NULL,'N',NULL,6,'de',0,0,'1',NULL),(105,80,184888,12,'T','80432','Die Schwierigkeiten der Klassenarbeiten ist angemessen ',NULL,NULL,'N',NULL,7,'de',0,0,'1',NULL),(106,80,184888,12,'T','72615','Klassenarbeiten sind zu schwer ',NULL,NULL,'N',NULL,8,'de',0,0,'1',NULL),(107,80,184888,12,'T','77500','Ich werde im Unterricht gefordert ',NULL,NULL,'N',NULL,9,'de',0,0,'1',NULL),(108,80,184888,12,'T','SQ011','Ich habe im Unterricht viel gelernt ',NULL,NULL,'N',NULL,10,'de',0,0,'1',NULL),(143,0,236889,15,'L','vorwissen','Schätze dein Vorwissen ein.','','','N','N',2,'de',0,0,'1',NULL),(144,0,236889,16,'F','bewertung','Bewerte deinen Lehrer','','','N','Y',0,'de',0,0,'1',''),(145,0,236889,16,'F','Unterricht','Bewerte den Unterricht','','','N','Y',1,'de',0,0,'1',''),(146,0,236889,16,'E','mehrweniger','Gebe an, wovon du dir mehr/weniger wünschst','','','N','Y',2,'de',0,0,'1',''),(147,0,236889,16,'T','eigenes','Hier ist Platz für weitere eigene Anmerkungen. Was möchtest du gerne noch loswerden?','','','N','N',3,'de',0,0,'1',''),(148,145,236889,16,'F','SQ007','Ich verstehe die Inhalte im Unterricht ',NULL,NULL,'N','N',1,'de',0,0,'1',''),(149,145,236889,16,'F','SQ008','Der Unterricht ist abwechslungsreich ',NULL,NULL,'N','N',2,'de',0,0,'1',''),(150,145,236889,16,'F','SQ009','Neue Themen werden verständlich eingeführt ',NULL,NULL,'N','N',3,'de',0,0,'1',''),(151,145,236889,16,'F','SQ010','Bei Schwierigkeiten wird mir geholfen ',NULL,NULL,'N','N',4,'de',0,0,'1',''),(152,146,236889,16,'T','SQ002','Gruppenarbeit',NULL,NULL,'N','N',1,'de',0,0,'1',''),(153,146,236889,16,'T','SQ003','Partnerarbeit',NULL,NULL,'N','N',2,'de',0,0,'1',''),(154,146,236889,16,'T','SQ004','Erklärungen an der Tafel',NULL,NULL,'N','N',3,'de',0,0,'1',''),(155,146,236889,16,'T','SQ005','Vorstellen von Aufgaben an der Tafel durch Schüler',NULL,NULL,'N','N',4,'de',0,0,'1',''),(157,144,236889,16,'T','SQ006','Der Lehrer hat einen Überblick über das Klassengeschehen.',NULL,NULL,'N','N',1,'de',0,0,'1',NULL),(158,144,236889,16,'T','SQ007','Der Lehrer hält es für wichtig, dass wir etwas lernen.',NULL,NULL,'N','N',2,'de',0,0,'1',NULL),(159,144,236889,16,'T','SQ008','Der Lehrer traut uns etwas zu.',NULL,NULL,'N','N',3,'de',0,0,'1',NULL),(160,144,236889,16,'T','SQ009','Der Lehrer nimmt unsere Anliegen ernst',NULL,NULL,'N','N',4,'de',0,0,'1',NULL),(161,144,236889,16,'T','SQ010','Der Lehrer gestaltet den Unterricht interesant',NULL,NULL,'N','N',5,'de',0,0,'1',NULL),(162,144,236889,16,'T','SQ011','Der Lehrer kann gut erklären',NULL,NULL,'N','N',6,'de',0,0,'1',NULL),(163,144,236889,16,'T','SQ012','Der Lehrer ist gerecht',NULL,NULL,'N','N',7,'de',0,0,'1',NULL),(164,145,236889,16,'T','SQ013','Das Unterrichtstempo ist zu schnell ',NULL,NULL,'N','N',5,'de',0,0,'1',NULL),(165,145,236889,16,'T','SQ012','Das Unterrichtstempo ist zu langsam ',NULL,NULL,'N','N',6,'de',0,0,'1',NULL),(166,145,236889,16,'T','80432','Die Schwierigkeiten der Klassenarbeiten ist angemessen ',NULL,NULL,'N','N',7,'de',0,0,'1',NULL),(167,145,236889,16,'T','72615','Klassenarbeiten sind zu schwer ',NULL,NULL,'N','N',8,'de',0,0,'1',NULL),(168,145,236889,16,'T','77500','Ich werde im Unterricht gefordert ',NULL,NULL,'N','N',9,'de',0,0,'1',NULL),(169,145,236889,16,'T','SQ011','Ich habe im Unterricht viel gelernt ',NULL,NULL,'N','N',10,'de',0,0,'1',NULL),(171,146,236889,16,'T','SQ008','Lerntheken',NULL,NULL,'N','N',5,'de',0,0,'1',''),(172,146,236889,16,'T','SQ009','Kopfübungen (wie in den letzten Stunden)',NULL,NULL,'N','N',6,'de',0,0,'1','');
/*!40000 ALTER TABLE `lszb_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_quota`
--

DROP TABLE IF EXISTS `lszb_quota`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_quota` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qlimit` int(11) DEFAULT NULL,
  `action` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `autoload_url` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `lszb_idx1_quota` (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_quota`
--

LOCK TABLES `lszb_quota` WRITE;
/*!40000 ALTER TABLE `lszb_quota` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_quota` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_quota_languagesettings`
--

DROP TABLE IF EXISTS `lszb_quota_languagesettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_quota_languagesettings` (
  `quotals_id` int(11) NOT NULL AUTO_INCREMENT,
  `quotals_quota_id` int(11) NOT NULL DEFAULT '0',
  `quotals_language` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `quotals_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quotals_message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `quotals_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quotals_urldescrip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`quotals_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_quota_languagesettings`
--

LOCK TABLES `lszb_quota_languagesettings` WRITE;
/*!40000 ALTER TABLE `lszb_quota_languagesettings` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_quota_languagesettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_quota_members`
--

DROP TABLE IF EXISTS `lszb_quota_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_quota_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) DEFAULT NULL,
  `qid` int(11) DEFAULT NULL,
  `quota_id` int(11) DEFAULT NULL,
  `code` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lszb_idx1_quota_members` (`sid`,`qid`,`quota_id`,`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_quota_members`
--

LOCK TABLES `lszb_quota_members` WRITE;
/*!40000 ALTER TABLE `lszb_quota_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_quota_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_saved_control`
--

DROP TABLE IF EXISTS `lszb_saved_control`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_saved_control` (
  `scid` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL DEFAULT '0',
  `srid` int(11) NOT NULL DEFAULT '0',
  `identifier` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_code` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(192) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `saved_thisstep` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `saved_date` datetime NOT NULL,
  `refurl` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`scid`),
  KEY `lszb_idx1_saved_control` (`sid`),
  KEY `lszb_idx2_saved_control` (`srid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_saved_control`
--

LOCK TABLES `lszb_saved_control` WRITE;
/*!40000 ALTER TABLE `lszb_saved_control` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_saved_control` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_sessions`
--

DROP TABLE IF EXISTS `lszb_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_sessions` (
  `id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expire` int(11) DEFAULT NULL,
  `data` blob,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_sessions`
--

LOCK TABLES `lszb_sessions` WRITE;
/*!40000 ALTER TABLE `lszb_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_settings_global`
--

DROP TABLE IF EXISTS `lszb_settings_global`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_settings_global` (
  `stg_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `stg_value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`stg_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_settings_global`
--

LOCK TABLES `lszb_settings_global` WRITE;
/*!40000 ALTER TABLE `lszb_settings_global` DISABLE KEYS */;
INSERT INTO `lszb_settings_global` (`stg_name`, `stg_value`) VALUES ('DBVersion','356'),('SessionName','qeuzvsqxaz2szg9gszb5pfntbxke3qf3buepbd16nuarey5e533ai2z9uooo199u'),('sitename','Lime Survey'),('siteadminname','Administrator'),('siteadminemail','admin@survey.cws-lernen.de'),('siteadminbounce','admin@survey.cws-lernen.de'),('defaultlang','de'),('AssetsVersion','30081'),('show_logo','hide'),('last_survey_1','976696'),('last_question_1','114'),('last_question_sid_1','976696'),('last_question_gid_1','14'),('last_question_1_632936','2'),('last_question_1_632936_gid','1'),('last_question_1_579638','14'),('last_question_1_579638_gid','4'),('last_question_1_976696_gid','14'),('last_question_1_976696','114'),('last_question_1_184888','80'),('last_question_1_184888_gid','12'),('last_question_1_236889','146'),('last_question_1_236889_gid','16');
/*!40000 ALTER TABLE `lszb_settings_global` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_settings_user`
--

DROP TABLE IF EXISTS `lszb_settings_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_settings_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `entity` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` varchar(31) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stg_name` varchar(63) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stg_value` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `lszb_idx1_settings_user` (`uid`),
  KEY `lszb_idx2_settings_user` (`entity`),
  KEY `lszb_idx3_settings_user` (`entity_id`),
  KEY `lszb_idx4_settings_user` (`stg_name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_settings_user`
--

LOCK TABLES `lszb_settings_user` WRITE;
/*!40000 ALTER TABLE `lszb_settings_user` DISABLE KEYS */;
INSERT INTO `lszb_settings_user` (`id`, `uid`, `entity`, `entity_id`, `stg_name`, `stg_value`) VALUES (1,1,NULL,NULL,'quickaction_state','1');
/*!40000 ALTER TABLE `lszb_settings_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_survey_184888`
--

DROP TABLE IF EXISTS `lszb_survey_184888`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_survey_184888` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `submitdate` datetime DEFAULT NULL,
  `lastpage` int(11) DEFAULT NULL,
  `startlanguage` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seed` varchar(31) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X11X76` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X11X77` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X11X78` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X79SQ006` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X79SQ007` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X79SQ008` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X79SQ009` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X79SQ010` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X79SQ011` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X79SQ012` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X80SQ007` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X80SQ008` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X80SQ009` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X80SQ010` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X80SQ013` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X80SQ012` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X8080432` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X8072615` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X8077500` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X80SQ011` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X81SQ002` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X81SQ003` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X81SQ004` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X81SQ005` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X81SQ006` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `184888X12X82` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_survey_184888`
--

LOCK TABLES `lszb_survey_184888` WRITE;
/*!40000 ALTER TABLE `lszb_survey_184888` DISABLE KEYS */;
INSERT INTO `lszb_survey_184888` (`id`, `submitdate`, `lastpage`, `startlanguage`, `seed`, `184888X11X76`, `184888X11X77`, `184888X11X78`, `184888X12X79SQ006`, `184888X12X79SQ007`, `184888X12X79SQ008`, `184888X12X79SQ009`, `184888X12X79SQ010`, `184888X12X79SQ011`, `184888X12X79SQ012`, `184888X12X80SQ007`, `184888X12X80SQ008`, `184888X12X80SQ009`, `184888X12X80SQ010`, `184888X12X80SQ013`, `184888X12X80SQ012`, `184888X12X8080432`, `184888X12X8072615`, `184888X12X8077500`, `184888X12X80SQ011`, `184888X12X81SQ002`, `184888X12X81SQ003`, `184888X12X81SQ004`, `184888X12X81SQ005`, `184888X12X81SQ006`, `184888X12X82`) VALUES (10,NULL,NULL,'de','416914917',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,'1980-01-01 00:00:00',2,'de','676442498','M','A2','A1','A2','A1','A1','A1','A3','A3','A1','A2','A2','A3','A2','A3','A5','A2','A5','A1','A2','S','D','I','S','I','Danke für ein gutes Mathe-Halbjahr, ihr Unterricht gefällt mir vorwiegend weil Sie auch neue digitalisierte Unterrichtsmethoden einbringen und nicht immer nur strikt nach alten Mustern arbeiten. Die Einführung in verschiedene Themen war teils gut, teils aber auch etwas trist. Ich rate Ihnen, mehr Einstiege wie beispielsweise das Basteln eines Würfels zur Einführung in die Optimierungsaufgaben zu nutzen. Ich hoffe, wir werden Sie als Lehrer im nächsten Jahr behalten. '),(12,'1980-01-01 00:00:00',2,'de','528003906','F','A2','A3','A2','A1','A1','A1','A3','A2','A1','A3','A3','A3','A3','A5','A5','A6','A1','A2','A1','S','I','S','I','I',''),(13,'1980-01-01 00:00:00',2,'de','2000933465','F','A2','A3','A2','A1','A1','A2','A3','A3','A1','A3','A2','A2','A1','A3','A6','A2','A5','A1','A2','S','I','I','S','S',''),(14,'1980-01-01 00:00:00',2,'de','1421614850','F','A1','A1','A3','A1','A1','A1','A3','A4','A1','A2','A3','A2','A1','A6','A6','A2','A5','A1','A2','I','S','I','D','I',''),(15,'1980-01-01 00:00:00',2,'de','2050458316','F','A2','A3','A2','A1','A1','A1','A3','A2','A1','A3','A3','A2','A1','A5','A5','A2','A5','A1','A1','S','I','S','S','S',''),(16,'1980-01-01 00:00:00',2,'de','303364895','M','A2','A1','A2','A1','A2','A2','A2','A2','A1','A2','A3','A2','A2','A5','A5','A3','A5','A2','A2','S','S','S','I','S','Insgesamt bin ich immer gerne in den Unterricht gegangen und konnte, denke ich, auch viel neues schnell lernen.'),(17,'1980-01-01 00:00:00',2,'de','1590278478','M','A2','A1','A3','A2','A1','A1','A3','A2','A1','A2','A3','A3','A2','A5','A4','A3','A4','A2','A1','D','S','I','I','I','Vielen Dank für die Einführung in den LK. Hoffentlich bleiben Sie weiterhin unser LK-Lehrer.\nFalls dies geschehen sollte, wäre es toll noch mehr digitalisierte Methoden zu benutzen, da dies enorm hilft sich bspw. Funktioen zu visualisieren.'),(18,'1980-01-01 00:00:00',2,'de','46355843','M','A1','A3','A2','A1','A1','A1','A3','A5','A2','A2','A3','A4','A2','A5','A5','A2','A6','A1','A1','I','S','S','I','S','Teilweise muss ich sagen, dass die Erklärungen unpräzise oder unzureichend gut oder verständlich formuliert waren, weswegen man sich viel selber erschließen oder beibringen musste, was für schwächere Schüler manchmal ein Problem dargestellt hat.  Ich würde Ihnen dementsprechend raten, auch mal das Offensichtliche oder das besonders Wichtige als solches hervorzuheben und zu erklären. Dies sollte in einem verständlichen Rahmen ablaufen und die Schüler sollten ermutigt werden, Fragen während der Erklärung zu stellen.'),(19,'1980-01-01 00:00:00',2,'de','1260783414','F','A1','A3','A1','A1','A1','A1','A3','A2','A2','A2','A2','A2','A1','A5','A2','A3','A2','A1','A1','S','S','I','S','S','Insgesamt ist der Unterricht sehr strukturiert und interessant gestalltet. Manchmal sind jedoch die Stundenteile, in denen wir uns durch Gruppenarbeit selbst etwas erarbeiten sollen, nicht ganz zielführend, da jeder einen anderen Ansatz hat und man sich so schnell falsche Schreibweisen etc. aneignet. Hilfreich sind die Partnerarbeiten bzw das immer die Möglichkeit besteht, sich mit Mitschülern über die jeweilige Aufgabe auszutauschen. Die Einführung von Geogebra und die jeweiligen Hilfestellung sind vorallem beim Bearbeiten von Hausaufgaben sehr hilfreich. Für die Zukunft könnte man vielleicht nach jedem Thema es nochmal kurz zusammenfassen, um zu einem späteren Zeitpunkt darauf zurück greifen zu können. Auch die Vorbereitung auf Klausuren und die Möglichkeit auf die Lösungen über OneNote zu bekommen war gut, jedoch entsprachen die Übungsaufgaben meistens nicht dem Anforderungsniveau in den Klausuren.\n'),(20,'1980-01-01 00:00:00',2,'de','2133898858','F','A1','A1','A2','A2','A2','A2','A3','A5','A2','A2','A3','A4','A2','A5','A5','A3','A4','A2','A3','I','I','I','S','S','Teilweise unterscheiden sich die Aufgaben in den Arbeiten stark von den im Unterricht gerechneten und besprochenden Übunden. Die Arbeiten unterscheiden sich zudem sehr von denen des anderen Matheleistungskurses. Aufabenstellungen im Unterricht sind manchmal unklar. '),(21,'1980-01-01 00:00:00',2,'de','956436910','F','A1','A3','A2','A1','A2','A1','A1','A2','A1','A2','A1','A3','A1','A6','A6','A2','A5','A1','A1','D','S','I','S','S','Manchmal fehlt mir ein kleines bisschen die Struktur, wenn beispielswese neue Themen eingeführt und erklärt werden. Eventuell könnte man an dieser Stelle zunächst eine Art Zusammenfassung aufschreiben. '),(22,'1980-01-01 00:00:00',2,'de','607582098','F','A1','A1','A2','A1','A1','A1','A4','A4','A1','A2','A3','A4','A2','A5','A6','A4','A3','A2','A2','S','S','I','S','S','Die Aufgaben auf den Arbeitsblättern finde ich meistens angemessen und gut. Dennoch kommt es manchmal vor, dass die meisten (manchmal auch alle) von uns bei einer Aufgabe, die wir an der Tafel beprechen, keine Antwort wissen. Dann wäre es vielleicht manchmal besser, uns größere Tipps zu geben oder auch die Aufgabe selbst aufzulösen, anstatt lange zu warten, ob sich doch noch jemand meldet. Manchmal ist auch die Aufgabenstellung etwas unklar.\nDennoch bin ich mit Ihrem Unterricht meistens zufrieden. Sie repektieren uns Schüler und nehmen uns ernst.\nSchöne Ferien!'),(23,'1980-01-01 00:00:00',2,'de','2003139310','M','A2','A3','A2','A2','A2','A1','A2','A2','A1','A2','A3','A3','A1','A4','A5','A2','A5','A2','A2','S','S','S','S','S',''),(24,'1980-01-01 00:00:00',2,'de','351204700','F','A2','','A3','A1','A1','A2','A4','A3','A3','A3','A3','A3','A3','A4','A4','A5','A2','A2','A3','S','S','I','I','S',''),(25,'1980-01-01 00:00:00',2,'de','375847524','M','A2','A3','A2','A1','A2','A1','A2','A2','A1','A2','A3','A3','A2','A5','A6','A4','A5','A1','A1','S','S','S','I','S','Ich finde die häufige Partnerarbeit sehr angenehm und leistungsfördernd.');
/*!40000 ALTER TABLE `lszb_survey_184888` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_survey_236889`
--

DROP TABLE IF EXISTS `lszb_survey_236889`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_survey_236889` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `submitdate` datetime DEFAULT NULL,
  `lastpage` int(11) DEFAULT NULL,
  `startlanguage` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seed` varchar(31) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X15X141` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X15X142` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X15X143` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X144SQ006` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X144SQ007` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X144SQ008` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X144SQ009` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X144SQ010` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X144SQ011` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X144SQ012` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X145SQ007` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X145SQ008` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X145SQ009` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X145SQ010` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X145SQ013` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X145SQ012` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X14580432` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X14572615` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X14577500` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X145SQ011` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X146SQ002` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X146SQ003` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X146SQ004` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X146SQ005` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X146SQ008` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X146SQ009` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `236889X16X147` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_survey_236889`
--

LOCK TABLES `lszb_survey_236889` WRITE;
/*!40000 ALTER TABLE `lszb_survey_236889` DISABLE KEYS */;
INSERT INTO `lszb_survey_236889` (`id`, `submitdate`, `lastpage`, `startlanguage`, `seed`, `236889X15X141`, `236889X15X142`, `236889X15X143`, `236889X16X144SQ006`, `236889X16X144SQ007`, `236889X16X144SQ008`, `236889X16X144SQ009`, `236889X16X144SQ010`, `236889X16X144SQ011`, `236889X16X144SQ012`, `236889X16X145SQ007`, `236889X16X145SQ008`, `236889X16X145SQ009`, `236889X16X145SQ010`, `236889X16X145SQ013`, `236889X16X145SQ012`, `236889X16X14580432`, `236889X16X14572615`, `236889X16X14577500`, `236889X16X145SQ011`, `236889X16X146SQ002`, `236889X16X146SQ003`, `236889X16X146SQ004`, `236889X16X146SQ005`, `236889X16X146SQ008`, `236889X16X146SQ009`, `236889X16X147`) VALUES (10,NULL,1,'de','1711017862','','A1','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,NULL,1,'de','1980199831','','A1','A3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(12,NULL,NULL,'de','1038093614',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(13,'1980-01-01 00:00:00',2,'de','1728880139','','A1','A3','A3','A1','A3','A2','A1','A1','A1','A2','A2','A2','A1','A6','A4','A3','A2','A4','A1','I','I','S','I','I','S','Am Ende des Jahres haben wir zuwenig erklärt bekommen  wo wir die Lerntheken bearbeitet haben. Aber es hat  gut funktioniert an der Theke zu arbeiten nur, wenn etwas neues in der Theke eingefürt wird sollten wir das vorher besprechen.'),(14,'1980-01-01 00:00:00',2,'de','147112007','','A1','A3','A1','A2','A6','A1','A3','A4','A4','A1','A2','A4','A3','A5','A4','A3','A2','A4','A1','S','I','I','I','D','S','');
/*!40000 ALTER TABLE `lszb_survey_236889` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_survey_579638`
--

DROP TABLE IF EXISTS `lszb_survey_579638`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_survey_579638` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `submitdate` datetime DEFAULT NULL,
  `lastpage` int(11) DEFAULT NULL,
  `startlanguage` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seed` varchar(31) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `579638X4X8` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `579638X4X10` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `579638X4X9` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `579638X4X9comment` text COLLATE utf8mb4_unicode_ci,
  `579638X5X11` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `579638X5X11comment` text COLLATE utf8mb4_unicode_ci,
  `579638X5X12` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `579638X5X12comment` text COLLATE utf8mb4_unicode_ci,
  `579638X5X13` text COLLATE utf8mb4_unicode_ci,
  `579638X5X14` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_survey_579638`
--

LOCK TABLES `lszb_survey_579638` WRITE;
/*!40000 ALTER TABLE `lszb_survey_579638` DISABLE KEYS */;
INSERT INTO `lszb_survey_579638` (`id`, `submitdate`, `lastpage`, `startlanguage`, `seed`, `579638X4X8`, `579638X4X10`, `579638X4X9`, `579638X4X9comment`, `579638X5X11`, `579638X5X11comment`, `579638X5X12`, `579638X5X12comment`, `579638X5X13`, `579638X5X14`) VALUES (1,NULL,NULL,'de','401748581',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,NULL,NULL,'de','1769588956',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,'1980-01-01 00:00:00',2,'de','976230187','M','N','A4','Testeintrag von Andreas Siebel - Kann gelöscht werden','A3','','A2','','bla','bla'),(4,'1980-01-01 00:00:00',2,'de','1569783418','M','Y','A2','','A3','','A2','','Das ausgewogene Verhältnis von Erklärungen  und Anwendungsaufgaben und das kleinschrittige Vorgehen. ','Mehr Verknüpfungsaufgaben zwischen einzelnen Lektionen und andere(längere) Zeitlimits.'),(5,'1980-01-01 00:00:00',2,'de','1502568748','M','Y','A1','','A3','','A2','','man hat immer sofort ein Feedback bekommen und konnte durch die verschiedenen Übungen seinen Umgang mit SQL verbessern','Beim Überprüfen mit der Lösung vielleicht so ein paar Tipps, was falsch war, da man teilweise lange überlegt was falsch ist und am Ende ist es nur ein kleiner Rechtschreibfehler der nicht auffällt'),(6,'1980-01-01 00:00:00',2,'de','1924958411','M','Y','A1','','A3','','A2','',',dass es immer zunächst einfachere Aufgaben gab, es aber trotzdem am Ende noch kniffelig Aufgaben zum probieren gab.','Gerne ausführlichere Erklärungen!'),(7,'1980-01-01 00:00:00',2,'de','77704240','M','Y','A4','','A3','','A2','','selbstständiges arbeiten','-'),(8,'1980-01-01 00:00:00',2,'de','1376851748','F','Y','A3','','A3','','A2','','Zunächst wurde alles genau erklärt und dann mit steigendem Schwierigkeitsgrad abgefragt. Perfekt zum Einprägen und üben.','Teilweise mehr Hilfestellungen.'),(9,'1980-01-01 00:00:00',2,'de','12818052','M','Y','A3','','A3','','A2','Teilweise dann jedoch aufwendig beziehungsweise schwerer, was aber ja auch so gewollt war. Richtige Aufteilung von mittelschwer, leicht und schwer','Gute Heranführung an die meisten Themen','Mehr Aufgabe die zwischenbereiche abdecken also nicht von sehr leicht zu extrem schwer in einem schritt bei manchen Lektionen.'),(10,'1980-01-01 00:00:00',2,'de','2046411538','M','Y','A4','','A3','','A2','','Den Aufbau des Kurses mit steigender Schwierigkeit \n','Eine Hilfestellung bei Aufgaben die man nach mehreren Versuchen immer noch falsch beantwortet hat wäre toll.'),(11,'1980-01-01 00:00:00',2,'de','358338126','M','Y','A3','','A3','','A2','','Geordnete und strukturierte Aufgabenstellungen, sowie umfangreiche Erklärungen und Hilfestellungen!','-'),(12,NULL,1,'de','2044292749','','N','A3','Ich wollte mich mit SQL-Grundlagen vertraut machen bzw bereits vorhandene Grundkenntnisse auffrischen und habe den Kurs zufällig gefunden. Der Kurs ist sehr gut aufgebaut, insbesondere die hohe Anzahl an Aufgaben sowie deren Reihenfolge tragen viel zum Verständnis des Materials bei. Vielen Dank für den Kurs!\n\nIch bin mir nicht sicher aber ich habe den Eindruck bekommen, als ob ein paar Aufgaben nicht korrekt überprüft werden:\n11.1 Übungen SELF JOIN (Aufgabe 9)\n8.2 Schwierigere Übungen (Aufgabe 3 Sigourney Weaver & ?)\nDas Problem kann natürlich daran liegen, dass ich diese evtl nicht richtig gelöst habe, allerdings wurden meine Lösungen der gleichen Aufgaben bei SQLZOO als korrekt eingestuft. Daher fand ich es wichtig, darauf hinzuweisen.\n\nNochmals herzlichen Dank für den Kurs!\n\n',NULL,NULL,NULL,NULL,NULL,NULL),(13,NULL,NULL,'de','756796908',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `lszb_survey_579638` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_survey_632936`
--

DROP TABLE IF EXISTS `lszb_survey_632936`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_survey_632936` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(35) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `submitdate` datetime DEFAULT NULL,
  `lastpage` int(11) DEFAULT NULL,
  `startlanguage` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seed` varchar(31) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `632936X1X1` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `632936X1X2` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `632936X1X2comment` text COLLATE utf8mb4_unicode_ci,
  `632936X2X3` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `632936X2X3comment` text COLLATE utf8mb4_unicode_ci,
  `632936X2X4` text COLLATE utf8mb4_unicode_ci,
  `632936X2X5` text COLLATE utf8mb4_unicode_ci,
  `632936X2X6` text COLLATE utf8mb4_unicode_ci,
  `632936X3X7` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_survey_token_632936_29157` (`token`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_survey_632936`
--

LOCK TABLES `lszb_survey_632936` WRITE;
/*!40000 ALTER TABLE `lszb_survey_632936` DISABLE KEYS */;
INSERT INTO `lszb_survey_632936` (`id`, `token`, `submitdate`, `lastpage`, `startlanguage`, `seed`, `632936X1X1`, `632936X1X2`, `632936X1X2comment`, `632936X2X3`, `632936X2X3comment`, `632936X2X4`, `632936X2X5`, `632936X2X6`, `632936X3X7`) VALUES (4,'pythonkurs2019',NULL,1,'de','349572725','M','A1','',NULL,NULL,NULL,NULL,NULL,NULL),(5,'pythonkurs2019',NULL,1,'de','621195481','M','A2','',NULL,NULL,NULL,NULL,NULL,NULL),(3,'pythonkurs2019','1980-01-01 00:00:00',3,'de','677328348','F','A2','','A2','','Ich habe eine neue Spache gelernt!','mehre Zeit für diesen Kurs.','','Programmieren ist einfach und interessant'),(6,'pythonkurs2019',NULL,1,'de','2072789083','M','A2','',NULL,NULL,NULL,NULL,NULL,NULL),(7,'pythonkurs2019',NULL,1,'de','1468101781','M','A3','',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `lszb_survey_632936` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_survey_976696`
--

DROP TABLE IF EXISTS `lszb_survey_976696`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_survey_976696` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `submitdate` datetime DEFAULT NULL,
  `lastpage` int(11) DEFAULT NULL,
  `startlanguage` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seed` varchar(31) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X13X109` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X13X110` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X13X111` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X112SQ006` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X112SQ007` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X112SQ008` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X112SQ009` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X112SQ010` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X112SQ011` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X112SQ012` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X113SQ007` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X113SQ008` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X113SQ009` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X113SQ010` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X113SQ013` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X113SQ012` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X11380432` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X11372615` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X11377500` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X113SQ011` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X114SQ002` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X114SQ003` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X114SQ004` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X114SQ005` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X114SQ006` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X114SQ007` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X114SQ008` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X114SQ009` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `976696X14X115` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_survey_976696`
--

LOCK TABLES `lszb_survey_976696` WRITE;
/*!40000 ALTER TABLE `lszb_survey_976696` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_survey_976696` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_survey_links`
--

DROP TABLE IF EXISTS `lszb_survey_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_survey_links` (
  `participant_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token_id` int(11) NOT NULL,
  `survey_id` int(11) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_invited` datetime DEFAULT NULL,
  `date_completed` datetime DEFAULT NULL,
  PRIMARY KEY (`participant_id`,`token_id`,`survey_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_survey_links`
--

LOCK TABLES `lszb_survey_links` WRITE;
/*!40000 ALTER TABLE `lszb_survey_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_survey_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_survey_url_parameters`
--

DROP TABLE IF EXISTS `lszb_survey_url_parameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_survey_url_parameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL,
  `parameter` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetqid` int(11) DEFAULT NULL,
  `targetsqid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_survey_url_parameters`
--

LOCK TABLES `lszb_survey_url_parameters` WRITE;
/*!40000 ALTER TABLE `lszb_survey_url_parameters` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_survey_url_parameters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_surveymenu`
--

DROP TABLE IF EXISTS `lszb_surveymenu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_surveymenu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `survey_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ordering` int(11) DEFAULT '0',
  `level` int(11) DEFAULT '0',
  `title` varchar(168) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `position` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'side',
  `description` text COLLATE utf8mb4_unicode_ci,
  `showincollapse` int(11) DEFAULT '0',
  `active` int(11) NOT NULL DEFAULT '0',
  `changed_at` datetime DEFAULT NULL,
  `changed_by` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `lszb_surveymenu_name` (`name`),
  KEY `lszb_idx2_surveymenu` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_surveymenu`
--

LOCK TABLES `lszb_surveymenu` WRITE;
/*!40000 ALTER TABLE `lszb_surveymenu` DISABLE KEYS */;
INSERT INTO `lszb_surveymenu` (`id`, `parent_id`, `survey_id`, `user_id`, `name`, `ordering`, `level`, `title`, `position`, `description`, `showincollapse`, `active`, `changed_at`, `changed_by`, `created_at`, `created_by`) VALUES (1,NULL,NULL,NULL,'settings',1,0,'Survey settings','side','Survey settings',1,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(2,NULL,NULL,NULL,'mainmenu',2,0,'Survey menu','side','Main survey menu',1,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(3,NULL,NULL,NULL,'quickmenu',3,0,'Quick menu','collapsed','Quick menu',0,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0);
/*!40000 ALTER TABLE `lszb_surveymenu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_surveymenu_entries`
--

DROP TABLE IF EXISTS `lszb_surveymenu_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_surveymenu_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ordering` int(11) DEFAULT '0',
  `name` varchar(168) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `title` varchar(168) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_title` varchar(168) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_description` text COLLATE utf8mb4_unicode_ci,
  `menu_icon` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_icon_type` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_class` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_link` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `action` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `template` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `partial` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `classes` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `permission` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `permission_grade` varchar(192) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8mb4_unicode_ci,
  `getdatamethod` varchar(192) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `language` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en-GB',
  `showincollapse` int(11) DEFAULT '0',
  `active` int(11) NOT NULL DEFAULT '0',
  `changed_at` datetime DEFAULT NULL,
  `changed_by` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `lszb_surveymenu_entries_name` (`name`),
  KEY `lszb_idx1_surveymenu_entries` (`menu_id`),
  KEY `lszb_idx5_surveymenu_entries` (`menu_title`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_surveymenu_entries`
--

LOCK TABLES `lszb_surveymenu_entries` WRITE;
/*!40000 ALTER TABLE `lszb_surveymenu_entries` DISABLE KEYS */;
INSERT INTO `lszb_surveymenu_entries` (`id`, `menu_id`, `user_id`, `ordering`, `name`, `title`, `menu_title`, `menu_description`, `menu_icon`, `menu_icon_type`, `menu_class`, `menu_link`, `action`, `template`, `partial`, `classes`, `permission`, `permission_grade`, `data`, `getdatamethod`, `language`, `showincollapse`, `active`, `changed_at`, `changed_by`, `created_at`, `created_by`) VALUES (1,1,NULL,1,'overview','Survey overview','Overview','Open the general survey overview','list','fontawesome','','admin/survey/sa/view','','','','','','','{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','','en-GB',0,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(2,1,NULL,2,'generalsettings','General survey settings','General settings','Open general survey settings','gears','fontawesome','','','updatesurveylocalesettings_generalsettings','editLocalSettings_main_view','/admin/survey/subview/accordion/_generaloptions_panel','','surveysettings','read',NULL,'_generalTabEditSurvey','en-GB',1,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(3,1,NULL,3,'surveytexts','Survey text elements','Text elements','Survey text elements','file-text-o','fontawesome','','','updatesurveylocalesettings','editLocalSettings_main_view','/admin/survey/subview/tab_edit_view','','surveylocale','read',NULL,'_getTextEditData','en-GB',1,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(4,1,NULL,4,'datasecurity','Data policy settings','Data policy settings','Edit data policy settings','shield','fontawesome','','','updatesurveylocalesettings','editLocalSettings_main_view','/admin/survey/subview/tab_edit_view_datasecurity','','surveylocale','read',NULL,'_getDataSecurityEditData','en-GB',1,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(5,1,NULL,5,'theme_options','Theme options','Theme options','Edit theme options for this survey','paint-brush','fontawesome','','admin/themeoptions/sa/updatesurvey','','','','','surveysettings','update','{\"render\": {\"link\": { \"pjaxed\": true, \"data\": {\"surveyid\": [\"survey\",\"sid\"], \"gsid\":[\"survey\",\"gsid\"]}}}}','','en-GB',0,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(6,1,NULL,6,'presentation','Presentation & navigation settings','Presentation','Edit presentation and navigation settings','eye-slash','fontawesome','','','updatesurveylocalesettings','editLocalSettings_main_view','/admin/survey/subview/accordion/_presentation_panel','','surveylocale','read',NULL,'_tabPresentationNavigation','en-GB',0,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(7,1,NULL,7,'tokens','Survey participant settings','Participant settings','Set additional options for survey participants','users','fontawesome','','','updatesurveylocalesettings','editLocalSettings_main_view','/admin/survey/subview/accordion/_tokens_panel','','surveylocale','read',NULL,'_tabTokens','en-GB',0,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(8,1,NULL,8,'notification','Notification and data management settings','Notifications & data','Edit settings for notification and data management','feed','fontawesome','','','updatesurveylocalesettings','editLocalSettings_main_view','/admin/survey/subview/accordion/_notification_panel','','surveylocale','read',NULL,'_tabNotificationDataManagement','en-GB',0,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(9,1,NULL,9,'publication','Publication & access control settings','Publication & access','Edit settings for publication and access control','key','fontawesome','','','updatesurveylocalesettings','editLocalSettings_main_view','/admin/survey/subview/accordion/_publication_panel','','surveylocale','read',NULL,'_tabPublicationAccess','en-GB',0,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(10,2,NULL,1,'listQuestions','List questions','List questions','List questions','list','fontawesome','','admin/survey/sa/listquestions','','','','','surveycontent','read','{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','','en-GB',1,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(11,2,NULL,2,'listQuestionGroups','List question groups','List question groups','List question groups','th-list','fontawesome','','admin/survey/sa/listquestiongroups','','','','','surveycontent','read','{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','','en-GB',1,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(12,2,NULL,3,'reorder','Reorder questions/question groups','Reorder questions/question groups','Reorder questions/question groups','icon-organize','iconclass','','admin/survey/sa/organize/','','','','','surveycontent','update','{\"render\": {\"isActive\": false, \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','','en-GB',1,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(13,2,NULL,4,'responses','Responses','Responses','Responses','icon-browse','iconclass','','admin/responses/sa/browse/','','','','','responses','read','{\"render\": {\"isActive\": true, \"link\": {\"data\": {\"surveyid\": [\"survey\", \"sid\"]}}}}','','en-GB',1,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(14,2,NULL,5,'participants','Survey participants','Survey participants','Go to survey participant and token settings','user','fontawesome','','admin/tokens/sa/index/','','','','','surveysettings','update','{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','','en-GB',1,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(15,2,NULL,6,'statistics','Statistics','Statistics','Statistics','bar-chart','fontawesome','','admin/statistics/sa/index/','','','','','statistics','read','{\"render\": {\"isActive\": true, \"link\": {\"data\": {\"surveyid\": [\"survey\", \"sid\"]}}}}','','en-GB',1,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(16,2,NULL,7,'quotas','Edit quotas','Quotas','Edit quotas for this survey.','tasks','fontawesome','','admin/quotas/sa/index/','','','','','quotas','read','{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','','en-GB',0,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(17,2,NULL,8,'assessments','Edit assessments','Assessments','Edit and look at the assessements for this survey.','comment-o','fontawesome','','admin/assessments/sa/index/','','','','','assessments','read','{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','','en-GB',0,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(18,2,NULL,9,'surveypermissions','Edit survey permissions','Survey permissions','Edit permissions for this survey','lock','fontawesome','','admin/surveypermission/sa/view/','','','','','surveysecurity','read','{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','','en-GB',0,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(19,2,NULL,10,'emailtemplates','Email templates','Email templates','Edit the templates for invitation, reminder and registration emails','envelope-square','fontawesome','','admin/emailtemplates/sa/index/','','','','','surveylocale','read','{\"render\": { \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','','en-GB',0,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(20,2,NULL,11,'panelintegration','Edit survey panel integration','Panel integration','Define panel integrations for your survey','link','fontawesome','','','updatesurveylocalesettings','editLocalSettings_main_view','/admin/survey/subview/accordion/_integration_panel','','surveylocale','read','{\"render\": {\"link\": { \"pjaxed\": false}}}','_tabPanelIntegration','en-GB',0,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(21,2,NULL,12,'resources','Add/edit resources (files/images) for this survey','Resources','Add/edit resources (files/images) for this survey','file','fontawesome','','','updatesurveylocalesettings','editLocalSettings_main_view','/admin/survey/subview/accordion/_resources_panel','','surveylocale','read',NULL,'_tabResourceManagement','en-GB',0,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(22,2,NULL,13,'plugins','Simple plugin settings','Simple plugins','Edit simple plugin settings','plug','fontawesome','','','updatesurveylocalesettings','editLocalSettings_main_view','/admin/survey/subview/accordion/_plugins_panel','','surveysettings','read','{\"render\": {\"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','_pluginTabSurvey','en-GB',0,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(23,3,NULL,1,'activateSurvey','Activate survey','Activate survey','Activate survey','play','fontawesome','','admin/survey/sa/activate','','','','','surveyactivation','update','{\"render\": {\"isActive\": false, \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','','en-GB',1,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(24,3,NULL,2,'deactivateSurvey','Stop this survey','Stop this survey','Stop this survey','stop','fontawesome','','admin/survey/sa/deactivate','','','','','surveyactivation','update','{\"render\": {\"isActive\": true, \"link\": {\"data\": {\"surveyid\": [\"survey\",\"sid\"]}}}}','','en-GB',1,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(25,3,NULL,3,'testSurvey','Go to survey','Go to survey','Go to survey','cog','fontawesome','','survey/index/','','','','','','','{\"render\": {\"link\": {\"external\": true, \"data\": {\"sid\": [\"survey\",\"sid\"], \"newtest\": \"Y\", \"lang\": [\"survey\",\"language\"]}}}}','','en-GB',1,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(26,3,NULL,4,'surveyLogicFile','Survey logic file','Survey logic file','Survey logic file','sitemap','fontawesome','','admin/expressions/sa/survey_logic_file/','','','','','surveycontent','read','{\"render\": { \"link\": {\"data\": {\"sid\": [\"survey\",\"sid\"]}}}}','','en-GB',1,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0),(27,3,NULL,5,'cpdb','Central participant database','Central participant database','Central participant database','users','fontawesome','','admin/participants/sa/displayParticipants','','','','','tokens','read','{\"render\": {\"link\": {}}}','','en-GB',1,1,'2019-04-02 10:15:14',0,'2019-04-02 10:15:14',0);
/*!40000 ALTER TABLE `lszb_surveymenu_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_surveys`
--

DROP TABLE IF EXISTS `lszb_surveys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_surveys` (
  `sid` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `gsid` int(11) DEFAULT '1',
  `admin` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `expires` datetime DEFAULT NULL,
  `startdate` datetime DEFAULT NULL,
  `adminemail` varchar(254) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `anonymized` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `faxto` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `format` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `savetimings` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `template` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `language` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_languages` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `datestamp` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `usecookie` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `allowregister` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `allowsave` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `autonumber_start` int(11) NOT NULL DEFAULT '0',
  `autoredirect` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `allowprev` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `printanswers` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `ipaddr` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `refurl` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `datecreated` datetime DEFAULT NULL,
  `showsurveypolicynotice` int(11) DEFAULT '0',
  `publicstatistics` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `publicgraphs` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `listpublic` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `htmlemail` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `sendconfirmation` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `tokenanswerspersistence` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `assessments` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `usecaptcha` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `usetokens` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N',
  `bounce_email` varchar(254) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attributedescriptions` text COLLATE utf8mb4_unicode_ci,
  `emailresponseto` text COLLATE utf8mb4_unicode_ci,
  `emailnotificationto` text COLLATE utf8mb4_unicode_ci,
  `tokenlength` int(11) NOT NULL DEFAULT '15',
  `showxquestions` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'Y',
  `showgroupinfo` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'B',
  `shownoanswer` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'Y',
  `showqnumcode` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'X',
  `bouncetime` int(11) DEFAULT NULL,
  `bounceprocessing` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `bounceaccounttype` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bounceaccounthost` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bounceaccountpass` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bounceaccountencryption` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bounceaccountuser` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `showwelcome` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'Y',
  `showprogress` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'Y',
  `questionindex` int(11) NOT NULL DEFAULT '0',
  `navigationdelay` int(11) NOT NULL DEFAULT '0',
  `nokeyboard` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `alloweditaftercompletion` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `googleanalyticsstyle` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `googleanalyticsapikey` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`sid`),
  KEY `lszb_idx1_surveys` (`owner_id`),
  KEY `lszb_idx2_surveys` (`gsid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_surveys`
--

LOCK TABLES `lszb_surveys` WRITE;
/*!40000 ALTER TABLE `lszb_surveys` DISABLE KEYS */;
INSERT INTO `lszb_surveys` (`sid`, `owner_id`, `gsid`, `admin`, `active`, `expires`, `startdate`, `adminemail`, `anonymized`, `faxto`, `format`, `savetimings`, `template`, `language`, `additional_languages`, `datestamp`, `usecookie`, `allowregister`, `allowsave`, `autonumber_start`, `autoredirect`, `allowprev`, `printanswers`, `ipaddr`, `refurl`, `datecreated`, `showsurveypolicynotice`, `publicstatistics`, `publicgraphs`, `listpublic`, `htmlemail`, `sendconfirmation`, `tokenanswerspersistence`, `assessments`, `usecaptcha`, `usetokens`, `bounce_email`, `attributedescriptions`, `emailresponseto`, `emailnotificationto`, `tokenlength`, `showxquestions`, `showgroupinfo`, `shownoanswer`, `showqnumcode`, `bouncetime`, `bounceprocessing`, `bounceaccounttype`, `bounceaccounthost`, `bounceaccountpass`, `bounceaccountencryption`, `bounceaccountuser`, `showwelcome`, `showprogress`, `questionindex`, `navigationdelay`, `nokeyboard`, `alloweditaftercompletion`, `googleanalyticsstyle`, `googleanalyticsapikey`) VALUES (632936,1,1,'Administrator','Y','2019-05-30 00:00:00','2019-04-20 00:00:00','admin@survey.cws-lernen.de','N','','G','N','fruity','de','','N','Y','N','Y',1,'N','N','N','N','N','2019-04-21 18:10:39',1,'N','N','N','Y','Y','N','N','A','N','admin@survey.cws-lernen.de',NULL,'','andreas.siebel@it-teaching.de',15,'Y','B','N','X',NULL,'N',NULL,NULL,NULL,NULL,NULL,'Y','Y',0,0,'N','N','0',''),(579638,1,1,'Administrator','Y',NULL,NULL,'admin@survey.cws-lernen.de','Y','','G','N','fruity','de','','N','N','N','Y',0,'N','N','N','N','N','2019-04-21 20:13:58',0,'N','N','N','Y','Y','N','N','N','N','admin@survey.cws-lernen.de',NULL,'','',15,'Y','B','N','X',NULL,'N',NULL,NULL,NULL,NULL,NULL,'Y','Y',0,0,'N','N',NULL,NULL),(976696,1,1,'Administrator','Y','2019-06-30 08:50:00',NULL,'admin@survey.cws-lernen.de','Y','','G','N','fruity','de','','N','N','N','Y',10,'N','N','N','N','N','2019-06-19 06:50:51',0,'N','N','N','Y','Y','N','N','N','N','admin@survey.cws-lernen.de',NULL,'','',15,'Y','B','N','X',NULL,'N',NULL,NULL,NULL,NULL,NULL,'Y','Y',0,0,'N','N','',''),(236889,1,1,'Administrator','Y','2019-06-30 08:50:00',NULL,'admin@survey.cws-lernen.de','Y','','G','N','fruity','de','','N','N','N','Y',10,'N','N','N','N','N','2019-06-19 06:52:36',0,'N','N','N','Y','Y','N','N','N','N','admin@survey.cws-lernen.de',NULL,'','',15,'Y','B','N','X',NULL,'N',NULL,NULL,NULL,NULL,NULL,'Y','Y',0,0,'N','N','',''),(184888,1,1,'Administrator','Y','2019-06-30 08:50:00',NULL,'admin@survey.cws-lernen.de','Y','','G','N','fruity','de','','N','N','N','Y',10,'N','N','N','N','N','2019-06-18 21:20:11',0,'N','N','N','Y','Y','N','N','N','N','admin@survey.cws-lernen.de',NULL,'','',15,'Y','B','N','X',NULL,'N',NULL,NULL,NULL,NULL,NULL,'Y','Y',0,0,'N','N','','');
/*!40000 ALTER TABLE `lszb_surveys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_surveys_groups`
--

DROP TABLE IF EXISTS `lszb_surveys_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_surveys_groups` (
  `gsid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `description` text COLLATE utf8mb4_unicode_ci,
  `sortorder` int(11) NOT NULL,
  `owner_uid` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`gsid`),
  KEY `lszb_idx1_surveys_groups` (`name`),
  KEY `lszb_idx2_surveys_groups` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_surveys_groups`
--

LOCK TABLES `lszb_surveys_groups` WRITE;
/*!40000 ALTER TABLE `lszb_surveys_groups` DISABLE KEYS */;
INSERT INTO `lszb_surveys_groups` (`gsid`, `name`, `title`, `template`, `description`, `sortorder`, `owner_uid`, `parent_id`, `created`, `modified`, `created_by`) VALUES (1,'default','Default',NULL,'Default survey group',0,1,NULL,'2019-04-02 10:15:14','2019-04-02 10:15:14',1);
/*!40000 ALTER TABLE `lszb_surveys_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_surveys_languagesettings`
--

DROP TABLE IF EXISTS `lszb_surveys_languagesettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_surveys_languagesettings` (
  `surveyls_survey_id` int(11) NOT NULL,
  `surveyls_language` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `surveyls_title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surveyls_description` text COLLATE utf8mb4_unicode_ci,
  `surveyls_welcometext` text COLLATE utf8mb4_unicode_ci,
  `surveyls_endtext` text COLLATE utf8mb4_unicode_ci,
  `surveyls_policy_notice` text COLLATE utf8mb4_unicode_ci,
  `surveyls_policy_error` text COLLATE utf8mb4_unicode_ci,
  `surveyls_policy_notice_label` varchar(192) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surveyls_url` text COLLATE utf8mb4_unicode_ci,
  `surveyls_urldescription` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surveyls_email_invite_subj` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surveyls_email_invite` text COLLATE utf8mb4_unicode_ci,
  `surveyls_email_remind_subj` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surveyls_email_remind` text COLLATE utf8mb4_unicode_ci,
  `surveyls_email_register_subj` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surveyls_email_register` text COLLATE utf8mb4_unicode_ci,
  `surveyls_email_confirm_subj` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surveyls_email_confirm` text COLLATE utf8mb4_unicode_ci,
  `surveyls_dateformat` int(11) NOT NULL DEFAULT '1',
  `surveyls_attributecaptions` text COLLATE utf8mb4_unicode_ci,
  `email_admin_notification_subj` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_admin_notification` text COLLATE utf8mb4_unicode_ci,
  `email_admin_responses_subj` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_admin_responses` text COLLATE utf8mb4_unicode_ci,
  `surveyls_numberformat` int(11) NOT NULL DEFAULT '0',
  `attachments` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`surveyls_survey_id`,`surveyls_language`),
  KEY `lszb_idx1_surveys_languagesettings` (`surveyls_title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_surveys_languagesettings`
--

LOCK TABLES `lszb_surveys_languagesettings` WRITE;
/*!40000 ALTER TABLE `lszb_surveys_languagesettings` DISABLE KEYS */;
INSERT INTO `lszb_surveys_languagesettings` (`surveyls_survey_id`, `surveyls_language`, `surveyls_title`, `surveyls_description`, `surveyls_welcometext`, `surveyls_endtext`, `surveyls_policy_notice`, `surveyls_policy_error`, `surveyls_policy_notice_label`, `surveyls_url`, `surveyls_urldescription`, `surveyls_email_invite_subj`, `surveyls_email_invite`, `surveyls_email_remind_subj`, `surveyls_email_remind`, `surveyls_email_register_subj`, `surveyls_email_register`, `surveyls_email_confirm_subj`, `surveyls_email_confirm`, `surveyls_dateformat`, `surveyls_attributecaptions`, `email_admin_notification_subj`, `email_admin_notification`, `email_admin_responses_subj`, `email_admin_responses`, `surveyls_numberformat`, `attachments`) VALUES (632936,'de','Umfrage Python Kurs','Umfrage zum Python Kurs 2019 auf Stepik:','<p>Ich freue mich, wenn du an der Online-Umfrage teilnimmst.</p>\r\n\r\n<p>Hinweise zur Datenverarbeitung: Daten werden nur auf diesem Server gespeichert und nnur zur Auswertung des Kurses verwendet. Die Daten werden nicht an Dritte weitergegeben.</p>\r\n','','<p>Daten werden nur zur Auswertung des Kurses verwendet. Die Daten werden anonym behandelt und nicht an Dritte weitergegeben.</p>\r\n\r\n<p>Bei Rückfragen:</p>\r\n\r\n<p>Andreas Siebel | andreas.siebel@it-teaching.de</p>\r\n','','','','','Einladung zu einer Umfrage','Hallo {FIRSTNAME},<br />\n<br />\nHiermit möchten wir Sie zu einer Umfrage einladen.<br />\n<br />\nDer Titel der Umfrage ist <br />\n\'{SURVEYNAME}\'<br />\n<br />\n\'{SURVEYDESCRIPTION}\'<br />\n<br />\nUm an dieser Umfrage teilzunehmen, klicken Sie bitte auf den unten stehenden Link.<br />\n<br />\nMit freundlichen Grüßen,<br />\n<br />\n{ADMINNAME} ({ADMINEMAIL})<br />\n<br />\n----------------------------------------------<br />\nKlicken Sie hier um die Umfrage zu starten:<br />\n{SURVEYURL}<br />\n<br />\nWenn Sie an diese Umfrage nicht teilnehmen und keine weiteren Erinnerungen erhalten möchten, klicken Sie bitte auf den folgenden Link:<br />\n{OPTOUTURL}<br />\n<br />\nWenn Sie geblockt sind, jedoch wieder teilnehmen und weitere Einladungen erhalten möchten, klicken Sie bitte auf den folgenden Link:<br />\n{OPTINURL}','Erinnerung an die Teilnahme an einer Umfrage','Hallo {FIRSTNAME},<br />\n<br />\nVor kurzem haben wir Sie zu einer Umfrage eingeladen.<br />\n<br />\nZu unserem Bedauern haben wir bemerkt, dass Sie die Umfrage noch nicht ausgefüllt haben. Wir möchten Ihnen mitteilen, dass die Umfrage noch aktiv ist und würden uns freuen, wenn Sie teilnehmen könnten.<br />\n<br />\nDer Titel der Umfrage ist <br />\n\'{SURVEYNAME}\'<br />\n<br />\n\'{SURVEYDESCRIPTION}\'<br />\n<br />\nUm an dieser Umfrage teilzunehmen, klicken Sie bitte auf den unten stehenden Link.<br />\n<br />\n Mit freundlichen Grüßen,<br />\n<br />\n{ADMINNAME} ({ADMINEMAIL})<br />\n<br />\n----------------------------------------------<br />\nKlicken Sie hier um die Umfrage zu starten:<br />\n{SURVEYURL}<br />\n<br />\nWenn Sie an diese Umfrage nicht teilnehmen und keine weiteren Erinnerungen erhalten möchten, klicken Sie bitte auf den folgenden Link:<br />\n{OPTOUTURL}','Registrierungsbestätigung für Teilnahmeumfrage','Hallo {FIRSTNAME},<br />\n<br />\nSie (oder jemand, der Ihre E-Mail benutzt hat) haben sich für eine Umfrage mit dem Titel {SURVEYNAME} angemeldet.<br />\n<br />\nUm an dieser Umfrage teilzunehmen, klicken Sie bitte auf den folgenden Link.<br />\n<br />\n{SURVEYURL}<br />\n<br />\nWenn Sie irgendwelche Fragen zu dieser Umfrage haben oder wenn Sie sich _nicht_ für diese Umfrage angemeldet haben und sie glauben, dass Ihnen diese E-Mail irrtümlicherweise zugeschickt worden ist, kontaktieren Sie bitte {ADMINNAME} unter {ADMINEMAIL}.','Bestätigung für die Teilnahme an unserer Umfrage','Hallo {FIRSTNAME},<br />\n<br />\nVielen Dank für die Teilnahme an der Umfrage mit dem Titel {SURVEYNAME}. Ihre Antworten wurden bei uns gespeichert.<br />\n<br />\nWenn Sie irgendwelche Fragen zu dieser E-Mail haben, kontaktieren Sie bitte {ADMINNAME} unter {ADMINEMAIL}.<br />\n<br />\nMit freundlichen Grüßen,<br />\n<br />\n{ADMINNAME}',1,NULL,'Antwortabsendung für Umfrage {SURVEYNAME}','Hallo,<br />\n<br />\nEine neue Antwort wurde für die Umfrage \'{SURVEYNAME}\' abgegeben.<br />\n<br />\nKlicken Sie auf den folgenden Link um den Antwortdatensatz anzusehen:<br />\n{VIEWRESPONSEURL}<br />\n<br />\nKlicken Sie auf den folgenden Link um den Antwortdatensatz zu bearbeiten:<br />\n{EDITRESPONSEURL}<br />\n<br />\nUm die Statistik zu sehen, klicken Sie hier:<br />\n{STATISTICSURL}','Antwortabsendung für Umfrage {SURVEYNAME} mit Ergebnissen','Hallo,<br />\n<br />\nEine neue Antwort wurde für die Umfrage \'{SURVEYNAME}\' abgegeben.<br />\n<br />\nKlicken Sie auf den folgenden Link um den Antwortdatensatz anzusehen:<br />\n{VIEWRESPONSEURL}<br />\n<br />\nKlicken Sie auf den folgenden Link um den Antwortdatensatz zu bearbeiten:<br />\n{EDITRESPONSEURL}<br />\n<br />\nUm die Statistik zu sehen, klicken Sie hier:<br />\n{STATISTICSURL}<br />\n<br />\n<br />\nDie folgenden Antworten wurden vom Teilnehmer gegeben:<br />\n{ANSWERTABLE}',0,NULL),(579638,'de','SQL Kurs 2019','Umfrage für den SQL Kurs 2019!','Ich würde mich freuen, wenn du an der Umfrage zum SQL-Kurs teilnimmst. Dies hilft den Kurs für zukünftige Teilnehmer zu verbessern.','Vielen Dank für deine Teilnahme',NULL,NULL,NULL,'','','Einladung zu einer Umfrage','Hallo {FIRSTNAME},<br />\n<br />\nHiermit möchten wir Sie zu einer Umfrage einladen.<br />\n<br />\nDer Titel der Umfrage ist <br />\n\'{SURVEYNAME}\'<br />\n<br />\n\'{SURVEYDESCRIPTION}\'<br />\n<br />\nUm an dieser Umfrage teilzunehmen, klicken Sie bitte auf den unten stehenden Link.<br />\n<br />\nMit freundlichen Grüßen,<br />\n<br />\n{ADMINNAME} ({ADMINEMAIL})<br />\n<br />\n----------------------------------------------<br />\nKlicken Sie hier um die Umfrage zu starten:<br />\n{SURVEYURL}<br />\n<br />\nWenn Sie an diese Umfrage nicht teilnehmen und keine weiteren Erinnerungen erhalten möchten, klicken Sie bitte auf den folgenden Link:<br />\n{OPTOUTURL}<br />\n<br />\nWenn Sie geblockt sind, jedoch wieder teilnehmen und weitere Einladungen erhalten möchten, klicken Sie bitte auf den folgenden Link:<br />\n{OPTINURL}','Erinnerung an die Teilnahme an einer Umfrage','Hallo {FIRSTNAME},<br />\n<br />\nVor kurzem haben wir Sie zu einer Umfrage eingeladen.<br />\n<br />\nZu unserem Bedauern haben wir bemerkt, dass Sie die Umfrage noch nicht ausgefüllt haben. Wir möchten Ihnen mitteilen, dass die Umfrage noch aktiv ist und würden uns freuen, wenn Sie teilnehmen könnten.<br />\n<br />\nDer Titel der Umfrage ist <br />\n\'{SURVEYNAME}\'<br />\n<br />\n\'{SURVEYDESCRIPTION}\'<br />\n<br />\nUm an dieser Umfrage teilzunehmen, klicken Sie bitte auf den unten stehenden Link.<br />\n<br />\n Mit freundlichen Grüßen,<br />\n<br />\n{ADMINNAME} ({ADMINEMAIL})<br />\n<br />\n----------------------------------------------<br />\nKlicken Sie hier um die Umfrage zu starten:<br />\n{SURVEYURL}<br />\n<br />\nWenn Sie an diese Umfrage nicht teilnehmen und keine weiteren Erinnerungen erhalten möchten, klicken Sie bitte auf den folgenden Link:<br />\n{OPTOUTURL}','Registrierungsbestätigung für Teilnahmeumfrage','Hallo {FIRSTNAME},<br />\n<br />\nSie (oder jemand, der Ihre E-Mail benutzt hat) haben sich für eine Umfrage mit dem Titel {SURVEYNAME} angemeldet.<br />\n<br />\nUm an dieser Umfrage teilzunehmen, klicken Sie bitte auf den folgenden Link.<br />\n<br />\n{SURVEYURL}<br />\n<br />\nWenn Sie irgendwelche Fragen zu dieser Umfrage haben oder wenn Sie sich _nicht_ für diese Umfrage angemeldet haben und sie glauben, dass Ihnen diese E-Mail irrtümlicherweise zugeschickt worden ist, kontaktieren Sie bitte {ADMINNAME} unter {ADMINEMAIL}.','Bestätigung für die Teilnahme an unserer Umfrage','Hallo {FIRSTNAME},<br />\n<br />\nVielen Dank für die Teilnahme an der Umfrage mit dem Titel {SURVEYNAME}. Ihre Antworten wurden bei uns gespeichert.<br />\n<br />\nWenn Sie irgendwelche Fragen zu dieser E-Mail haben, kontaktieren Sie bitte {ADMINNAME} unter {ADMINEMAIL}.<br />\n<br />\nMit freundlichen Grüßen,<br />\n<br />\n{ADMINNAME}',1,NULL,'Antwortabsendung für Umfrage {SURVEYNAME}','Hallo,<br />\n<br />\nEine neue Antwort wurde für die Umfrage \'{SURVEYNAME}\' abgegeben.<br />\n<br />\nKlicken Sie auf den folgenden Link um den Antwortdatensatz anzusehen:<br />\n{VIEWRESPONSEURL}<br />\n<br />\nKlicken Sie auf den folgenden Link um den Antwortdatensatz zu bearbeiten:<br />\n{EDITRESPONSEURL}<br />\n<br />\nUm die Statistik zu sehen, klicken Sie hier:<br />\n{STATISTICSURL}','Antwortabsendung für Umfrage {SURVEYNAME} mit Ergebnissen','Hallo,<br />\n<br />\nEine neue Antwort wurde für die Umfrage \'{SURVEYNAME}\' abgegeben.<br />\n<br />\nKlicken Sie auf den folgenden Link um den Antwortdatensatz anzusehen:<br />\n{VIEWRESPONSEURL}<br />\n<br />\nKlicken Sie auf den folgenden Link um den Antwortdatensatz zu bearbeiten:<br />\n{EDITRESPONSEURL}<br />\n<br />\nUm die Statistik zu sehen, klicken Sie hier:<br />\n{STATISTICSURL}<br />\n<br />\n<br />\nDie folgenden Antworten wurden vom Teilnehmer gegeben:<br />\n{ANSWERTABLE}',0,NULL),(976696,'de','Feedback 8n1 2019','','Mich interessiert, was du im Unterricht als hilfreich und als weniger hilfreich empfunden hast. Wovon wünschst du dir mehr, wovon weniger?','',NULL,NULL,NULL,'','','Einladung zu einer Umfrage','Hallo {FIRSTNAME},<br />\n<br />\nHiermit möchten wir Sie zu einer Umfrage einladen.<br />\n<br />\nDer Titel der Umfrage ist <br />\n\'{SURVEYNAME}\'<br />\n<br />\n\'{SURVEYDESCRIPTION}\'<br />\n<br />\nUm an dieser Umfrage teilzunehmen, klicken Sie bitte auf den unten stehenden Link.<br />\n<br />\nMit freundlichen Grüßen,<br />\n<br />\n{ADMINNAME} ({ADMINEMAIL})<br />\n<br />\n----------------------------------------------<br />\nKlicken Sie hier um die Umfrage zu starten:<br />\n{SURVEYURL}<br />\n<br />\nWenn Sie an diese Umfrage nicht teilnehmen und keine weiteren Erinnerungen erhalten möchten, klicken Sie bitte auf den folgenden Link:<br />\n{OPTOUTURL}<br />\n<br />\nWenn Sie geblockt sind, jedoch wieder teilnehmen und weitere Einladungen erhalten möchten, klicken Sie bitte auf den folgenden Link:<br />\n{OPTINURL}','Erinnerung an die Teilnahme an einer Umfrage','Hallo {FIRSTNAME},<br />\n<br />\nVor kurzem haben wir Sie zu einer Umfrage eingeladen.<br />\n<br />\nZu unserem Bedauern haben wir bemerkt, dass Sie die Umfrage noch nicht ausgefüllt haben. Wir möchten Ihnen mitteilen, dass die Umfrage noch aktiv ist und würden uns freuen, wenn Sie teilnehmen könnten.<br />\n<br />\nDer Titel der Umfrage ist <br />\n\'{SURVEYNAME}\'<br />\n<br />\n\'{SURVEYDESCRIPTION}\'<br />\n<br />\nUm an dieser Umfrage teilzunehmen, klicken Sie bitte auf den unten stehenden Link.<br />\n<br />\n Mit freundlichen Grüßen,<br />\n<br />\n{ADMINNAME} ({ADMINEMAIL})<br />\n<br />\n----------------------------------------------<br />\nKlicken Sie hier um die Umfrage zu starten:<br />\n{SURVEYURL}<br />\n<br />\nWenn Sie an diese Umfrage nicht teilnehmen und keine weiteren Erinnerungen erhalten möchten, klicken Sie bitte auf den folgenden Link:<br />\n{OPTOUTURL}','Registrierungsbestätigung für Teilnahmeumfrage','Hallo {FIRSTNAME},<br />\n<br />\nSie (oder jemand, der Ihre E-Mail benutzt hat) haben sich für eine Umfrage mit dem Titel {SURVEYNAME} angemeldet.<br />\n<br />\nUm an dieser Umfrage teilzunehmen, klicken Sie bitte auf den folgenden Link.<br />\n<br />\n{SURVEYURL}<br />\n<br />\nWenn Sie irgendwelche Fragen zu dieser Umfrage haben oder wenn Sie sich _nicht_ für diese Umfrage angemeldet haben und sie glauben, dass Ihnen diese E-Mail irrtümlicherweise zugeschickt worden ist, kontaktieren Sie bitte {ADMINNAME} unter {ADMINEMAIL}.','Bestätigung für die Teilnahme an unserer Umfrage','Hallo {FIRSTNAME},<br />\n<br />\nVielen Dank für die Teilnahme an der Umfrage mit dem Titel {SURVEYNAME}. Ihre Antworten wurden bei uns gespeichert.<br />\n<br />\nWenn Sie irgendwelche Fragen zu dieser E-Mail haben, kontaktieren Sie bitte {ADMINNAME} unter {ADMINEMAIL}.<br />\n<br />\nMit freundlichen Grüßen,<br />\n<br />\n{ADMINNAME}',1,NULL,'Antwortabsendung für Umfrage {SURVEYNAME}','Hallo,<br />\n<br />\nEine neue Antwort wurde für die Umfrage \'{SURVEYNAME}\' abgegeben.<br />\n<br />\nKlicken Sie auf den folgenden Link um den Antwortdatensatz anzusehen:<br />\n{VIEWRESPONSEURL}<br />\n<br />\nKlicken Sie auf den folgenden Link um den Antwortdatensatz zu bearbeiten:<br />\n{EDITRESPONSEURL}<br />\n<br />\nUm die Statistik zu sehen, klicken Sie hier:<br />\n{STATISTICSURL}','Antwortabsendung für Umfrage {SURVEYNAME} mit Ergebnissen','Hallo,<br />\n<br />\nEine neue Antwort wurde für die Umfrage \'{SURVEYNAME}\' abgegeben.<br />\n<br />\nKlicken Sie auf den folgenden Link um den Antwortdatensatz anzusehen:<br />\n{VIEWRESPONSEURL}<br />\n<br />\nKlicken Sie auf den folgenden Link um den Antwortdatensatz zu bearbeiten:<br />\n{EDITRESPONSEURL}<br />\n<br />\nUm die Statistik zu sehen, klicken Sie hier:<br />\n{STATISTICSURL}<br />\n<br />\n<br />\nDie folgenden Antworten wurden vom Teilnehmer gegeben:<br />\n{ANSWERTABLE}',0,NULL),(236889,'de','Feedback 5d 2019','','Mich interessiert, was du im Unterricht als hilfreich und als weniger hilfreich empfunden hast. Wovon wünschst du dir mehr, wovon weniger?','',NULL,NULL,NULL,'','','Einladung zu einer Umfrage','Hallo {FIRSTNAME},<br />\n<br />\nHiermit möchten wir Sie zu einer Umfrage einladen.<br />\n<br />\nDer Titel der Umfrage ist <br />\n\'{SURVEYNAME}\'<br />\n<br />\n\'{SURVEYDESCRIPTION}\'<br />\n<br />\nUm an dieser Umfrage teilzunehmen, klicken Sie bitte auf den unten stehenden Link.<br />\n<br />\nMit freundlichen Grüßen,<br />\n<br />\n{ADMINNAME} ({ADMINEMAIL})<br />\n<br />\n----------------------------------------------<br />\nKlicken Sie hier um die Umfrage zu starten:<br />\n{SURVEYURL}<br />\n<br />\nWenn Sie an diese Umfrage nicht teilnehmen und keine weiteren Erinnerungen erhalten möchten, klicken Sie bitte auf den folgenden Link:<br />\n{OPTOUTURL}<br />\n<br />\nWenn Sie geblockt sind, jedoch wieder teilnehmen und weitere Einladungen erhalten möchten, klicken Sie bitte auf den folgenden Link:<br />\n{OPTINURL}','Erinnerung an die Teilnahme an einer Umfrage','Hallo {FIRSTNAME},<br />\n<br />\nVor kurzem haben wir Sie zu einer Umfrage eingeladen.<br />\n<br />\nZu unserem Bedauern haben wir bemerkt, dass Sie die Umfrage noch nicht ausgefüllt haben. Wir möchten Ihnen mitteilen, dass die Umfrage noch aktiv ist und würden uns freuen, wenn Sie teilnehmen könnten.<br />\n<br />\nDer Titel der Umfrage ist <br />\n\'{SURVEYNAME}\'<br />\n<br />\n\'{SURVEYDESCRIPTION}\'<br />\n<br />\nUm an dieser Umfrage teilzunehmen, klicken Sie bitte auf den unten stehenden Link.<br />\n<br />\n Mit freundlichen Grüßen,<br />\n<br />\n{ADMINNAME} ({ADMINEMAIL})<br />\n<br />\n----------------------------------------------<br />\nKlicken Sie hier um die Umfrage zu starten:<br />\n{SURVEYURL}<br />\n<br />\nWenn Sie an diese Umfrage nicht teilnehmen und keine weiteren Erinnerungen erhalten möchten, klicken Sie bitte auf den folgenden Link:<br />\n{OPTOUTURL}','Registrierungsbestätigung für Teilnahmeumfrage','Hallo {FIRSTNAME},<br />\n<br />\nSie (oder jemand, der Ihre E-Mail benutzt hat) haben sich für eine Umfrage mit dem Titel {SURVEYNAME} angemeldet.<br />\n<br />\nUm an dieser Umfrage teilzunehmen, klicken Sie bitte auf den folgenden Link.<br />\n<br />\n{SURVEYURL}<br />\n<br />\nWenn Sie irgendwelche Fragen zu dieser Umfrage haben oder wenn Sie sich _nicht_ für diese Umfrage angemeldet haben und sie glauben, dass Ihnen diese E-Mail irrtümlicherweise zugeschickt worden ist, kontaktieren Sie bitte {ADMINNAME} unter {ADMINEMAIL}.','Bestätigung für die Teilnahme an unserer Umfrage','Hallo {FIRSTNAME},<br />\n<br />\nVielen Dank für die Teilnahme an der Umfrage mit dem Titel {SURVEYNAME}. Ihre Antworten wurden bei uns gespeichert.<br />\n<br />\nWenn Sie irgendwelche Fragen zu dieser E-Mail haben, kontaktieren Sie bitte {ADMINNAME} unter {ADMINEMAIL}.<br />\n<br />\nMit freundlichen Grüßen,<br />\n<br />\n{ADMINNAME}',1,NULL,'Antwortabsendung für Umfrage {SURVEYNAME}','Hallo,<br />\n<br />\nEine neue Antwort wurde für die Umfrage \'{SURVEYNAME}\' abgegeben.<br />\n<br />\nKlicken Sie auf den folgenden Link um den Antwortdatensatz anzusehen:<br />\n{VIEWRESPONSEURL}<br />\n<br />\nKlicken Sie auf den folgenden Link um den Antwortdatensatz zu bearbeiten:<br />\n{EDITRESPONSEURL}<br />\n<br />\nUm die Statistik zu sehen, klicken Sie hier:<br />\n{STATISTICSURL}','Antwortabsendung für Umfrage {SURVEYNAME} mit Ergebnissen','Hallo,<br />\n<br />\nEine neue Antwort wurde für die Umfrage \'{SURVEYNAME}\' abgegeben.<br />\n<br />\nKlicken Sie auf den folgenden Link um den Antwortdatensatz anzusehen:<br />\n{VIEWRESPONSEURL}<br />\n<br />\nKlicken Sie auf den folgenden Link um den Antwortdatensatz zu bearbeiten:<br />\n{EDITRESPONSEURL}<br />\n<br />\nUm die Statistik zu sehen, klicken Sie hier:<br />\n{STATISTICSURL}<br />\n<br />\n<br />\nDie folgenden Antworten wurden vom Teilnehmer gegeben:<br />\n{ANSWERTABLE}',0,NULL),(184888,'de','Feedback E-Mathe 2019','','Mich interessiert, was du im Unterricht als hilfreich und als weniger hilfreich empfunden hast. Wovon wünschst du dir mehr, wovon weniger?','',NULL,NULL,NULL,'','','Einladung zu einer Umfrage','Hallo {FIRSTNAME},<br />\n<br />\nHiermit möchten wir Sie zu einer Umfrage einladen.<br />\n<br />\nDer Titel der Umfrage ist <br />\n\'{SURVEYNAME}\'<br />\n<br />\n\'{SURVEYDESCRIPTION}\'<br />\n<br />\nUm an dieser Umfrage teilzunehmen, klicken Sie bitte auf den unten stehenden Link.<br />\n<br />\nMit freundlichen Grüßen,<br />\n<br />\n{ADMINNAME} ({ADMINEMAIL})<br />\n<br />\n----------------------------------------------<br />\nKlicken Sie hier um die Umfrage zu starten:<br />\n{SURVEYURL}<br />\n<br />\nWenn Sie an diese Umfrage nicht teilnehmen und keine weiteren Erinnerungen erhalten möchten, klicken Sie bitte auf den folgenden Link:<br />\n{OPTOUTURL}<br />\n<br />\nWenn Sie geblockt sind, jedoch wieder teilnehmen und weitere Einladungen erhalten möchten, klicken Sie bitte auf den folgenden Link:<br />\n{OPTINURL}','Erinnerung an die Teilnahme an einer Umfrage','Hallo {FIRSTNAME},<br />\n<br />\nVor kurzem haben wir Sie zu einer Umfrage eingeladen.<br />\n<br />\nZu unserem Bedauern haben wir bemerkt, dass Sie die Umfrage noch nicht ausgefüllt haben. Wir möchten Ihnen mitteilen, dass die Umfrage noch aktiv ist und würden uns freuen, wenn Sie teilnehmen könnten.<br />\n<br />\nDer Titel der Umfrage ist <br />\n\'{SURVEYNAME}\'<br />\n<br />\n\'{SURVEYDESCRIPTION}\'<br />\n<br />\nUm an dieser Umfrage teilzunehmen, klicken Sie bitte auf den unten stehenden Link.<br />\n<br />\n Mit freundlichen Grüßen,<br />\n<br />\n{ADMINNAME} ({ADMINEMAIL})<br />\n<br />\n----------------------------------------------<br />\nKlicken Sie hier um die Umfrage zu starten:<br />\n{SURVEYURL}<br />\n<br />\nWenn Sie an diese Umfrage nicht teilnehmen und keine weiteren Erinnerungen erhalten möchten, klicken Sie bitte auf den folgenden Link:<br />\n{OPTOUTURL}','Registrierungsbestätigung für Teilnahmeumfrage','Hallo {FIRSTNAME},<br />\n<br />\nSie (oder jemand, der Ihre E-Mail benutzt hat) haben sich für eine Umfrage mit dem Titel {SURVEYNAME} angemeldet.<br />\n<br />\nUm an dieser Umfrage teilzunehmen, klicken Sie bitte auf den folgenden Link.<br />\n<br />\n{SURVEYURL}<br />\n<br />\nWenn Sie irgendwelche Fragen zu dieser Umfrage haben oder wenn Sie sich _nicht_ für diese Umfrage angemeldet haben und sie glauben, dass Ihnen diese E-Mail irrtümlicherweise zugeschickt worden ist, kontaktieren Sie bitte {ADMINNAME} unter {ADMINEMAIL}.','Bestätigung für die Teilnahme an unserer Umfrage','Hallo {FIRSTNAME},<br />\n<br />\nVielen Dank für die Teilnahme an der Umfrage mit dem Titel {SURVEYNAME}. Ihre Antworten wurden bei uns gespeichert.<br />\n<br />\nWenn Sie irgendwelche Fragen zu dieser E-Mail haben, kontaktieren Sie bitte {ADMINNAME} unter {ADMINEMAIL}.<br />\n<br />\nMit freundlichen Grüßen,<br />\n<br />\n{ADMINNAME}',1,NULL,'Antwortabsendung für Umfrage {SURVEYNAME}','Hallo,<br />\n<br />\nEine neue Antwort wurde für die Umfrage \'{SURVEYNAME}\' abgegeben.<br />\n<br />\nKlicken Sie auf den folgenden Link um den Antwortdatensatz anzusehen:<br />\n{VIEWRESPONSEURL}<br />\n<br />\nKlicken Sie auf den folgenden Link um den Antwortdatensatz zu bearbeiten:<br />\n{EDITRESPONSEURL}<br />\n<br />\nUm die Statistik zu sehen, klicken Sie hier:<br />\n{STATISTICSURL}','Antwortabsendung für Umfrage {SURVEYNAME} mit Ergebnissen','Hallo,<br />\n<br />\nEine neue Antwort wurde für die Umfrage \'{SURVEYNAME}\' abgegeben.<br />\n<br />\nKlicken Sie auf den folgenden Link um den Antwortdatensatz anzusehen:<br />\n{VIEWRESPONSEURL}<br />\n<br />\nKlicken Sie auf den folgenden Link um den Antwortdatensatz zu bearbeiten:<br />\n{EDITRESPONSEURL}<br />\n<br />\nUm die Statistik zu sehen, klicken Sie hier:<br />\n{STATISTICSURL}<br />\n<br />\n<br />\nDie folgenden Antworten wurden vom Teilnehmer gegeben:<br />\n{ANSWERTABLE}',0,NULL);
/*!40000 ALTER TABLE `lszb_surveys_languagesettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_template_configuration`
--

DROP TABLE IF EXISTS `lszb_template_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_template_configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sid` int(11) DEFAULT NULL,
  `gsid` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `files_css` text COLLATE utf8mb4_unicode_ci,
  `files_js` text COLLATE utf8mb4_unicode_ci,
  `files_print_css` text COLLATE utf8mb4_unicode_ci,
  `options` text COLLATE utf8mb4_unicode_ci,
  `cssframework_name` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cssframework_css` text COLLATE utf8mb4_unicode_ci,
  `cssframework_js` text COLLATE utf8mb4_unicode_ci,
  `packages_to_load` text COLLATE utf8mb4_unicode_ci,
  `packages_ltr` text COLLATE utf8mb4_unicode_ci,
  `packages_rtl` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `lszb_idx1_template_configuration` (`template_name`),
  KEY `lszb_idx2_template_configuration` (`sid`),
  KEY `lszb_idx3_template_configuration` (`gsid`),
  KEY `lszb_idx4_template_configuration` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_template_configuration`
--

LOCK TABLES `lszb_template_configuration` WRITE;
/*!40000 ALTER TABLE `lszb_template_configuration` DISABLE KEYS */;
INSERT INTO `lszb_template_configuration` (`id`, `template_name`, `sid`, `gsid`, `uid`, `files_css`, `files_js`, `files_print_css`, `options`, `cssframework_name`, `cssframework_css`, `cssframework_js`, `packages_to_load`, `packages_ltr`, `packages_rtl`) VALUES (1,'vanilla',NULL,NULL,NULL,'{\"add\":[\"css/ajaxify.css\",\"css/theme.css\",\"css/custom.css\"]}','{\"add\":[\"scripts/theme.js\",\"scripts/ajaxify.js\",\"scripts/custom.js\"]}','{\"add\":[\"css/print_theme.css\"]}','{\"ajaxmode\":\"on\",\"brandlogo\":\"on\",\"container\":\"on\", \"hideprivacyinfo\": \"off\", \"brandlogofile\":\"./files/logo.png\",\"font\":\"noto\"}','bootstrap','{}','','{\"add\":[\"pjax\",\"font-noto\",\"moment\"]}',NULL,NULL),(2,'fruity',NULL,NULL,NULL,'{\"add\":[\"css/ajaxify.css\",\"css/animate.css\",\"css/variations/sea_green.css\",\"css/theme.css\",\"css/custom.css\"]}','{\"add\":[\"scripts/theme.js\",\"scripts/ajaxify.js\",\"scripts/custom.js\"]}','{\"add\":[\"css/print_theme.css\"]}','{\"ajaxmode\":\"on\",\"brandlogo\":\"on\",\"brandlogofile\":\"./files/logo.png\",\"container\":\"on\",\"backgroundimage\":\"off\",\"backgroundimagefile\":null,\"animatebody\":\"off\",\"bodyanimation\":\"fadeInRight\",\"bodyanimationduration\":\"500\",\"animatequestion\":\"off\",\"questionanimation\":\"flipInX\",\"questionanimationduration\":\"500\",\"animatealert\":\"off\",\"alertanimation\":\"shake\",\"alertanimationduration\":\"500\",\"font\":\"noto\",\"bodybackgroundcolor\":\"#ffffff\",\"fontcolor\":\"#444444\",\"questionbackgroundcolor\":\"#ffffff\",\"questionborder\":\"on\",\"questioncontainershadow\":\"on\",\"checkicon\":\"f00c\",\"animatecheckbox\":\"on\",\"checkboxanimation\":\"rubberBand\",\"checkboxanimationduration\":\"500\",\"animateradio\":\"on\",\"radioanimation\":\"zoomIn\",\"radioanimationduration\":\"500\",\"zebrastriping\":\"off\",\"stickymatrixheaders\":\"off\",\"greyoutselected\":\"off\",\"hideprivacyinfo\":\"off\",\"crosshover\":\"off\",\"showpopups\":\"1\"}','bootstrap','{}','','{\"add\":[\"pjax\",\"font-noto\",\"moment\"]}',NULL,NULL),(3,'bootswatch',NULL,NULL,NULL,'{\"add\":[\"css/ajaxify.css\",\"css/theme.css\",\"css/custom.css\"]}','{\"add\":[\"scripts/theme.js\",\"scripts/ajaxify.js\",\"scripts/custom.js\"]}','{\"add\":[\"css/print_theme.css\"]}','{\"ajaxmode\":\"on\",\"brandlogo\":\"on\",\"container\":\"on\",\"brandlogofile\":\"./files/logo.png\"}','bootstrap','{\"replace\":[[\"css/bootstrap.css\",\"css/variations/flatly.min.css\"]]}','','{\"add\":[\"pjax\",\"font-noto\",\"moment\"]}',NULL,NULL),(4,'fruity',632936,NULL,NULL,'inherit','inherit','inherit','inherit','inherit','inherit','inherit','inherit',NULL,NULL),(5,'fruity',NULL,1,NULL,'inherit','inherit','inherit','inherit','inherit','inherit','inherit','inherit',NULL,NULL),(6,'fruity',579638,NULL,NULL,'inherit','inherit','inherit','inherit','inherit','inherit','inherit','inherit',NULL,NULL),(7,'fruity',699157,NULL,NULL,'inherit','inherit','inherit','inherit','inherit','inherit','inherit','inherit',NULL,NULL),(8,'fruity',764279,NULL,NULL,'inherit','inherit','inherit','inherit','inherit','inherit','inherit','inherit',NULL,NULL),(9,'fruity',184888,NULL,NULL,'inherit','inherit','inherit','inherit','inherit','inherit','inherit','inherit',NULL,NULL),(10,'fruity',976696,NULL,NULL,'inherit','inherit','inherit','inherit','inherit','inherit','inherit','inherit',NULL,NULL),(11,'fruity',236889,NULL,NULL,'inherit','inherit','inherit','inherit','inherit','inherit','inherit','inherit',NULL,NULL);
/*!40000 ALTER TABLE `lszb_template_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_templates`
--

DROP TABLE IF EXISTS `lszb_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `folder` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation_date` datetime DEFAULT NULL,
  `author` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `copyright` text COLLATE utf8mb4_unicode_ci,
  `license` text COLLATE utf8mb4_unicode_ci,
  `version` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_version` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `view_folder` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `files_folder` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `last_update` datetime DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `extends` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lszb_idx1_templates` (`name`),
  KEY `lszb_idx2_templates` (`title`),
  KEY `lszb_idx3_templates` (`owner_id`),
  KEY `lszb_idx4_templates` (`extends`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_templates`
--

LOCK TABLES `lszb_templates` WRITE;
/*!40000 ALTER TABLE `lszb_templates` DISABLE KEYS */;
INSERT INTO `lszb_templates` (`id`, `name`, `folder`, `title`, `creation_date`, `author`, `author_email`, `author_url`, `copyright`, `license`, `version`, `api_version`, `view_folder`, `files_folder`, `description`, `last_update`, `owner_id`, `extends`) VALUES (1,'vanilla','vanilla','Vanilla Theme','2019-04-02 10:15:14','Louis Gac','louis.gac@limesurvey.org','https://www.limesurvey.org/','Copyright (C) 2007-2017 The LimeSurvey Project Team\\r\\nAll rights reserved.','License: GNU/GPL License v2 or later, see LICENSE.php\\r\\n\\r\\nLimeSurvey is free software. This version may have been modified pursuant to the GNU General Public License, and as distributed it includes or is derivative of works licensed under the GNU General Public License or other free or open source software licenses. See COPYRIGHT.php for copyright notices and details.','3.0','3.0','views','files','<strong>LimeSurvey Bootstrap Vanilla Survey Theme</strong><br>A clean and simple base that can be used by developers to create their own Bootstrap based theme.',NULL,1,''),(2,'fruity','fruity','Fruity Theme','2019-04-02 10:15:14','Louis Gac','louis.gac@limesurvey.org','https://www.limesurvey.org/','Copyright (C) 2007-2017 The LimeSurvey Project Team\\r\\nAll rights reserved.','License: GNU/GPL License v2 or later, see LICENSE.php\\r\\n\\r\\nLimeSurvey is free software. This version may have been modified pursuant to the GNU General Public License, and as distributed it includes or is derivative of works licensed under the GNU General Public License or other free or open source software licenses. See COPYRIGHT.php for copyright notices and details.','3.0','3.0','views','files','<strong>LimeSurvey Fruity Theme</strong><br>A fruity theme for a flexible use. This theme offers monochromes variations and many options for easy customizations.',NULL,1,'vanilla'),(3,'bootswatch','bootswatch','Bootswatch Theme','2019-04-02 10:15:14','Louis Gac','louis.gac@limesurvey.org','https://www.limesurvey.org/','Copyright (C) 2007-2017 The LimeSurvey Project Team\\r\\nAll rights reserved.','License: GNU/GPL License v2 or later, see LICENSE.php\\r\\n\\r\\nLimeSurvey is free software. This version may have been modified pursuant to the GNU General Public License, and as distributed it includes or is derivative of works licensed under the GNU General Public License or other free or open source software licenses. See COPYRIGHT.php for copyright notices and details.','3.0','3.0','views','files','<strong>LimeSurvey Bootwatch Theme</strong><br>Based on BootsWatch Themes: <a href=\"https://bootswatch.com/3/\"\">Visit BootsWatch page</a> ',NULL,1,'vanilla');
/*!40000 ALTER TABLE `lszb_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_tokens_184888`
--

DROP TABLE IF EXISTS `lszb_tokens_184888`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_tokens_184888` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `participant_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `firstname` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` text COLLATE utf8mb4_unicode_ci,
  `emailstatus` text COLLATE utf8mb4_unicode_ci,
  `token` varchar(35) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `language` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blacklisted` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sent` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `remindersent` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `remindercount` int(11) DEFAULT '0',
  `completed` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `usesleft` int(11) DEFAULT '1',
  `validfrom` datetime DEFAULT NULL,
  `validuntil` datetime DEFAULT NULL,
  `mpid` int(11) DEFAULT NULL,
  PRIMARY KEY (`tid`),
  KEY `idx_token_token_184888_12652` (`token`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_tokens_184888`
--

LOCK TABLES `lszb_tokens_184888` WRITE;
/*!40000 ALTER TABLE `lszb_tokens_184888` DISABLE KEYS */;
INSERT INTO `lszb_tokens_184888` (`tid`, `participant_id`, `firstname`, `lastname`, `email`, `emailstatus`, `token`, `language`, `blacklisted`, `sent`, `remindersent`, `remindercount`, `completed`, `usesleft`, `validfrom`, `validuntil`, `mpid`) VALUES (1,NULL,'','','','OK','emathe','de',NULL,'N','N',0,'N',16,NULL,NULL,NULL);
/*!40000 ALTER TABLE `lszb_tokens_184888` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_tokens_236889`
--

DROP TABLE IF EXISTS `lszb_tokens_236889`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_tokens_236889` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `participant_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `firstname` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` text COLLATE utf8mb4_unicode_ci,
  `emailstatus` text COLLATE utf8mb4_unicode_ci,
  `token` varchar(35) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `language` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blacklisted` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sent` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `remindersent` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `remindercount` int(11) DEFAULT '0',
  `completed` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `usesleft` int(11) DEFAULT '1',
  `validfrom` datetime DEFAULT NULL,
  `validuntil` datetime DEFAULT NULL,
  `mpid` int(11) DEFAULT NULL,
  PRIMARY KEY (`tid`),
  KEY `idx_token_token_236889_28894` (`token`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_tokens_236889`
--

LOCK TABLES `lszb_tokens_236889` WRITE;
/*!40000 ALTER TABLE `lszb_tokens_236889` DISABLE KEYS */;
INSERT INTO `lszb_tokens_236889` (`tid`, `participant_id`, `firstname`, `lastname`, `email`, `emailstatus`, `token`, `language`, `blacklisted`, `sent`, `remindersent`, `remindercount`, `completed`, `usesleft`, `validfrom`, `validuntil`, `mpid`) VALUES (1,NULL,'','','','OK','5d','de',NULL,'N','N',0,'N',28,NULL,NULL,NULL);
/*!40000 ALTER TABLE `lszb_tokens_236889` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_tokens_579638`
--

DROP TABLE IF EXISTS `lszb_tokens_579638`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_tokens_579638` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `participant_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `firstname` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` text COLLATE utf8mb4_unicode_ci,
  `emailstatus` text COLLATE utf8mb4_unicode_ci,
  `token` varchar(35) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `language` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blacklisted` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sent` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `remindersent` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `remindercount` int(11) DEFAULT '0',
  `completed` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `usesleft` int(11) DEFAULT '1',
  `validfrom` datetime DEFAULT NULL,
  `validuntil` datetime DEFAULT NULL,
  `mpid` int(11) DEFAULT NULL,
  PRIMARY KEY (`tid`),
  KEY `idx_token_token_579638_24340` (`token`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_tokens_579638`
--

LOCK TABLES `lszb_tokens_579638` WRITE;
/*!40000 ALTER TABLE `lszb_tokens_579638` DISABLE KEYS */;
INSERT INTO `lszb_tokens_579638` (`tid`, `participant_id`, `firstname`, `lastname`, `email`, `emailstatus`, `token`, `language`, `blacklisted`, `sent`, `remindersent`, `remindercount`, `completed`, `usesleft`, `validfrom`, `validuntil`, `mpid`) VALUES (1,NULL,'','','','OK','sqlkurs2019','de',NULL,'N','N',0,'N',91,NULL,NULL,NULL);
/*!40000 ALTER TABLE `lszb_tokens_579638` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_tokens_632936`
--

DROP TABLE IF EXISTS `lszb_tokens_632936`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_tokens_632936` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `participant_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `firstname` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` text COLLATE utf8mb4_unicode_ci,
  `emailstatus` text COLLATE utf8mb4_unicode_ci,
  `token` varchar(35) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `language` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blacklisted` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sent` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `remindersent` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `remindercount` int(11) DEFAULT '0',
  `completed` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `usesleft` int(11) DEFAULT '1',
  `validfrom` datetime DEFAULT NULL,
  `validuntil` datetime DEFAULT NULL,
  `mpid` int(11) DEFAULT NULL,
  PRIMARY KEY (`tid`),
  KEY `idx_token_token_632936_23621` (`token`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_tokens_632936`
--

LOCK TABLES `lszb_tokens_632936` WRITE;
/*!40000 ALTER TABLE `lszb_tokens_632936` DISABLE KEYS */;
INSERT INTO `lszb_tokens_632936` (`tid`, `participant_id`, `firstname`, `lastname`, `email`, `emailstatus`, `token`, `language`, `blacklisted`, `sent`, `remindersent`, `remindercount`, `completed`, `usesleft`, `validfrom`, `validuntil`, `mpid`) VALUES (1,NULL,'','','','OK','pythonkurs2019','de',NULL,'N','N',0,'N',198,'2019-04-20 21:42:00','2019-07-12 21:42:00',NULL);
/*!40000 ALTER TABLE `lszb_tokens_632936` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_tokens_976696`
--

DROP TABLE IF EXISTS `lszb_tokens_976696`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_tokens_976696` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `participant_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `firstname` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` text COLLATE utf8mb4_unicode_ci,
  `emailstatus` text COLLATE utf8mb4_unicode_ci,
  `token` varchar(35) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `language` varchar(25) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blacklisted` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sent` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `remindersent` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `remindercount` int(11) DEFAULT '0',
  `completed` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT 'N',
  `usesleft` int(11) DEFAULT '1',
  `validfrom` datetime DEFAULT NULL,
  `validuntil` datetime DEFAULT NULL,
  `mpid` int(11) DEFAULT NULL,
  PRIMARY KEY (`tid`),
  KEY `idx_token_token_976696_48150` (`token`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_tokens_976696`
--

LOCK TABLES `lszb_tokens_976696` WRITE;
/*!40000 ALTER TABLE `lszb_tokens_976696` DISABLE KEYS */;
INSERT INTO `lszb_tokens_976696` (`tid`, `participant_id`, `firstname`, `lastname`, `email`, `emailstatus`, `token`, `language`, `blacklisted`, `sent`, `remindersent`, `remindercount`, `completed`, `usesleft`, `validfrom`, `validuntil`, `mpid`) VALUES (1,NULL,'','','','OK','8n1','de',NULL,'N','N',0,'N',25,NULL,NULL,NULL);
/*!40000 ALTER TABLE `lszb_tokens_976696` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_tutorial_entries`
--

DROP TABLE IF EXISTS `lszb_tutorial_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_tutorial_entries` (
  `teid` int(11) NOT NULL AUTO_INCREMENT,
  `ordering` int(11) DEFAULT NULL,
  `title` text COLLATE utf8mb4_unicode_ci,
  `content` text COLLATE utf8mb4_unicode_ci,
  `settings` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`teid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_tutorial_entries`
--

LOCK TABLES `lszb_tutorial_entries` WRITE;
/*!40000 ALTER TABLE `lszb_tutorial_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_tutorial_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_tutorial_entry_relation`
--

DROP TABLE IF EXISTS `lszb_tutorial_entry_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_tutorial_entry_relation` (
  `teid` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `sid` int(11) DEFAULT NULL,
  PRIMARY KEY (`teid`,`tid`),
  KEY `lszb_idx1_tutorial_entry_relation` (`uid`),
  KEY `lszb_idx2_tutorial_entry_relation` (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_tutorial_entry_relation`
--

LOCK TABLES `lszb_tutorial_entry_relation` WRITE;
/*!40000 ALTER TABLE `lszb_tutorial_entry_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_tutorial_entry_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_tutorials`
--

DROP TABLE IF EXISTS `lszb_tutorials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_tutorials` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(192) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `active` int(11) DEFAULT '0',
  `settings` text COLLATE utf8mb4_unicode_ci,
  `permission` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permission_grade` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`tid`),
  UNIQUE KEY `lszb_idx1_tutorials` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_tutorials`
--

LOCK TABLES `lszb_tutorials` WRITE;
/*!40000 ALTER TABLE `lszb_tutorials` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_tutorials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_user_groups`
--

DROP TABLE IF EXISTS `lszb_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_user_groups` (
  `ugid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` int(11) NOT NULL,
  PRIMARY KEY (`ugid`),
  UNIQUE KEY `lszb_idx1_user_groups` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_user_groups`
--

LOCK TABLES `lszb_user_groups` WRITE;
/*!40000 ALTER TABLE `lszb_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_user_in_groups`
--

DROP TABLE IF EXISTS `lszb_user_in_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_user_in_groups` (
  `ugid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY (`ugid`,`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_user_in_groups`
--

LOCK TABLES `lszb_user_in_groups` WRITE;
/*!40000 ALTER TABLE `lszb_user_in_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `lszb_user_in_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lszb_users`
--

DROP TABLE IF EXISTS `lszb_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lszb_users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `users_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int(11) NOT NULL,
  `lang` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(192) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `htmleditormode` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `templateeditormode` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `questionselectormode` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `one_time_pw` text COLLATE utf8mb4_unicode_ci,
  `dateformat` int(11) NOT NULL DEFAULT '1',
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `lszb_idx1_users` (`users_name`),
  KEY `lszb_idx2_users` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lszb_users`
--

LOCK TABLES `lszb_users` WRITE;
/*!40000 ALTER TABLE `lszb_users` DISABLE KEYS */;
INSERT INTO `lszb_users` (`uid`, `users_name`, `password`, `full_name`, `parent_id`, `lang`, `email`, `htmleditormode`, `templateeditormode`, `questionselectormode`, `one_time_pw`, `dateformat`, `created`, `modified`) VALUES (1,'admin','$2y$10$IpQvK4gIjjt045dHcedLIuMLDuJ6oBwfvFE/k9v2gxqKALyrR95vW','Administrator',0,'de','admin@survey.cws-lernen.de','default','default','default',NULL,1,'2019-04-02 10:15:14','2019-04-02 10:22:32');
/*!40000 ALTER TABLE `lszb_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'kd34245_lime409'
--

--
-- Dumping routines for database 'kd34245_lime409'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-07-24 16:07:15
